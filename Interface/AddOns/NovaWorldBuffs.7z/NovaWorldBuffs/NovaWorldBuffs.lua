--------------------
--Nova World Buffs--
--------------------
--Classic WoW world buff timers and pre warnings.
--Novaspark-Arugal OCE (classic).
--https://www.curseforge.com/members/venomisto/projects
--Note: Server restarts will cause the timers to be inaccurate because the NPC's reset.

NWB = LibStub("AceAddon-3.0"):NewAddon("NovaWorldBuffs", "AceComm-3.0");
NWB.dragonLib = LibStub("HereBeDragons-2.0");
NWB.dragonLibPins = LibStub("HereBeDragons-Pins-2.0");
NWB.commPrefix = "NWB";
NWB.hasAddon = {};
local L = LibStub("AceLocale-3.0"):GetLocale("NovaWorldBuffs");
local Serializer = LibStub:GetLibrary("AceSerializer-3.0");
local realm = GetRealmName();
local faction = UnitFactionGroup("player");
local version = GetAddOnMetadata("NovaWorldBuffs", "Version") or 9999;

function NWB:OnInitialize()
	self:loadFactionSpecificOptions();
    self.db = LibStub("AceDB-3.0"):New("NWBdatabase", NWB.optionDefaults, "Default");
    LibStub("AceConfig-3.0"):RegisterOptionsTable("NovaWorldBuffs", NWB.options);
	self.NWBOptions = LibStub("AceConfigDialog-3.0"):AddToBlizOptions("NovaWorldBuffs", "NovaWorldBuffs");
	self.chatColor = "|cff" .. self:RGBToHex(self.db.global.chatColorR, self.db.global.chatColorG, self.db.global.chatColorB);
	self:RegisterComm(self.commPrefix);
	self:registerOtherAddons();
	self:buildRealmFactionData();
	self:timerCleanup();
	self:ticker();
	self:yellTicker();
	self:setSongFlowers();
	self:createSongflowerMarkers();
	self:createWorldbuffMarkersTable();
	self:createWorldbuffMarkers();
end

function NWB:OnCommReceived(commPrefix, string, distribution, sender)
	if (UnitInBattleground("player") and distribution ~= "GUILD") then
		return;
	end
	--AceComm doesn't supply realm name if it's on the same realm as player.
	--Not sure if it provives GetRealmName() or GetNormalizedRealmName() for crossrealm.
	--For now we'll check all 3 name types just to be sure until tested.
	local me = UnitName("player") .. "-" .. GetRealmName();
	local meNormalized = UnitName("player") .. "-" .. GetNormalizedRealmName();
	if (sender == UnitName("player") or sender == me or sender == meNormalized) then
		NWB.hasAddon[meNormalized] = true;
		return;
	end
	local _, realm = strsplit("-", sender, 2);
	--If realm found then it's not my realm, but just incase acecomm changes and starts supplying realm also check if realm exists.
	if (realm ~= nil or (realm and realm ~= GetRealmName() and realm ~= GetNormalizedRealmName())) then
		--Ignore data from other realms (in bgs).
		return;
	end
	if (commPrefix == "WBT-1" or commPrefix == "WBT-2" or commPrefix == "WBT-3" or commPrefix == "WBT-0" or commPrefix == "WBT-A") then
			--Parse WBT.
			NWB:parseWorldBuffTracker(commPrefix, string, distribution, sender);
			return;
	elseif (commPrefix == "D4C") then
			--Parse DBM.
			NWB:parseDBM(commPrefix, string, distribution, sender);
			return;
	elseif (commPrefix == "FADEWT-5") then
			--Parse Fade.
			NWB:parseFade(commPrefix, string, distribution, sender);
			return;
	end
	--If no realm in name it must be our realm so add it.
	if (not string.match(sender, "-")) then
		--Add normalized realm since roster checks use this.
		sender = sender .. "-" .. GetNormalizedRealmName();
	end
	--Keep a list of addon users for use in NWB:sendGuildMsg().
	NWB.hasAddon[sender] = true;
	local deserializeResult, deserialized = Serializer:Deserialize(string);
	if (not deserializeResult) then
		NWB:debug("Error deserializing:", string);
		return;
	end
	local args = NWB:explode(" ", deserialized, 2);
	local cmd = args[1]; --Cmd (first arg) so we know where to send the data.
	local remoteVersion = args[2]; --Version number.
	local data = args[3]; --Data (everything after version arg).
	if (data == nil) then
		--Temp fix for people with old version data structure sending incompatable data.
		--Only effects a few of the early testers.
		data = args[2]; --Data (everything after version arg).
		remoteVersion = 0;
	end
	--Ignore old version data with this update, trying to weed out old versions setting wrong timers.
	if (tonumber(remoteVersion) < 1.23) then
		if (cmd == "requestData" and distribution == "GUILD") then
			NWB:sendData("GUILD");
		end
		return;
	end
	if (cmd == "data") then
		NWB:receivedData(data, sender, distribution);
	elseif (cmd == "requestData") then
		--Other addon users request data when they log on.
		NWB:receivedData(data, sender, distribution);
		NWB:sendData("GUILD");
	elseif (cmd == "yell" and not (NWB.db.global.receiveGuildDataOnly and distribution ~= "GUILD")) then
		--Yell msg seen by someone in org.
		NWB:doFirstYell(data);
	end
	NWB:versionCheck(remoteVersion);
end

--Send to specified addon channel.
function NWB:sendComm(distribution, string, target)
	if (target == UnitName("player")) then
		return;
	end
	if (distribution == "GUILD" and not IsInGuild()) then
		return;
	end
	if (distribution == "CHANNEL") then
		--Get channel ID number.
		local addonChannelId = GetChannelName(target);
		--Not sure why this only accepts a string and not an int.
		--Addon channels are disabled in classic but I'll leave this here anyway.
		target = tostring(addonChannelId);
	elseif (distribution ~= "WHISPER") then
		target = nil;
	end
	local serialized = Serializer:Serialize(string);
	NWB:SendCommMessage(NWB.commPrefix, serialized, distribution, target);
end

--Send full data.
function NWB:sendData(distribution, target, prio)
	if (not prio) then
		prio = "NORMAL";
	end
	local data = NWB:createData(distribution);
	if (next(data) ~= nil) then
		data = Serializer:Serialize(data);
		NWB:sendComm(distribution, "data " .. version .. " " .. data, target, prio);
	end
end

--Send first yell msg.
function NWB:sendYell(distribution, type)
	NWB:sendComm(distribution, "yell " .. version .. " " .. type, target);
end

--Send full data and also request other users data back, used at logon time.
function NWB:requestData(distribution, target, prio)
	if (not prio) then
		prio = "NORMAL";
	end
	local data = NWB:createData(distribution);
	data = Serializer:Serialize(data);
	NWB:sendComm(distribution, "requestData " .. version .. " " .. data, target, prio);
end

--Create data table for sending.
function NWB:createData(distribution)
	local data = {};
	if (UnitInBattleground("player") and distribution ~= "GUILD") then
		return data;
	end
	if (NWB.data.rendTimer > (GetServerTime() - NWB.db.global.rendRespawnTime)) then
		data['rendTimer'] = NWB.data.rendTimer;
		data['rendTimerWho'] = NWB.data.rendTimerWho;
		data['rendYell'] = NWB.data.rendYell;
		data['rendYell2'] = NWB.data.rendYell2;
		data['rendSource'] = NWB.data.rendSource;
	end
	if (NWB.data.onyTimer > (GetServerTime() - NWB.db.global.onyRespawnTime)) then
		data['onyTimer'] = NWB.data.onyTimer;
		data['onyTimerWho'] = NWB.data.onyTimerWho;
		data['onyYell'] = NWB.data.onyYell;
		data['onyYell2'] = NWB.data.onyYell2;
		data['onySource'] = NWB.data.onySource;
	end
	if (NWB.data.nefTimer > (GetServerTime() - NWB.db.global.nefRespawnTime)) then
		data['nefTimer'] = NWB.data.nefTimer;
		data['nefTimerWho'] = NWB.data.nefTimerWho;
		data['nefYell'] = NWB.data.nefYell;
		data['nefYell2'] = NWB.data.nefYell2;
		data['nefSource'] = NWB.data.nefSource;
	end
	if ((NWB.data.onyNpcDied > NWB.data.onyTimer) and
			(NWB.data.onyNpcDied > (GetServerTime() - NWB.db.global.onyRespawnTime))) then
		data['onyNpcDied'] = NWB.data.onyNpcDied;
	end
	if ((NWB.data.nefNpcDied > NWB.data.nefTimer) and
			(NWB.data.nefNpcDied > (GetServerTime() - NWB.db.global.nefRespawnTime))) then
		data['nefNpcDied'] = NWB.data.nefNpcDied;
	end
	for k, v in pairs(NWB.songFlowers) do
		--Add currently active songflower timers.
		if (NWB.data[k] > GetServerTime() - 1500) then
			data[k] = NWB.data[k];
		end
	end
	if (distribution == "GUILD") then
		local me = UnitName("player") .. "-" .. GetNormalizedRealmName();
		data[me] = {
			["lastUpdate"] = GetServerTime(), 
			["disableAllGuildMsgs"] = NWB.db.global.disableAllGuildMsgs,
			["guildBuffDropped"] = NWB.db.global.guildBuffDropped,
			["guildNpcDialogue"] = NWB.db.global.guildNpcDialogue,
			["guildCommand"] = NWB.db.global.guildCommand,
			["guild30"] = NWB.db.global.guild30,
			["guild15"] = NWB.db.global.guild15,
			["guild10"] = NWB.db.global.guild10,
			["guild5"] = NWB.db.global.guild5,
			["guild1"] = NWB.db.global.guild1,
			["guild0"] = NWB.db.global.guild0,
		};
	end
	data['faction'] = faction;
	return data;
end

--Add received data to our database.
function NWB:receivedData(data, sender, distribution)
	local deserializeResult, data = Serializer:Deserialize(data);
	if (not deserializeResult) then
		NWB:debug("Failed to deserialize data.");
		return;
	end
	--A faction check should not be needed but who knows what funky stuff can happen with the new yell channel and mind control etc.
	--if (not data['faction'] or data['faction'] ~= faction) then
	--	NWB:debug("data from opposite faction received", sender, distribution);
	--	return;
	--end
	local ignoreList = {
		--["dbm"] = true,
		--["WorldBuffTracker"] = true,
		--["Fade"] = true,
	};
	--Ignore data from out of date version users if we've disabled another addons sync.
	for k, v in pairs(ignoreList) do
		if (data["rendSource"] and data["rendSource"] == k) then
			NWB:debug("ignoring rend data from", sender, k);
			data['rendTimer'] = nil;
			data['rendTimerWho'] = nil;
			data['rendYell'] = nil;
			data['rendYell2'] = nil;
			data['rendSource'] = nil;
		end
		if (data["onySource"] and data["onySource"] == k) then
			NWB:debug("ignoring ony data from", sender, k);
			data['onyTimer'] = nil;
			data['onyTimerWho'] = nil;
			data['onyYell'] = nil;
			data['onyYell2'] = nil;
			data['onySource'] = nil;
		end
		if (data["nefSource"] and data["nefSource"] == k) then
			NWB:debug("ignoring nef data from", sender, k);
			data['nefTimer'] = nil;
			data['nefTimerWho'] = nil;
			data['nefYell'] = nil;
			data['nefYell2'] = nil;
			data['nefSource'] = nil;
		end
	end
	if (data["rendTimer"] and (data["rendTimer"] < NWB.data["rendTimer"] or 
		(data["rendYell"] < (data["rendTimer"] - 120) and data["rendYell2"] < (data["rendTimer"] - 120)))) then
		--Don't overwrite any data for this timer type if it's an old timer.
		if (data["rendYell"] < (data["rendTimer"] - 120) and data["rendYell2"] < (data["rendTimer"] - 120)) then
			NWB:debug("invalid rend timer from", sender, "npcyell:", data["rendYell"], "buffdropped:", data["rendTimer"]);
		end
		data['rendTimer'] = nil;
		data['rendTimerWho'] = nil;
		data['rendYell'] = nil;
		data['rendYell2'] = nil;
		data['rendSource'] = nil;
	end
	if (data["onyTimer"] and (data["onyTimer"] < NWB.data["onyTimer"] or
			(data["onyYell"] < (data["onyTimer"] - 120) and data["onyYell2"] < (data["onyTimer"] - 120)))) then
		if (data["onyYell"] < (data["onyTimer"] - 120) and data["onyYell2"] < (data["onyTimer"] - 120)) then
			NWB:debug("invalid ony timer from", sender, "npcyell:", data["onyYell"], "buffdropped:", data["onyTimer"]);
		end
		data['onyTimer'] = nil;
		data['onyTimerWho'] = nil;
		data['onyYell'] = nil;
		data['onyYell2'] = nil;
		data['onySource'] = nil;
	end
	if (data["nefTimer"] and (data["nefTimer"] < NWB.data["nefTimer"] or
			(data["nefYell"] < (data["nefTimer"] - 120) and data["nefYell2"] < (data["nefTimer"] - 120)))) then
		if (data["nefYell"] < (data["nefTimer"] - 120) and data["nefYell2"] < (data["nefTimer"] - 120)) then
			NWB:debug("invalid nef timer from", sender, "npcyell:", data["nefYell"], "buffdropped:", data["nefTimer"]);
		end
		data['nefTimer'] = nil;
		data['nefTimerWho'] = nil;
		data['nefYell'] = nil;
		data['nefYell2'] = nil;
		data['nefSource'] = nil;
	end
	local hasNewData, newFlowerData;
	for k, v in pairs(data) do
		if ((string.match(k, "flower") and NWB.db.global.syncFlowersAll)
				or (not NWB.db.global.receiveGuildDataOnly)
				or (NWB.db.global.receiveGuildDataOnly and distribution == "GUILD")) then
			if (tonumber(v)) then
				--If data is numeric (a timestamp) then check it's newer than our current timer.
				if (v ~= nil) then
					if (v ~= 0 and v > NWB.data[k]) then
						NWB:debug("new data", sender, distribution, k, v, "old:", NWB.data[k]);
						if (string.match(k, "flower") and not (distribution == "GUILD" and (GetServerTime() - NWB.data[k]) > 15)) then
							newFlowerData = true;
						end
						NWB.data[k] = v;
						hasNewData = true;
					end
				end
			elseif (v ~= nil) then
				NWB.data[k] = v;
			end
		end
	end
	NWB:timerCleanup();
	--If we get newer data from someone outside the guild then share it with the guild.
	if (hasNewData) then
		NWB.data.lastSyncBy = sender;
		NWB:debug("new data done", sender, distribution, NWB:isPlayerInGuild(sender));
		if (distribution ~= "GUILD" and not NWB:isPlayerInGuild(sender)) then
			NWB:debug("sending new guild data");
			NWB:sendData("GUILD");
		end
	end
	--If new flower data received and not freshly picked by guild member (that sends a msg to guild chat already)
	if (newFlowerData) then
		--local string = "New songflower timer received:";
		local string = L["newSongflowerReceived"] .. ":";
		local found;
		for k, v in pairs(NWB.songFlowers) do
			local time = (NWB.data[k] + 1500) - GetServerTime();
			if (time > 0) then
				local minutes = string.format("%02.f", math.floor(time / 60));
    			local seconds = string.format("%02.f", math.floor(time - minutes * 60));
				string = string .. " (" .. v.subZone .. " " .. minutes .. "m" .. seconds .. "s)";
				found = true;
  			end
		end
		if (not found) then
			string = string .. " " .. L["noActiveTimers"] .. ".";
		end
		NWB:print(string);
	end
end

function NWB:versionCheck(remoteVersion)
	local lastVersionMsg = NWB.db.global.lastVersionMsg;
	if (tonumber(remoteVersion) > tonumber(version) and (GetServerTime() - lastVersionMsg) > 21600) then
		print("|cffffff00" .. L["versionOutOfDate"] .. ".");
		NWB.db.global.lastVersionMsg = GetServerTime();
	end
end
--Print current buff timers to chat window.
function NWB:printBuffTimers(channel)
	local msg;
	if (faction == "Horde" or NWB.db.global.allianceEnableRend) then
		if (NWB.data.rendTimer > (GetServerTime() - NWB.db.global.rendRespawnTime)) then
			--msg = L["rend"] .. ": " .. NWB:getTimeString(NWB.db.global.rendRespawnTime - (GetServerTime() - NWB.data.rendTimer), true) .. ".";
			msg = L["rend"] .. ": " .. NWB:getTimeString(NWB.db.global.rendRespawnTime - (GetServerTime() - NWB.data.rendTimer), true) .. ".";
			if (NWB.db.global.showTimeStamp) then
				local timeStamp = NWB:getTimeFormat(NWB.data.rendTimer + NWB.db.global.rendRespawnTime);
				msg = msg .. " (" .. timeStamp .. ")";
			end
		else
			msg = L["rend"] .. ": " .. L["noCurrentTimer"] .. ".";
		end
		NWB:print(msg, channel);
	end
	if ((NWB.data.onyNpcDied > NWB.data.onyTimer) and
			(NWB.data.onyNpcDied > (GetServerTime() - NWB.db.global.onyRespawnTime))) then
		if (faction == "Horde") then
			msg = "Onyxia NPC (Runthak) was killed " .. NWB:getTimeString(GetServerTime() - NWB.data.onyNpcDied, true) 
					.. " ago no buff recorded since.";
		else
			msg = "Onyxia NPC (Mattingly) was killed " .. NWB:getTimeString(GetServerTime() - NWB.data.onyNpcDied, true) 
					.. " ago no buff recorded since.";
		end
	elseif (NWB.data.onyTimer > (GetServerTime() - NWB.db.global.onyRespawnTime)) then
		msg = L["onyxia"] .. ": " .. NWB:getTimeString(NWB.db.global.onyRespawnTime - (GetServerTime() - NWB.data.onyTimer), true) .. ".";
		if (NWB.db.global.showTimeStamp) then
			local timeStamp = NWB:getTimeFormat(NWB.data.onyTimer + NWB.db.global.onyRespawnTime);
			msg = msg .. " (" .. timeStamp .. ")";
		end
	else
		msg = L["onyxia"] .. ": " .. L["noCurrentTimer"] .. ".";
	end
	NWB:print(msg, channel);
	if ((NWB.data.nefNpcDied > NWB.data.nefTimer) and
			(NWB.data.nefNpcDied > (GetServerTime() - NWB.db.global.nefRespawnTime))) then
		if (faction == "Horde") then
			msg = "Nefarian NPC (Saurfang) was killed " .. NWB:getTimeString(GetServerTime() - NWB.data.nefNpcDied, true) 
					.. " ago no buff recorded since.";
		else
			msg = "Nefarian NPC (Afrasiabi) was killed " .. NWB:getTimeString(GetServerTime() - NWB.data.nefNpcDied, true) 
					.. " ago no buff recorded since.";
		end
	elseif (NWB.data.nefTimer > (GetServerTime() - NWB.db.global.nefRespawnTime)) then
		msg = L["nefarian"] .. ": " .. NWB:getTimeString(NWB.db.global.nefRespawnTime - (GetServerTime() - NWB.data.nefTimer), true) .. ".";
		if (NWB.db.global.showTimeStamp) then
			local timeStamp = NWB:getTimeFormat(NWB.data.nefTimer + NWB.db.global.nefRespawnTime);
			msg = msg .. " (" .. timeStamp .. ")";
		end
	else
		msg = L["nefarian"] .. ": " .. L["noCurrentTimer"] .. ".";
	end
	NWB:print(msg, channel);
end


--Single line buff timers.
function NWB:getShortBuffTimers(channel)
	local msg = "";
	if (faction == "Horde" or NWB.db.global.allianceEnableRend) then
		if (NWB.data.rendTimer > (GetServerTime() - NWB.db.global.rendRespawnTime)) then
			msg = "(" .. L["rend"] .. ": " .. NWB:getTimeString(NWB.db.global.rendRespawnTime - (GetServerTime() - NWB.data.rendTimer), true) .. ") ";
		else
			msg = "(" .. L["rend"] .. ": " .. L["noCurrentTimer"] .. ") ";
		end
	end
	if ((NWB.data.onyNpcDied > NWB.data.onyTimer) and
			(NWB.data.onyNpcDied > (GetServerTime() - NWB.db.global.onyRespawnTime))) then
		if (faction == "Horde") then
			msg = msg .. "(Onyxia: NPC (Runthak) was killed " .. NWB:getTimeString(GetServerTime() - NWB.data.onyNpcDied, true) 
					.. " ago no buff recorded since) ";
		else
			msg = msg .. "(Onyxia: NPC (Mattingly) was killed " .. NWB:getTimeString(GetServerTime() - NWB.data.onyNpcDied, true) 
					.. " ago no buff recorded since) ";
		end
	elseif (NWB.data.onyTimer > (GetServerTime() - NWB.db.global.onyRespawnTime)) then
		msg = msg .. "(" .. L["onyxia"] .. ": " .. NWB:getTimeString(NWB.db.global.onyRespawnTime - (GetServerTime() - NWB.data.onyTimer), true) .. ") ";
	else
		msg = msg .. "(" .. L["onyxia"] .. ": " .. L["noCurrentTimer"] .. ") ";
	end
	if ((NWB.data.nefNpcDied > NWB.data.nefTimer) and
			(NWB.data.nefNpcDied > (GetServerTime() - NWB.db.global.nefRespawnTime))) then
		if (faction == "Horde") then
			msg = msg .. "(Nefarian: NPC (Saurfang) was killed " .. NWB:getTimeString(GetServerTime() - NWB.data.nefNpcDied, true) 
					.. " ago no buff recorded since)";
		else
			msg = msg .. "(Nefarian: NPC (Afrasiabi) was killed " .. NWB:getTimeString(GetServerTime() - NWB.data.nefNpcDied, true) 
					.. " ago no buff recorded since)";
		end
	elseif (NWB.data.nefTimer > (GetServerTime() - NWB.db.global.nefRespawnTime)) then
		msg = msg .. "(" .. L["nefarian"] .. ": " .. NWB:getTimeString(NWB.db.global.nefRespawnTime - (GetServerTime() - NWB.data.nefTimer), true) .. ")";
	else
		msg = msg .. "(" .. L["nefarian"] .. ": " .. L["noCurrentTimer"] .. ")";
	end
	return msg;
end

--Add prefix and colors from db then print.
function NWB:print(msg, channel)
	if (channel) then
		channel = string.lower(channel);
	end
	if (channel == "group" or channel == "team") then
		channel = "party";
	end
	if (channel == "gchat" or channel == "gmsg") then
		channel = "guild";
	end
	if (channel == "say" or channel == "yell" or channel == "party" or channel == "guild" or channel == "officer" or channel == "raid") then
		--If posting to a specifed channel then advertise addon name in prefix, more people that have the addon then more accurate the data is.
		local prefix = "[NovaWorldBuffs]";
		if (channel == "guild") then
			prefix = "[WorldBuffs]";
		end
		SendChatMessage(prefix .. " " .. NWB:stripColors(msg), channel);
	elseif (tonumber(channel)) then
		--Send to numbered channel by number.
		local id, name = GetChannelName(channel);
		if (id == 0) then
			print("|cFFFFFF00No channel with id |cFFFF5100" .. channel .. " |cFFFFFF00exists.");
			print("|cFFFFFF00Type \"/wb\" to print world buff timers to yourself.");
			print("|cFFFFFF00Type \"/wb config\" to open options.");
			print("|cFFFFFF00Type \"/wb guild\" to post buff timers to the specified chat channel (accepts channel names and numbers).");
			print("|cFFFFFF00Use \"/sf\" in the same way for songflowers.");
			return;
		end
		local prefix = "[NovaWorldBuffs]";
		SendChatMessage(prefix .. " " .. NWB:stripColors(msg), "CHANNEL", nil, id);
	elseif (channel ~= nil) then
		--Send to numbered channel by name.
		local id, name = GetChannelName(channel);
		if (id == 0) then
			print("|cFFFFFF00No channel with name |cFFFF5100" .. channel .. " |cFFFFFF00exists.");
			print("|cFFFFFF00Type \"/wb\" to print world buff timers to yourself.");
			print("|cFFFFFF00Type \"/wb config\" to open options.");
			print("|cFFFFFF00Type \"/wb guild\" to post buff timers to the specified chat channel (accepts channel names and numbers).");
			print("|cFFFFFF00Use \"/sf\" in the same way for songflowers.");
			return;
		end
		local prefix = "[NovaWorldBuffs]";
		SendChatMessage(prefix .. " " .. NWB:stripColors(msg), "CHANNEL", nil, id);
	else
		local prefix = "|cFFFF5100[WorldBuffs]|r";
		print(prefix .. " " .. NWB.chatColor .. msg);
	end
end

NWB.types = {
	[1] = "rend",
	[2] = "ony",
	[3] = "nef"
};

--1 second looping function for timer warning msgs.
function NWB:ticker()
	for k, v in pairs(NWB.types) do
		local offset = 0;
		if (v == "rend") then
			offset = NWB.db.global.rendRespawnTime;
		elseif (v == "ony") then
			offset = NWB.db.global.onyRespawnTime;
		elseif (v == "nef") then
			offset = NWB.db.global.nefRespawnTime;
		end
		local secondsLeft = (NWB.data[v .. "Timer"] + offset) - GetServerTime();
		--This looks messy but when checking (secondsLeft == 0) it would sometimes skip, not sure why.
		--This gives it a 2 second window instead of 1.
		if (NWB.data[v .. "0"] and secondsLeft <= 0 and secondsLeft >= -1) then
			NWB.data[v .. "0"] = nil;
			NWB:doWarning(v, 0, secondsLeft);
		elseif (NWB.data[v .. "1"] and secondsLeft <= 60 and secondsLeft >= 59) then
			NWB.data[v .. "1"] = nil;
			NWB:doWarning(v, 1, secondsLeft);
		elseif (NWB.data[v .. "5"] and secondsLeft <= 300  and secondsLeft >= 299) then
			NWB.data[v .. "5"] = nil;
			NWB:doWarning(v, 5, secondsLeft);
		elseif (NWB.data[v .. "10"] and secondsLeft <= 600  and secondsLeft >= 599) then
			NWB.data[v .. "10"] = nil;
			NWB:doWarning(v, 10, secondsLeft);
		elseif (NWB.data[v .. "15"] and secondsLeft <= 900 and secondsLeft >= 899) then
			NWB.data[v .. "15"] = nil;
			NWB:doWarning(v, 15, secondsLeft);
		elseif (NWB.data[v .. "30"] and secondsLeft <= 1800 and secondsLeft >= 1799) then
			NWB.data[v .. "30"] = nil;
			NWB:doWarning(v, 30, secondsLeft);
		end
	end
	C_Timer.After(1, function()
		NWB:ticker();
	end)
end

function NWB:yellTicker()
	C_Timer.After(180, function()
		--Msg inside the timer so it doesn't send first tick at logon, player entering world does that.
		C_Timer.After(5, function()
			NWB.doFilterAddonChatMsg = false;
		end)
		local inInstance, instanceType = IsInInstance();
		if (not UnitInBattleground("player") and inInstance ~= "raid") then
			NWB:sendData("YELL");
		end
		NWB.doFilterAddonChatMsg = true;
		NWB:yellTicker();
	end)
end

--Filter addon comm warnings from yell for 5 seconds after sending a yell.
--Even though we only send 1 msg every few minutes I think it can still trigger this msg if a large amount of people are in 1 spot.
--Even if it triggers this msg the data still got out there to most people, it will spread just fine over time.
--"yell" msgs possibly don't just send 1 msg to the server but instead loop through every player close and send 1 by 1?
NWB.doFilterAddonChatMsg = false;
local function filterAddonChatMsg(self, event, msg, author, ...)
	if (NWB.doFilterAddonChatMsg) then
		--The number of messages that can be sent is limited, please wait to send another message.
		if (string.find(msg, ERR_CHAT_THROTTLED)) then
			return true;
    	end
    end
end
ChatFrame_AddMessageEventFilter("CHAT_MSG_SYSTEM", filterAddonChatMsg);

--Send warnings to channels selected in options.
function NWB:doWarning(type, num, secondsLeft)
	local send = true;
	local buff;
	if (type == "rend") then
		buff = L["rend"];
		if (faction ~= "Horde" and not NWB.db.global.allianceEnableRend) then
			--We only send rend timer warnings to alliance if they have enabled it.
			send = nil;
		end
	elseif (type == "ony") then
		buff = L["onyxia"];
	elseif (type == "nef") then
		buff = L["nefarian"];
	end
	local msg;
	if (num == 0) then
		msg = string.format(L["newBuffCanBeDropped"], buff);
	else
		msg = string.format(L["buffResetsIn"], buff, NWB:getTimeString(secondsLeft, true));
	end
	if ((type == "ony" and NWB.data.onyNpcDied > NWB.data.onyTimer)
			or (type == "nef" and (NWB.data.nefNpcDied > NWB.data.nefTimer))) then
		--If npc killed timestamp is newer than last set time then don't send any warnings.
		return;	
	end
	--Chat.
	if (NWB.db.global.chat30 and num == 30 and send) then
		NWB:print(msg);
	elseif (NWB.db.global.chat15 and num == 15 and send) then
		NWB:print(msg);
	elseif (NWB.db.global.chat10 and num == 10 and send) then
		NWB:print(msg);
	elseif (NWB.db.global.chat5 and num == 5 and send) then
		NWB:print(msg);
	elseif (NWB.db.global.chat1 and num == 1 and send) then
		NWB:print(msg);
	elseif (NWB.db.global.chat0 and num == 0 and send) then
		NWB:print(msg);
	end
	--Middle of the screen.
	local colorTable = {r = self.db.global.middleColorR, g = self.db.global.middleColorG, 
			b = self.db.global.middleColorB, id = 41, sticky = 0};
	if (NWB.db.global.middle30 and num == 30 and send) then
		RaidNotice_AddMessage(RaidWarningFrame, NWB:stripColors(msg), colorTable, 5);
	elseif (NWB.db.global.middle15 and num == 15 and send) then
		RaidNotice_AddMessage(RaidWarningFrame, NWB:stripColors(msg), colorTable, 5);
	elseif (NWB.db.global.middle10 and num == 10 and send) then
		RaidNotice_AddMessage(RaidWarningFrame, NWB:stripColors(msg), colorTable, 5);
	elseif (NWB.db.global.middle5 and num == 5 and send) then
		RaidNotice_AddMessage(RaidWarningFrame, NWB:stripColors(msg), colorTable, 5);
	elseif (NWB.db.global.middle1 and num == 1 and send) then
		RaidNotice_AddMessage(RaidWarningFrame, NWB:stripColors(msg), colorTable, 5);
	elseif (NWB.db.global.middle0 and num == 0 and send) then
		RaidNotice_AddMessage(RaidWarningFrame, NWB:stripColors(msg), colorTable, 5);
	end
	--Guild.
	if (NWB.db.global.guild30 and num == 30 and send) then
		NWB:sendGuildMsg(msg, "guild30");
	elseif (NWB.db.global.guild15 and num == 15 and send) then
		NWB:sendGuildMsg(msg, "guild15");
	elseif (NWB.db.global.guild10 and num == 10 and send) then
		NWB:sendGuildMsg(msg, "guild10");
	elseif (NWB.db.global.guild5 and num == 5 and send) then
		NWB:sendGuildMsg(msg, "guild5");
	elseif (NWB.db.global.guild1 and num == 1 and send) then
		NWB:sendGuildMsg(msg, "guild1");
	elseif (NWB.db.global.guild0 and num == 0 and send) then
		NWB:sendGuildMsg(msg, "guild0");
	end
end

--Only one person online at a time sends guild msgs so there's no spam, chosen by alphabetical order.
--Can also specify zone so only 1 person from that zone will send the msg (like orgrimmar when npc yell goes out).
function NWB:sendGuildMsg(msg, type, zoneName)
	if (NWB.db.global.disableAllGuildMsgs) then
		return;
	end
	if (not IsInGuild()) then
		return;
	end
	GuildRoster();
	local numTotalMembers = GetNumGuildMembers();
	local onlineMembers = {};
	local me = UnitName("player") .. "-" .. GetNormalizedRealmName();
	for i = 1, numTotalMembers do
		local name, _, _, _, _, zone, _, _, online, _, _, _, _, isMobile = GetGuildRosterInfo(i);
		if (zoneName) then
			if (name and zone == zoneName and online and NWB.hasAddon[name] and not isMobile) then
				--If guild member is in zone specified and online and has addon installed add to temp table.
				--Not currently used anywhere, was removed.
				onlineMembers[name] = true;
			end
		elseif (type) then
			--If type then check our db for other peoples settings to ignore them in online list if they have this type disabled.
			if (name and online and NWB.hasAddon[name] and not isMobile) then
				if (NWB.data[name]) then
					--If another guild member check thier settings.
					if (NWB.data[name][type] == true and NWB.data[name].disableAllGuildMsgs ~= true) then
						--Has addon and has this type of msg type option enabled.
						onlineMembers[name] = true;
					end
				elseif (name == me) then
					--If myself check my settings.
					if (NWB.db.global[type] == true and NWB.db.global.disableAllGuildMsgs ~= true) then
						onlineMembers[name] = true;
					end
				end
			end
		else
			if (name and online and NWB.hasAddon[name] and not isMobile) then
				--If guild member is online and has addon installed add to temp table.
				onlineMembers[name] = true;
			end
		end
	end
	--Check temp table to see if we're first in alphabetical order.
	for k, v in NWB:pairsByKeys(onlineMembers) do
		if (k == me) then
			SendChatMessage("[WorldBuffs] " .. NWB:stripColors(msg), "guild");
		end
		return;
	end
end

--Guild chat msg event.
function NWB:chatMsgGuild(...)
	local msg = ...;
	msg = string.lower(msg);
	if (string.match(msg, "^!wb") and NWB.db.global.guildCommand) then
		NWB:sendGuildMsg(NWB:getShortBuffTimers(), "guildCommand");
	end
end

function NWB:monsterYell(...)
	--Skip strict string matching yell msgs for regions we haven't localized yet.
	--This could result in less accurate timers but better than no timers at all.
	local locale = GetLocale();
	local skipStringCheck;
	if (faction == "Horde") then
		if (locale == "frFR" or locale == "ptBR" or locale == "koKR" or locale == "esES" or locale == "esMX" or locale == "itIT") then
			skipStringCheck = true;
		end
	end
	if (faction == "Alliance") then
		if (locale == "frFR" or locale == "ptBR" or locale == "koKR" or locale == "esES" or locale == "esMX" or locale == "itIT"
				or locale == "ruRU" or locale == "deDE") then
			skipStringCheck = true;
		end
	end
	local msg, name = ...;
	if ((name == L["Thrall"] or name == L["Herald of Thrall"])
			and (string.match(msg, L["Rend Blackhand, has fallen"]) or skipStringCheck)) then
		--6 seconds between first rend yell and buff applied.
		NWB.data.rendYell = GetServerTime();
		NWB:doFirstYell("rend");
		--Send first yell msg to guild so people in org see it, needed because 1 person online only will send msg.
		NWB:sendYell("GUILD", "rend");
		if  (name == L["Herald of Thrall"]) then
			--If it was herald we may we in the barrens but not in crossraods to receive buff, set buff timer.
			C_Timer.After(5, function()
				NWB:setRendBuff("self", UnitName("player"));
			end)
		end
	elseif ((name == L["Thrall"] or name == L["Herald of Thrall"])
			and string.match(msg, "Be bathed in my power")) then
		--Second yell right before drops "Be bathed in my power! Drink in my might! Battle for the glory of the Horde!".
		NWB:debug("rend yell 2");
		NWB.data.rendYell2 = GetServerTime();
	elseif ((name == L["Overlord Runthak"] and (string.match(msg, L["Onyxia, has been slain"]) or skipStringCheck))
			or (name == L["Major Mattingly"] and (string.match(msg, L["history has been made"]) or skipStringCheck))) then
		--14 seconds between first ony yell and buff applied.
		NWB.data.onyYell = GetServerTime();
		NWB:doFirstYell("ony");
		--Send first yell msg to guild so people in org see it, needed because 1 person online only will send msg.
		NWB:sendYell("GUILD", "ony");
	elseif ((name == L["Overlord Runthak"] and string.match(msg, L["Be lifted by the rallying cry"]))
			or (name == L["Major Mattingly"] and string.match(msg, L["Onyxia, hangs from the arches"]))) then
		--Second yell right before drops "Be lifted by the rallying cry of your dragon slayers".
		NWB:debug("ony yell 2");
		NWB.data.onyYell2 = GetServerTime();
	elseif ((name == L["High Overlord Saurfang"] and (string.match(msg, L["NEFARIAN IS SLAIN"]) or skipStringCheck))
		 	or (name == L["Field Marshal Afrasiabi"] and (string.match(msg, L["the Lord of Blackrock is slain"]) or skipStringCheck))) then
		--15 seconds between first nef yell and buff applied.
		NWB.data.nefYell = GetServerTime();
		NWB:doFirstYell("nef");
		--Send first yell msg to guild so people in org see it, needed because 1 person online only will send msg.
		NWB:sendYell("GUILD", "nef");
	elseif ((name == L["High Overlord Saurfang"] and string.match(msg, L["Revel in his rallying cry"]))
			or (name == L["Field Marshal Afrasiabi"] and string.match(msg, L["Revel in the rallying cry"]))) then
		--Second yell right before drops "Be lifted by PlayerName's accomplishment! Revel in his rallying cry!".
		NWB:debug("nef yell 2");
		NWB.data.nefYell2 = GetServerTime();
	end
end

--Post first yell warning to guild chat, shared by all different addon comms so no overlap.
local rendFirstYell, onyFirstYell, nefFirstYell = 0, 0, 0;
function NWB:doFirstYell(type)
	if (type == "rend") then
		if ((GetServerTime() - rendFirstYell) > 120) then
			--6 seconds from rend first yell to buff drop.
			NWB.data.rendYell = GetServerTime();
			if (NWB.db.global.guildNpcDialogue  and (faction == "Horde" or NWB.db.global.allianceEnableRend)) then
				NWB:sendGuildMsg(L["rendFirstYellMsg"], "guildNpcDialogue");
			end
			rendFirstYell = GetServerTime();
		end
	elseif (type == "ony") then
		if ((GetServerTime() - onyFirstYell) > 120) then
			--14 seconds from ony first yell to buff drop.
			NWB.data.onyYell = GetServerTime();
			if (NWB.db.global.guildNpcDialogue) then
				NWB:sendGuildMsg(L["onyxiaFirstYellMsg"], "guildNpcDialogue");
			end
			onyFirstYell = GetServerTime();
		end
	elseif (type == "nef") then
		if ((GetServerTime() - nefFirstYell) > 120) then
			--15 seconds from nef first yell to buff drop.
			NWB.data.nefYell = GetServerTime();
			if (NWB.db.global.guildNpcDialogue) then
				NWB:sendGuildMsg(L["nefarianFirstYellMsg"], "guildNpcDialogue");
			end
			nefFirstYell = GetServerTime();
		end
	end
end

function NWB:combatLogEventUnfiltered(...)
	local timestamp, subEvent, hideCaster, sourceGUID, sourceName, sourceFlags, sourceRaidFlags, destGUID, 
			destName, destFlags, destRaidFlags, _, spellName = CombatLogGetCurrentEventInfo();
	if (subEvent == "UNIT_DIED") then
		local _, _, zone = NWB.dragonLib:GetPlayerZonePosition();
		if ((zone == 1454 or zone == 1411) and destName == L["Overlord Runthak"]) then
			if (faction ~= "Horde") then
				return;
			end
			NWB.data.onyNpcDied = GetServerTime();
			if (NWB.db.global.guildNpcKilled) then
				SendChatMessage("[WorldBuffs] " .. L["onyxiaNpcKilledHorde"], "guild");
			end
			NWB:print(L["onyxiaNpcKilledHorde"]);
			NWB:timerCleanup();
			NWB:sendData("GUILD");
			NWB:sendData("YELL"); --Yell is further than npc view range.
		elseif ((zone == 1454 or zone == 1411) and destName == L["High Overlord Saurfang"]) then
			if (faction ~= "Horde") then
				return;
			end
			NWB.data.nefNpcDied = GetServerTime();
			if (NWB.db.global.guildNpcKilled) then
				SendChatMessage("[WorldBuffs] " .. L["nefarianNpcKilledHorde"], "guild");
			end
			NWB:print(L["nefarianNpcKilledHorde"]);
			NWB:timerCleanup();
			NWB:sendData("GUILD");
			NWB:sendData("YELL"); --Yell is further than npc view range.
		elseif ((zone == 1453 or zone == 1429) and destName == L["Major Mattingly"]) then
			if (faction ~= "Alliance") then
				return;
			end
			NWB.data.onyNpcDied = GetServerTime();
			if (NWB.db.global.guildNpcKilled) then
				SendChatMessage("[WorldBuffs] " .. L["onyxiaNpcKilledAlliance"], "guild");
			end
			NWB:print(L["onyxiaNpcKilledAlliance"]);
			NWB:timerCleanup();
			NWB:sendData("GUILD");
			NWB:sendData("YELL"); --Yell is further than npc view range.
		elseif ((zone == 1453 or zone == 1429) and destName == L["Field Marshal Afrasiabi"]) then
			if (faction ~= "Alliance") then
				return;
			end
			NWB.data.nefNpcDied = GetServerTime();
			if (NWB.db.global.guildNpcKilled) then
				SendChatMessage("[WorldBuffs] " .. L["nefarianNpcKilledAlliance"], "guild");
			end
			NWB:print(L["nefarianNpcKilledAlliance"]);
			NWB:timerCleanup();
			NWB:sendData("GUILD");
			NWB:sendData("YELL"); --Yell is further than npc view range.
		end
	elseif (subEvent == "SPELL_AURA_APPLIED" or subEvent == "SPELL_AURA_REFRESH") then
		local _, _, _, _, _, npcID = strsplit("-", sourceGUID);
		if (destName == UnitName("player") and spellName == L["Warchief's Blessing"]) then
			local expirationTime = NWB:getBuffDuration(L["Warchief's Blessing"], 1);
			if (expirationTime >= 3599.5) then
				NWB:setRendBuff("self", UnitName("player"));
			end
			NWB:debug(expirationTime);
		elseif ((npcID == "14720" or npcID == "14721") and destName == UnitName("player") and spellName == L["Rallying Cry of the Dragonslayer"]
				and ((GetServerTime() - NWB.data.nefYell2) < 60 or (GetServerTime() - NWB.data.nefYell) < 60)) then
			--To tell the difference between nef and ony we check if there a nef npc yell recently, if not then fall back to ony.
			--1 minute is the buff window after 2nd yell to allow for mass lag.
			--Doubt any server would drop both heads within 1min of each other.
			local expirationTime = NWB:getBuffDuration(L["Rallying Cry of the Dragonslayer"], 2);
			if (expirationTime >= 7199.5) then
				NWB:setNefBuff("self", UnitName("player"));
			end
			NWB:debug(expirationTime);
		elseif ((npcID == "14392" or npcID == "14394")and destName == UnitName("player") and spellName == L["Rallying Cry of the Dragonslayer"]
				and ((GetServerTime() - NWB.data.onyYell2) < 60 or (GetServerTime() - NWB.data.onyYell) < 60)
				and ((GetServerTime() - NWB.data.nefYell2) > 60)) then
			local expirationTime = NWB:getBuffDuration(L["Rallying Cry of the Dragonslayer"], 2);
			if (expirationTime >= 7199.5) then
				NWB:setOnyBuff("self", UnitName("player"));
			end
			NWB:debug(expirationTime);
		end
	end
end

local rendLastSet, onyLastSet, nefLastSet = 0, 0, 0;
function NWB:setRendBuff(source, sender)
	--Check if this addon has already set a timer a few seconds before another addon's comm.
	if (source ~= "self" and (GetServerTime() - NWB.data.rendTimer) < 10) then
		return;
	end
	if (not NWB:validateNewTimer("rend", source)) then
		NWB:debug("failed rend timer validation", source);
		return;
	end
	NWB.data.rendTimer = GetServerTime();
	NWB.data.rendTimerWho = sender;
	NWB.data.rendSource = source;
	NWB:resetWarningTimers("rend");
	NWB:sendData("GUILD");
	--Once per drop one guild member will say in chat it dropped.
	--Throddle the drop msg for when we get multiple sources at the same drop time.
	if ((GetServerTime() - rendLastSet) > 120) then
		if (NWB.db.global.guildBuffDropped and (faction == "Horde" or NWB.db.global.allianceEnableRend)) then
			NWB:sendGuildMsg(L["rendBuffDropped"], "guildBuffDropped");
		end
	end
	rendLastSet = GetServerTime();
	NWB:debug("set rend buff", source);
end

function NWB:setOnyBuff(source, sender)
	--Ony and nef share a last set cooldown to prevent any bugs with both being set at once.
	if ((GetServerTime() - nefLastSet) < 20) then
		return;
	end
	if (source ~= "self" and (GetServerTime() - NWB.data.onyTimer) < 10) then
		return;
	end
	if (not NWB:validateNewTimer("ony", source)) then
		NWB:debug("failed ony timer validation", source);
		return;
	end
	NWB.data.onyTimer = GetServerTime();
	NWB.data.onyTimerWho = sender;
	NWB.data.onyNpcDied = 0;
	NWB.data.onySource = source;
	NWB:resetWarningTimers("ony");
	NWB:sendData("GUILD");
	if ((GetServerTime() - onyLastSet) > 120) then
		if (NWB.db.global.guildBuffDropped) then
			NWB:sendGuildMsg(L["onyxiaBuffDropped"], "guildBuffDropped");
		end
	end
	onyLastSet = GetServerTime();
	NWB:debug("set ony buff", source);
end

function NWB:setNefBuff(source, sender)
	--Ony and nef share a last set cooldown to prevent any bugs with both being set at once.
	if ((GetServerTime() - onyLastSet) < 20) then
		return;
	end
	if (source ~= "self" and (GetServerTime() - NWB.data.nefTimer) < 10) then
		return;
	end
	if (not NWB:validateNewTimer("nef", source)) then
		NWB:debug("failed nef timer validation", source);
		return;
	end
	NWB.data.nefTimer = GetServerTime();
	NWB.data.nefTimerWho = sender;
	NWB.data.nefNpcDied = 0;
	NWB.data.nefSource = source;
	NWB:resetWarningTimers("nef");
	NWB:sendData("GUILD");
	if ((GetServerTime() - nefLastSet) > 120) then
		if (NWB.db.global.guildBuffDropped) then
			NWB:sendGuildMsg(L["nefarianBuffDropped"], "guildBuffDropped");
		end
	end
	nefLastSet = GetServerTime();
	NWB:debug("set nef buff", source);
end

--Validate new timer, mostly used for testing blanket fixes for timers.
function NWB:validateNewTimer(type, source, timestamp)
	if (type == "rend") then
		return true;
	elseif (type == "ony") then
		if (source == "dbm") then
			local timer = NWB.data.onyTimer;
			local respawnTime = NWB.db.global.onyRespawnTime;
			if ((timer - 30) > (GetServerTime() - respawnTime) and not (NWB.data.onyNpcDied > timer)) then
				--Don't set dbm timers if valid timer already exists (current bug).
				NWB:debug("trying to set timer from dbm when timer already exists");
				return;
			end
		end
		if (NWB.data.nefTimer == timestamp or NWB.data.nefTimer == GetServerTime()) then
			NWB:debug("ony trying to set exact same timer as nef", source);
			--Make sure ony never syncs with nef time stamp (current bug).
			return;
		end
	elseif (type == "nef") then
		if (NWB.data.onyTimer == timestamp or NWB.data.onyTimer == GetServerTime()) then
			NWB:debug("nef trying to set exact same timer as ony", source);
			--Make sure nef never syncs with ony time stamp (current bug).
			return;
		end
	end
	return true;
end

--Make sure warning msg values are correct for the current time left on each timer.
function NWB:timerCleanup()
	local types = {
		[1] = "rend",
		[2] = "ony",
		[3] = "nef"
	};
	for k, v in pairs(types) do
		local offset = 0;
		if (v == "rend") then
			offset = NWB.db.global.rendRespawnTime;
			NWB:resetWarningTimers("rend");
		elseif (v == "ony") then
			offset = NWB.db.global.onyRespawnTime;
			NWB:resetWarningTimers("ony");
		elseif (v == "nef") then
			offset = NWB.db.global.nefRespawnTime;
			NWB:resetWarningTimers("nef");
		end
		--Clear warning timers that ended while we were offline or if NPC was killed since last buff.
		if (NWB.data[v .. "NpcDied"] and NWB.data[v .. "NpcDied"] > (GetServerTime() - NWB.db.global[v .. "RespawnTime"])) then
			NWB.data[v .. "30"] = nil;
			NWB.data[v .. "15"] = nil;
			NWB.data[v .. "10"] = nil;
			NWB.data[v .. "5"] = nil;
			NWB.data[v .. "1"] = nil;
			NWB.data[v .. "0"] = nil;
		elseif (((NWB.data[v .. "Timer"] + offset) - GetServerTime()) < 0) then
			NWB.data[v .. "30"] = nil;
			NWB.data[v .. "15"] = nil;
			NWB.data[v .. "10"] = nil;
			NWB.data[v .. "5"] = nil;
			NWB.data[v .. "1"] = nil;
			NWB.data[v .. "0"] = nil;
		elseif (((NWB.data[v .. "Timer"] + offset) - GetServerTime()) < 60) then
			NWB.data[v .. "30"] = nil;
			NWB.data[v .. "15"] = nil;
			NWB.data[v .. "10"] = nil;
			NWB.data[v .. "5"] = nil;
			NWB.data[v .. "1"] = nil;
		elseif (((NWB.data[v .. "Timer"] + offset) - GetServerTime()) < 300) then
			NWB.data[v .. "30"] = nil;
			NWB.data[v .. "15"] = nil;
			NWB.data[v .. "10"] = nil;
			NWB.data[v .. "5"] = nil;
		elseif (((NWB.data[v .. "Timer"] + offset) - GetServerTime()) < 600) then
			NWB.data[v .. "30"] = nil;
			NWB.data[v .. "15"] = nil;
			NWB.data[v .. "10"] = nil;
		elseif (((NWB.data[v .. "Timer"] + offset) - GetServerTime()) < 900) then
			NWB.data[v .. "30"] = nil;
			NWB.data[v .. "15"] = nil;
		elseif (((NWB.data[v .. "Timer"] + offset) - GetServerTime()) < 1800) then
			NWB.data[v .. "30"] = nil;
		end
	end
end

--Reset and enable all warning msgs for specified timer.
function NWB:resetWarningTimers(type)
	NWB.data[type .. "30"] = true;
	NWB.data[type .. "15"] = true;
	NWB.data[type .. "10"] = true;
	NWB.data[type .. "5"] = true;
	NWB.data[type .. "1"] = true;
	NWB.data[type .. "0"] = true;
end

local f = CreateFrame("Frame");
f:RegisterEvent("PLAYER_ENTERING_WORLD");
f:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED");
f:RegisterEvent("CHAT_MSG_MONSTER_YELL");
f:RegisterEvent("GROUP_JOINED");
f:RegisterEvent("CHAT_MSG_GUILD");
local doLogon = true;
f:SetScript("OnEvent", function(self, event, ...)	
	if (event == "PLAYER_ENTERING_WORLD") then
		if (doLogon) then
			GuildRoster();
			if (NWB.db.global.logonPrint) then
				C_Timer.After(10, function()
					GuildRoster(); --Attempting to fix slow guild roster update at logon.
					NWB:printBuffTimers();
				end);
			end
			--If WorldBuffTimers isn't installed then send it's data request to guild.
			if (not WorldBuffTracker_HandleSync and IsInGuild()) then
				C_ChatInfo.SendAddonMessage("WBT-0", 11326, "GUILD");
			end
			--First request after logon is high prio so gets sent right away, need to register addon users asap so no duplicate guild msgs.
			NWB:requestData("GUILD", nil, "ALERT");
			--This fixes a bug with hovering over icons on first map opening.
			WorldMapFrame:Show();
			WorldMapFrame:SetMapID(1448);
			WorldMapFrame:Hide();
			doLogon = nil;
		end
		NWB:sendData("YELL");
	elseif (event == "COMBAT_LOG_EVENT_UNFILTERED") then
		NWB:combatLogEventUnfiltered(...);
	elseif (event == "CHAT_MSG_MONSTER_YELL") then
		NWB:monsterYell(...);
	elseif (event == "GROUP_JOINED") then
		C_Timer.After(5, function()
			if (UnitInBattleground("player")) then
				return;
			end
			if (IsInRaid()) then
  				NWB:sendData("RAID");
  			elseif (IsInGroup()) then
  				NWB:sendData("PARTY");
  			end
  		end)
  	elseif (event == "CHAT_MSG_GUILD") then
  		NWB:chatMsgGuild(...);
	end
end)

--Flight paths.
local doCheckLeaveFlghtPath = false;
hooksecurefunc("TakeTaxiNode", function(...)
	doCheckLeaveFlghtPath = true;
    --Give it a few seconds to get on the taxi.
    C_Timer.After(5, function()
		NWB.checkLeaveFlghtPath();
		--Wipe felwood songflower detected players when leaving.
		NWB.detectedPlayers = {};
	end)
	NWB:sendData("YELL");
end)

--Loop this func till flight path is left.
function NWB.checkLeaveFlghtPath()
    local isOnFlightPath = UnitOnTaxi("player");
    if (not isOnFlightPath) then
    	doCheckLeaveFlghtPath = false;
    	--Send data to people close when dismounting a flightpath.
    	NWB:sendData("YELL");
    end
    if (doCheckLeaveFlghtPath) then
    	C_Timer.After(2, function()
			NWB.checkLeaveFlghtPath();
		end)
	end
end

--WorldBuffTracker.
--[[C_ChatInfo.RegisterAddonMessagePrefix("WBT-0");
C_ChatInfo.RegisterAddonMessagePrefix("WBT-1");
C_ChatInfo.RegisterAddonMessagePrefix("WBT-2");
C_ChatInfo.RegisterAddonMessagePrefix("WBT-3");
C_ChatInfo.RegisterAddonMessagePrefix("WBT-A");
--DMB4.
C_ChatInfo.RegisterAddonMessagePrefix("D4C");
--Bigwigs.
C_ChatInfo.RegisterAddonMessagePrefix("BigWigs");
--Fade.
--C_ChatInfo.RegisterAddonMessagePrefix("FADEWT-5");]]

--Convert seconds to a readable format.
function NWB:getTimeString(seconds, countOnly, short)
	local timecalc = 0;
	if (countOnly) then
		timecalc = seconds;
	else
		timecalc = seconds - time();
	end
	local d = math.floor((timecalc % (86400*7)) / 86400)
	local h = math.floor((timecalc % 86400) / 3600);
	local m = math.floor((timecalc % 3600) / 60);
	local s = math.floor((timecalc % 60));
	if (short) then
		if (d == 1 and h == 0) then
			return d .. L["dayShort"];
		elseif (d == 1) then
			return d .. L["dayShort"] .. h .. L["hourShort"];
		end
		if (d > 1 and h == 0) then
			return d .. L["dayShort"];
		elseif (d > 1) then
			return d .. L["dayShort"] .. h .. L["hourShort"];
		end
		if (h == 1 and m == 0) then
			return h .. L["hourShort"];
		elseif (h == 1) then
			return h .. L["hourShort"] .. m .. L["minuteShort"];
		end
		if (h > 1 and m == 0) then
			return h .. L["hourShort"];
		elseif (h > 1) then
			return h .. L["hourShort"] .. m .. L["minuteShort"];
		end
		if (m == 1 and s == 0) then
			return m .. L["minuteShort"];
		elseif (m == 1) then
			return m .. L["minuteShort"] .. s .. L["secondShort"];
		end
		if (m > 1 and s == 0) then
			return m .. L["minuteShort"];
		elseif (m > 1) then
			return m .. L["minuteShort"] .. s .. L["secondShort"];
		end
		--If no matches it must be seconds only.
		return s .. L["secondShort"];
	else
		if (d == 1 and h == 0) then
			return d .. " " .. L["day"];
		elseif (d == 1) then
			return d .. " " .. L["day"] .. " " .. h .. " " .. L["hours"];
		end
		if (d > 1 and h == 0) then
			return d .. " " .. L["days"];
		elseif (d > 1) then
			return d .. " " .. L["days"] .. " " .. h .. " " .. L["hours"];
		end
		if (h == 1 and m == 0) then
			return h .. " " .. L["hour"];
		elseif (h == 1) then
			return h .. " " .. L["hour"] .. " " .. m .. " " .. L["minutes"];
		end
		if (h > 1 and m == 0) then
			return h .. " " .. L["hours"];
		elseif (h > 1) then
			return h .. " " .. L["hours"] .. " " .. m .. " " .. L["minutes"];
		end
		if (m == 1 and s == 0) then
			return m .. " " .. L["minute"];
		elseif (m == 1) then
			return m .. " " .. L["minute"] .. " " .. s .. " " .. L["seconds"];
		end
		if (m > 1 and s == 0) then
			return m .. " " .. L["minutes"];
		elseif (m > 1) then
			return m .. " " .. L["minutes"] .. " " .. s .. " " .. L["seconds"];
		end
		--If no matches it must be seconds only.
		return s .. " " .. L["seconds"];
	end
end

--Returns am/pm and lt/st format.
function NWB:getTimeFormat(timeStamp)
	if (NWB.db.global.timeStampZone == "server") then
		local data = date("*t", GetServerTime());
		local localHour, localMin = data.hour, data.min;
		local serverHour, serverMin = GetGameTime();
		local localSecs = (localMin*60) + ((localHour*60)*60);
		local serverSecs = (serverMin*60) + ((serverHour*60)*60);
		local diff = localSecs - serverSecs;
		local serverTime = 0;
		if (localHour < serverHour) then
			timeStamp = timeStamp - (diff + 86400);
		else
			timeStamp = timeStamp - diff;
		end
	end
	if (NWB.db.global.timeStampFormat == 12) then
		--Strip leading zero and convert to lowercase am/pm.
		return gsub(string.lower(date("%I:%M%p", timeStamp)), "^0", "");
	else
		return date("%H:%M:%S", timeStamp);
	end
end

--Accepts both types of RGB.
function NWB:RGBToHex(r, g, b)
	r = tonumber(r);
	g = tonumber(g);
	b = tonumber(b);
	--Check if whole numbers.
	if (r == math.floor(r) and g == math.floor(g) and b == math.floor(b)) then
		r = r <= 255 and r >= 0 and r or 0;
		g = g <= 255 and g >= 0 and g or 0;
		b = b <= 255 and b >= 0 and b or 0;
		return string.format("%02x%02x%02x", r, g, b);
	else
		return string.format("%02x%02x%02x", r*255, g*255, b*255);
	end
end

--English buff names, we check both english and locale names for buff durations just to be sure in untested locales.
local englishBuffs = {
	[1] = "Warchief's Blessing",
	[2] = "Rallying Cry of the Dragonslayer",
	[3] = "Songflower Serenade",
}

--Get seconds left on a buff by name.
function NWB:getBuffDuration(buff, englishID)
	for i = 1, 32 do
		local name, _, _, _, _, expirationTime = UnitBuff("player", i);
		if ((name and name == buff) or (englishID and name == englishBuffs[englishID])) then
			return expirationTime - GetTime();
		end
	end
	return 0;
end

--Check if player is in guild, accepts full realm name and normalized.
function NWB:isPlayerInGuild(who, onlineOnly)
	if (not IsInGuild()) then
		return;
	end
	GuildRoster();
	local numTotalMembers = GetNumGuildMembers();
	local normalizedWho = string.gsub(who, " ", "");
	normalizedWho = string.gsub(normalizedWho, "'", "");
	local me = UnitName("player") .. "-" .. GetRealmName();
	local normalizedMe = UnitName("player") .. "-" .. GetNormalizedRealmName();
	if (who == me or who == normalizedMe) then
		return true;
	end
	for i = 1, numTotalMembers do
		local name, _, _, _, _, _, _, _, online, _, _, _, _, isMobile = GetGuildRosterInfo(i);
		if (onlineOnly) then
			if (name and (name == who or name == normalizedWho) and online and not isMobile) then
				return true;
			end
		else
			if (name and (name == who or name == normalizedWho)) then
				return true;
			end
		end
	end
end

--PHP explode type function.
function NWB:explode(div, str, count)
	if (div == '') then
		return false;
	end
	local pos,arr = 0,{};
	local index = 0;
	for st, sp in function() return string.find(str, div, pos, true) end do
		index = index + 1;
 		table.insert(arr, string.sub(str, pos, st-1));
		pos = sp + 1;
		if (count and index == count) then
			table.insert(arr, string.sub(str, pos));
			return arr;
		end
	end
	table.insert(arr, string.sub(str, pos));
	return arr;
end

--Iterate table keys in alphabetical order.
function NWB:pairsByKeys(t, f)
	local a = {};
	for n in pairs(t) do
		table.insert(a, n);
	end
	table.sort(a, f);
	local i = 0;
	local iter = function()
		i = i + 1;
		if (a[i] == nil) then
			return nil;
		else
			return a[i], t[a[i]];
		end
	end
	return iter;
end

--Strip escape strings from chat msgs.
function NWB:stripColors(str)
	local escapes = {
    	["|c%x%x%x%x%x%x%x%x"] = "", --Color start.
    	["|r"] = "", --Color end.
    	["|H.-|h(.-)|h"] = "%1", --Links.
    	["|T.-|t"] = "", --Textures.
    	["{.-}"] = "", --Raid target icons.
	};
	if (str) then
    	for k, v in pairs(escapes) do
        	str = gsub(str, k, v);
    	end
    end
    return str;
end

function NWB:dmfTimestamps(month)
	--Create current date table.
	local data = date("*t", GetServerTime());
	local dmfStartDay;
	for i = 1, 7 do
		--Iterate the first 7 days in the month to find first friday.
		local time = date("*t", time({year = data.year, month = data.month, day = i}));
		if (time.wday == 6) then
			--If day of the week (wday) is 6 (friday) then set this as first friday of the month.
			dmfStartDay = i;
		end
	end
	local time = time({year = data.year, month = data.month, day = dmfStartDay, hour = 0, sec = 1});
	--Add 3 days and 3 hours to get 2nd monday 3am start time (needs region adjustments added).
	local dmfStart = time + 270000;
	--Add 6 days to get following sunday end timestamp.
	local dmfEnd = dmfStart + 518400;
	return dmfStart, dmfEnd;
end

function NWB:dmfTimeLeft()
	local dmfStart, dmfEnd = NWB:dmfTimestamps();
	--OCE region only just for now.
	if (realm == "Arugal" or realm == "Felstriker" or realm == "Remulos" or realm == "Yojamba") then
		if (GetServerTime() < dmfStart) then
			--If before the start of dmf.
			local timeString = NWB:getTimeString(dmfStart - GetServerTime(), true);
			NWB:debug("dmf start", timeString)
		elseif (GetServerTime() < dmfEnd) then
			--After dmf starts and before the end.
			local timeString = NWB:getTimeString(dmfEnd - GetServerTime(), true);
			NWB:debug("dmf end", timeString)
		elseif (GetServerTime() > dmfEnd) then
			--After dmf ended so calc next months dmf instead.
			local data = date("*t", GetServerTime());
			if (data.month == 12) then
				dmfStart, dmfEnd = NWB:dmfTimestamps(1);
			else
				dmfStart, dmfEnd = NWB:dmfTimestamps(data.month + 1);
			end
			NWB:debug("dmf nextmonth", timeString)
		end
	end
end

function NWB:debug(...)
	if (NWB.isDebug) then
		if (type(...) == "table") then
			UIParentLoadAddOn('Blizzard_DebugTools');
			DevTools_Dump(...);
    		--DisplayTableInspectorWindow(...);
    	else
			print("NWBDebug:", ...);
		end
	end
end

SLASH_NWBCMD1, SLASH_NWBCMD2, SLASH_NWBCMD3, SLASH_NWBCMD4, SLASH_NWBCMD5, SLASH_NWBCMD6 
		= '/nwb', '/novaworldbuff', '/novaworldbuffs', '/wb', '/worldbuff', '/worldbuffs';
function SlashCmdList.NWBCMD(msg, editBox)
	if (msg) then
		msg = string.lower(msg);
	end
	if (msg == "group" or msg == "team") then
		msg = "party";
	end
	if (msg == "map") then
		WorldMapFrame:Show();
		if (faction == "Alliance") then
			WorldMapFrame:SetMapID(1453);
		else
			WorldMapFrame:SetMapID(1454);
		end
		return;
	end
	if (msg == "options" or msg == "option" or msg == "config" or msg == "menu") then
		--Opening the frame needs to be run twice to avoid a bug.
		InterfaceOptionsFrame_OpenToCategory("NovaWorldBuffs");
		--Hack to fix the issue of interface options not opening to menus below the current scroll range.
		--This addon name starts with N and will always be closer to the middle so just scroll to the middle when opening.
		local min, max = InterfaceOptionsFrameAddOnsListScrollBar:GetMinMaxValues();
		if (min < max) then
			InterfaceOptionsFrameAddOnsListScrollBar:SetValue(math.floor(max/2));
		end
		InterfaceOptionsFrame_OpenToCategory("NovaWorldBuffs");
	elseif (msg ~= nil and msg ~= "") then
		NWB:print(NWB:getShortBuffTimers(), msg);
	else
		NWB:printBuffTimers();
	end
end

-------------
---Options---
-------------

NWB.options = {
	name = "|TInterface\\AddOns\\NovaWorldBuffs\\Media\\logo32:24:24:0:5|t NovaWorldBuffs v" .. GetAddOnMetadata("NovaWorldBuffs", "Version"),
	handler = NWB,
	type = 'group',
	args = {
		desc = {
			type = "description",
			name = "|CffDEDE42World Buffs Config (You can type /wb config to open this).\n"
					.. "Type /wb to display timers to yourself.\n"
					.. "Type /wb <channel> to display timers to the spcified channel.\n"
					.. "Scroll down for more options.",
			fontSize = "medium",
			order = 1,
		},
		colorHeader = {
			type = "header",
			name = "General Options",
			order = 2,
		},
		logonPrint = {
			type = "toggle",
			name = "Logon Timers",
			desc = "Show timers in the chat window when you log on.",
			order = 3,
			get = "getLogonPrint",
			set = "setLogonPrint",
		},
		disableAllGuildMsgs = {
			type = "toggle",
			name = "Disable Guild Msgs",
			desc = "Disable all guild messages including timers and when buffs drop? Note: You can disable all msgs 1 by 1 below and "
					.. "just leave certain things enabled such as the !wb command to help out your guild if you rather.",
			order = 4,
			get = "getDisableAllGuildMsgs",
			set = "setDisableAllGuildMsgs",
		},
		receiveGuildDataOnly  = {
			type = "toggle",
			name = "Guild Data Only",
			desc = "This will make it so you don't get timer data from anyone outside the guild. You should only enable this "
					.. "if you think someone is spoofing wrong timer data on purpose because it will lower the accuracy of your timers "
					.. "with less people to pull data from. It will make it especially hard to get songflower timers becaus "
					.. "they are so short.",
			order = 4,
			get = "getReceiveGuildDataOnly",
			set = "setReceiveGuildDataOnly",
		},
		chatColor = {
			type = "color",
			name = "Chat Msg Color",
			desc = "What color should the timer msgs in chat be?",
			order = 5,
			get = "getChatColor",
			set = "setChatColor",
			hasAlpha = false,
		},
		middleColor = {
			type = "color",
			name = "Middle Screen Color",
			desc = "What color should the raid warning style msgs in the middle of the screen be?",
			order = 6,
			get = "getMiddleColor",
			set = "setMiddleColor",
			hasAlpha = false,
		},
		resetColors = {
			type = "execute",
			name = "Reset Colors",
			desc = "Reset colors back to default.",
			func = "resetColors",
			order = 7,
		},
		showTimeStamp = {
			type = "toggle",
			name = "Show Time Stamp",
			desc = "Show a time stamp (1:23pm) beside the timer msg?",
			order = 8,
			get = "getShowTimeStamp",
			set = "setShowTimeStamp",
		},
		timeStampFormat = {
			type = "select",
			name = "Time Stamp Format",
			desc = "Set which timestamp format to use, 12 hour (1:23pm) or 24 hour (13:23).",
			values = {
				[12] = "12 hour",
				[24] = "24 hour",
			},
			sorting = {
				[1] = 12,
				[2] = 24,
			},
			order = 9,
			get = "getTimeStampFormat",
			set = "setTimeStampFormat",
		},
		timeStampZone = {
			type = "select",
			name = "Local Time / Server Time",
			desc = "Use local time or server time for timestamps?",
			values = {
				["local"] = "Local Time",
				["server"] = "Server Time",
			},
			sorting = {
				[1] = "local",
				[2] = "server",
			},
			order = 10,
			get = "getTimeStampZone",
			set = "setTimeStampZone",
		},
		showWorldMapMarkers = {
			type = "toggle",
			name = "City Map Timers",
			desc = "Show timer icons on the Orgrimmar/Stormwind world map?",
			order = 11,
			get = "getShowWorldMapMarkers",
			set = "setShowWorldMapMarkers",
		},
		chatWarningHeader = {
			type = "header",
			name = "Chat Window Timer Warnings",
			order = 20,
		},
		chat30 = {
			type = "toggle",
			name = "30 Minutes",
			desc = "Print a msg in chat when 30 minutes left.",
			order = 21,
			get = "getChat30",
			set = "setChat30",
		},
		chat15 = {
			type = "toggle",
			name = "15 Minutes",
			desc = "Print a msg in chat when 15 minutes left.",
			order = 22,
			get = "getChat15",
			set = "setChat15",
		},
		chat10 = {
			type = "toggle",
			name = "10 Minutes",
			desc = "Print a msg in chat when 10 minutes left.",
			order = 23,
			get = "getChat10",
			set = "setChat10",
		},
		chat5 = {
			type = "toggle",
			name = "5 Minutes",
			desc = "Print a msg in chat when 5 minutes left.",
			order = 24,
			get = "getChat5",
			set = "setChat5",
		},
		chat1 = {
			type = "toggle",
			name = "1 Minute",
			desc = "Print a msg in chat when 1 minute left.",
			order = 25,
			get = "getChat1",
			set = "setChat1",
		},
		chatReset = {
			type = "toggle",
			name = "Buff Has Reset",
			desc = "Print a msg in chat when a buff has reset and a new one can be dropped.",
			order = 26,
			get = "getChat0",
			set = "setChat0",
		},
		middleWarningHeader = {
			type = "header",
			name = "Middle Of The Screen Timer Warnings",
			order = 30,
		},
		middle30 = {
			type = "toggle",
			name = "30 Minutes",
			desc = "Show a raid warning style msg in the middle of the screen when 30 minutes left.",
			order = 31,
			get = "getMiddle30",
			set = "setMiddle30",
		},
		middle15 = {
			type = "toggle",
			name = "15 Minutes",
			desc = "Show a raid warning style msg in the middle of the screen when 15 minutes left.",
			order = 32,
			get = "getMiddle15",
			set = "setMiddle15",
		},
		middle10 = {
			type = "toggle",
			name = "10 Minutes",
			desc = "Show a raid warning style msg in the middle of the screen when 10 minutes left.",
			order = 33,
			get = "getMiddle10",
			set = "setMiddle10",
		},
		middle5 = {
			type = "toggle",
			name = "5 Minutes",
			desc = "Show a raid warning style msg in the middle of the screen when 5 minutes left.",
			order = 34,
			get = "getMiddle5",
			set = "setMiddle5",
		},
		middle1 = {
			type = "toggle",
			name = "1 Minute",
			desc = "Show a raid warning style msg in the middle of the screen when 1 minute left.",
			order = 35,
			get = "getMiddle1",
			set = "setMiddle1",
		},
		middleReset = {
			type = "toggle",
			name = "Buff Has Reset",
			desc = "Show a raid warning style msg in the middle of the screen when a buff has reset and a new one can be dropped.",
			order = 36,
			get = "getMiddle0",
			set = "setMiddle0",
		},
		guildWarningHeader = {
			type = "header",
			name = "Guild Message Timer Warnings",
			order = 40,
		},
		guild30 = {
			type = "toggle",
			name = "30 Minutes",
			desc = "Send a message to guild chat when 30 minutes left.",
			order = 41,
			get = "getGuild30",
			set = "setGuild30",
		},
		guild15 = {
			type = "toggle",
			name = "15 Minutes",
			desc = "Send a message to guild chat when 15 minutes left.",
			order = 42,
			get = "getGuild15",
			set = "setGuild15",
		},
		guild10 = {
			type = "toggle",
			name = "10 Minutes",
			desc = "Send a message to guild chat when 10 minutes left.",
			order = 43,
			get = "getGuild10",
			set = "setGuild10",
		},
		guild5 = {
			type = "toggle",
			name = "5 Minutes",
			desc = "Send a message to guild chat when 5 minutes left.",
			order = 44,
			get = "getGuild5",
			set = "setGuild5",
		},
		guild1 = {
			type = "toggle",
			name = "1 Minute",
			desc = "Send a message to guild chat when 1 minute left.",
			order = 45,
			get = "getGuild1",
			set = "setGuild1",
		},
		guildReset = {
			type = "toggle",
			name = "Buff Has Reset",
			desc = "Send a message to guild chat when a buff has reset and a new one can be dropped.",
			order = 46,
			get = "getGuild0",
			set = "setGuild0",
		},
		guildNpcDialogue = {
			type = "toggle",
			name = "NPC Dialogue Started",
			desc = "Send a message to guild when someone hands in a head and the NPC first yells and you still have time to relog if fast?",
			order = 47,
			get = "getGuildNpcDialogue",
			set = "setGuildNpcDialogue",
		},
		guildBuffDropped = {
			type = "toggle",
			name = "New Buff Dropped",
			desc = "Send a message to guild when a new buff has been dropped? This msg is sent after the NPC is finished yelling "
					.. " and you get the actual buff a few seconds later. (6 seconds after first yell for rend, 14 seconds for ony, "
					.. " 15 seconds for nef)",
			order = 48,
			get = "getGuildBuffDropped",
			set = "setGuildBuffDropped",
		},
		guildNpcKilled = {
			type = "toggle",
			name = "NPC Was Killed",
			desc = "Send a message to guild when one of the buff NPC's were killed in Orgrimmar or Stormwind? (mind control reset).",
			order = 49,
			get = "getGuildNpcKilled",
			set = "setGuildNpcKilled",
		},
		guildCommand = {
			type = "toggle",
			name = "!wb Guild Command",
			desc = "Reply with timer info to a !wb command in guild chat? You should probably leave this enabled to help your guild, " 
					.. "if you really want to disable all guild msgs and leave only this command then untick everything else and don't tick "
					.. "the Disable All Guild Msgs at the top.",
			order = 50,
			get = "getGuildCommand",
			set = "setGuildCommand",
		},
		songflowers = {
			type = "header",
			name = "Songflowers",
			order = 60,
		},
		guildSongflower = {
			type = "toggle",
			name = "Tell Guild When Picked",
			desc = "Tell your guild chat when you have picked a songflower with the time of next spawn?",
			order = 61,
			get = "getGuildSongflower",
			set = "setGuildSongflower",
		},
		mySongflowerOnly = {
			type = "toggle",
			name = "Only When I Pick",
			desc = "Only record a new timer when I pick a songflower and not when others pick infront of me? This option is here "
					.. "just incase you have problems with false timers being set from other players. There's currently "
					.. "no way to tell if another players buff is new so a timer may trigger on rare occasions if the game loads "
					.. "the songflower buff on someone else when they logon infront of you beside a songflower.",
			order = 62,
			get = "getMySongflowerOnly",
			set = "setMySongflowerOnly",
		},
		syncFlowersAll = {
			type = "toggle",
			name = "Sync Flowers With All",
			desc = "Enable this to override the guild only data setting at the top of this config so you can share songflower "
					.. "data outside the guild but keep worldbuff data guild only still.",
			order = 63,
			get = "getSyncFlowersAll",
			set = "setSyncFlowersAll",
		},
		showNewFlower = {
			type = "toggle",
			name = "New Flower Timers",
			desc = "This will show you in chat window when a new flower timer is found from another player not in your guild "
					.. " (guild msgs already show in guild chat when a flower is picked).",
			order = 64,
			get = "getShowNewFlower",
			set = "setShowNewFlower",
		},
		showSongflowerWorldmapMarkers = {
			type = "toggle",
			name = "Songflower Worldmap",
			desc = "Show songflower icons on the world map?.",
			order = 65,
			get = "getShowSongflowerWorldmapMarkers",
			set = "setShowSongflowerWorldmapMarkers",
		},
		showSongflowerMinimapMarkers = {
			type = "toggle",
			name = "Songflower Minimap",
			desc = "Show songflower icons on the mini map?.",
			order = 66,
			get = "getShowSongflowerMinimapMarkers",
			set = "setShowSongflowerMinimapMarkers",
		},
	},
};

function NWB:loadFactionSpecificOptions()
	if (faction == "Alliance") then
		NWB.options.args["allianceEnableRend"] = {
			type = "toggle",
			name = "Enable Alliance Rend",
			desc = "Enable this to track rend as Alliance, for guilds that mind control to get rend buff. If you use this then everyone in "
					.. "the guild with the addon should enable it or guild chat msgs may not work properly (personal timer msgs will still work).";
			order = 19,
			get = "getAllianceEnableRend",
			set = "setAllianceEnableRend",
		};
	end
end

------------------------
--Load option defaults--
------------------------
NWB.optionDefaults = {
	global = {
		chatColorR = 255, chatColorG = 255, chatColorB = 0,
		middleColorR = 1, middleColorG = 0.96, middleColorB = 0.41,
		logonPrint = true,
		chatWarning = true,
		middleScreenWarning = true,
		chat30 = true,
		chat15 = false,
		chat10 = true,
		chat5 = false,
		chat1 = true,
		chat0 = true,
		middle30 = true,
		middle15 = false,
		middle10 = true,
		middle5 = false,
		middle1 = true,
		middle0 = true,
		guild30 = false,
		guild15 = false,
		guild10 = true,
		guild5 = false,
		guild1 = true,
		guild0 = false,
		rendRespawnTime = 10800,
		onyRespawnTime = 21600,
		nefRespawnTime = 28800,
		syncVicinity = true,
		lastVersionMsg = 0,
		showTimeStamp = true,
		timeStampFormat = 12,
		timeStampZone = "local",
		guildNpcKilled = true,
		guildBuffDropped = true,
		guildNpcDialogue = true,
		guildCommand = true,
		disableAllGuildMsgs = false,
		receiveGuildDataOnly = false,
		guildSongflower = true,
		mySongflowerOnly = false,
		syncFlowersAll = true,
		allianceEnableRend = false,
		showWorldMapMarkers = true,
		showSongflowerWorldmapMarkers = true,
		showSongflowerMinimapMarkers = true,
		showNewFlower = true,
	},
};

--Configuraton options are shared but buff data is realm and faction specific so I store timer data seperately.
--Config options = NWB.db.global (ace3)
--Timer data = NWB.data
function NWB:buildRealmFactionData()
	local defaults = {
		rendTimer = 0,
		rendYell = 0,
		rendYell2 = 0,
		onyTimer = 0,
		onyYell = 0,
		onyYell2 = 0,
		onyNpcDied = 0,
		nefTimer = 0,
		nefYell = 0,
		nefYell2 = 0,
		nefNpcDied = 0,
		flower1 = 0,
		flower2 = 0,
		flower3 = 0,
		flower4 = 0,
		flower5 = 0,
		flower6 = 0,
		flower7 = 0,
		flower8 = 0,
		flower9 = 0,
		flower10 = 0,
	};
	--Create realm and faction tables if they don't exist.
	if (not self.db.global[realm]) then
			self.db.global[realm] = {};
	end
	if (not self.db.global[realm][faction]) then
			self.db.global[realm][faction] = {};
	end
	for k, v in pairs(defaults) do
		if (not self.db.global[realm][faction][k]) then
			--Add default values if no value is already set.
			self.db.global[realm][faction][k] = v;
		end
	end
	--Timer data is stored within the ace3 global table but I create a shortcut here "NWB.data".
	self.data = self.db.global[realm][faction];
end

--Print timers to chat window at logon time.
function NWB:setLogonPrint(info, value)
	self.db.global.logonPrint = value;
end

function NWB:getLogonPrint(info)
	return self.db.global.logonPrint;
end

--Show a time stamp after the timers.
function NWB:setShowTimeStamp(info, value)
	self.db.global.showTimeStamp = value;
end

function NWB:getShowTimeStamp(info)
	return self.db.global.showTimeStamp;
end

--Which timestamp format to use 12h/24h.
function NWB:setTimeStampFormat(info, value)
	self.db.global.timeStampFormat = value;
end

function NWB:getTimeStampFormat(info)
	return self.db.global.timeStampFormat;
end

--Which timezone format to use local/server.
function NWB:setTimeStampZone(info, value)
	self.db.global.timeStampZone = value;
end

function NWB:getTimeStampZone(info)
	return self.db.global.timeStampZone;
end

--Show world map markers.
function NWB:setShowWorldMapMarkers(info, value)
	self.db.global.showWorldMapMarkers = value;
	NWB:refreshWorldbuffMarkers();
end

function NWB:getShowWorldMapMarkers(info)
	return self.db.global.showWorldMapMarkers;
end

--Enable rend timers for alliance.
function NWB:setAllianceEnableRend(info, value)
	self.db.global.allianceEnableRend = value;
	NWB:refreshWorldbuffMarkers();
end

function NWB:getAllianceEnableRend(info)
	return self.db.global.allianceEnableRend;
end

--Disable all guild msgs.
function NWB:setDisableAllGuildMsgs(info, value)
	self.db.global.disableAllGuildMsgs = value;
	NWB:sendData("GUILD");
end

function NWB:getDisableAllGuildMsgs(info)
	return self.db.global.disableAllGuildMsgs;
end

--Ignore data from outside the guild.
function NWB:setReceiveGuildDataOnly(info, value)
	self.db.global.receiveGuildDataOnly = value;
end

function NWB:getReceiveGuildDataOnly(info)
	return self.db.global.receiveGuildDataOnly;
end

--Chat color.
function NWB:setChatColor(info, r, g, b, a)
	self.db.global.chatColorR, self.db.global.chatColorG, self.db.global.chatColorB = r, g, b;
	NWB.chatColor = "|cff" .. NWB:RGBToHex(self.db.global.chatColorR, self.db.global.chatColorG, self.db.global.chatColorB);
end

function NWB:getChatColor(info)
	return self.db.global.chatColorR, self.db.global.chatColorG, self.db.global.chatColorB;
end

--Middle of screen color.
function NWB:setMiddleColor(info, r, g, b, a)
	self.db.global.middleColorR, self.db.global.middleColorG, self.db.global.middleColorB = r, g, b;
end

function NWB:getMiddleColor(info)
	return self.db.global.middleColorR, self.db.global.middleColorG, self.db.global.middleColorB;
end

--Reset colors.
function NWB:resetColors(info, r, g, b, a)
	self.db.global.chatColorR = self.optionDefaults.global.chatColorR;
	self.db.global.chatColorG = self.optionDefaults.global.chatColorG;
	self.db.global.chatColorB = self.optionDefaults.global.chatColorB;
	self.db.global.middleColorR = self.optionDefaults.global.middleColorR;
	self.db.global.middleColorG = self.optionDefaults.global.middleColorG;
	self.db.global.middleColorB = self.optionDefaults.global.middleColorB;
	NWB.chatColor = "|cff" .. NWB:RGBToHex(self.db.global.chatColorR, self.db.global.chatColorG, self.db.global.chatColorB);
end

--Chat 30 minute warning.
function NWB:setChat30(info, value)
	self.db.global.chat30 = value;
end

function NWB:getChat30(info)
	return self.db.global.chat30;
end

--Chat 15 minute warning.
function NWB:setChat15(info, value)
	self.db.global.chat15 = value;
end

function NWB:getChat15(info)
	return self.db.global.chat15;
end
--Chat 10 minute warning.
function NWB:setChat10(info, value)
	self.db.global.chat10 = value;
end

function NWB:getChat10(info)
	return self.db.global.chat10;
end
--Chat 5 minute warning.
function NWB:setChat5(info, value)
	self.db.global.chat5 = value;
end

function NWB:getChat5(info)
	return self.db.global.chat5;
end
--Chat 1 minute warning.
function NWB:setChat1(info, value)
	self.db.global.chat1 = value;
end

function NWB:getChat1(info)
	return self.db.global.chat1;
end
--Chat timer finished warning.
function NWB:setChat0(info, value)
	self.db.global.chat0 = value;
end

function NWB:getChat0(info)
	return self.db.global.chat0;
end

--Middle of the screen 30 minute warning.
function NWB:setMiddle30(info, value)
	self.db.global.middle30 = value;
end

function NWB:getMiddle30(info)
	return self.db.global.middle30;
end

--Middle of the screen 15 minute warning.
function NWB:setMiddle15(info, value)
	self.db.global.middle15 = value;
end

function NWB:getMiddle15(info)
	return self.db.global.middle15;
end

--Middle of the screen 10 minute warning.
function NWB:setMiddle10(info, value)
	self.db.global.middle10 = value;
end

function NWB:getMiddle10(info)
	return self.db.global.middle10;
end

--Middle of the screen 5 minute warning.
function NWB:setMiddle5(info, value)
	self.db.global.middle5 = value;
end

function NWB:getMiddle5(info)
	return self.db.global.middle5;
end

--Middle of the screen 1 minute warning.
function NWB:setMiddle1(info, value)
	self.db.global.middle1 = value;
end

function NWB:getMiddle1(info)
	return self.db.global.middle1;
end

--Middle of the screen 0 minute warning.
function NWB:setMiddle0(info, value)
	self.db.global.middle0 = value;
end

function NWB:getMiddle0(info)
	return self.db.global.middle0;
end

--Guild 30 minute warning.
function NWB:setGuild30(info, value)
	self.db.global.guild30 = value;
end

function NWB:getGuild30(info)
	return self.db.global.guild30;
end

--Guild 15 minute warning.
function NWB:setGuild15(info, value)
	self.db.global.guild15 = value;
end

function NWB:getGuild15(info)
	return self.db.global.guild15;
end

--Guild 10 minute warning.
function NWB:setGuild10(info, value)
	self.db.global.guild10 = value;
end

function NWB:getGuild10(info)
	return self.db.global.guild10;
end

--Guild 5 minute warning.
function NWB:setGuild5(info, value)
	self.db.global.guild5 = value;
end

function NWB:getGuild5(info)
	return self.db.global.guild5;
end

--Guild 1 minute warning.
function NWB:setGuild1(info, value)
	self.db.global.guild1 = value;
end

function NWB:getGuild1(info)
	return self.db.global.guild1;
end

--Guild 0 minute warning.
function NWB:setGuild0(info, value)
	self.db.global.guild0 = value;
end

function NWB:getGuild0(info)
	return self.db.global.guild0;
end

--Guild NPC dialogue started.
function NWB:setGuildNpcDialogue(info, value)
	self.db.global.guildNpcDialogue = value;
	NWB:sendData("GUILD");
end

function NWB:getGuildNpcDialogue(info)
	return self.db.global.guildNpcDialogue;
end

--Guild buff dropped.
function NWB:setGuildBuffDropped(info, value)
	self.db.global.guildBuffDropped = value;
	NWB:sendData("GUILD");
end

function NWB:getGuildBuffDropped(info)
	return self.db.global.guildBuffDropped;
end

--Guild NPC killed.
function NWB:setGuildNpcKilled(info, value)
	self.db.global.guildNpcKilled = value;
	NWB:sendData("GUILD");
end

function NWB:getGuildNpcKilled(info)
	return self.db.global.guildNpcKilled;
end

--Guild !wb command.
function NWB:setGuildCommand(info, value)
	self.db.global.guildCommand = value;
	NWB:sendData("GUILD");
end

function NWB:getGuildCommand(info)
	return self.db.global.guildCommand;
end

--Guild songflower picked announce.
function NWB:setGuildSongflower(info, value)
	self.db.global.guildSongflower = value;
end

function NWB:getGuildSongflower(info)
	return self.db.global.guildSongflower;
end

--Only set songflower timer if I picked it.
function NWB:setMySongflowerOnly(info, value)
	self.db.global.mySongflowerOnly = value;
end

function NWB:getMySongflowerOnly(info)
	return self.db.global.mySongflowerOnly;
end

--Sync songflowers on all channels when guild only is selected for data.
function NWB:setSyncFlowersAll(info, value)
	self.db.global.syncFlowersAll = value;
end

function NWB:getSyncFlowersAll(info)
	return self.db.global.syncFlowersAll;
end

--Sync songflowers on all channels when guild only is selected for data.
function NWB:setShowNewFlower(info, value)
	self.db.global.showNewFlower = value;
end

function NWB:getShowNewFlower(info)
	return self.db.global.showNewFlower;
end

--Show world map songflower markers.
function NWB:setShowSongflowerWorldmapMarkers(info, value)
	self.db.global.showSongflowerWorldmapMarkers = value;
	NWB:refreshSongflowerMarkers();
end

function NWB:getShowSongflowerWorldmapMarkers(info)
	return self.db.global.showSongflowerWorldmapMarkers;
end

--Show mini map songflower markers.
function NWB:setShowSongflowerMinimapMarkers(info, value)
	self.db.global.showSongflowerMinimapMarkers = value;
	NWB:refreshSongflowerMarkers();
end

function NWB:getShowSongflowerMinimapMarkers(info)
	return self.db.global.showSongflowerMinimapMarkers;
end

---Parse other world buff addons for increased accuracy and to spread more data around.
---Thanks to all authors for their work.
---If any of these authors ask me to stop parsing their comms I'll remove it.
function NWB:registerOtherAddons()
	--self:RegisterComm("FADEWT-5");
	--self:RegisterComm("WBT-0");
	--self:RegisterComm("WBT-1");
	--self:RegisterComm("WBT-2");
	--self:RegisterComm("WBT-3");
	--self:RegisterComm("WBT-A");
	self:RegisterComm("D4C");
end

--[[Parse WorldBuffTracker addon msgs.
function NWB:parseWorldBuffTracker(prefix, msg, channel, sender)
	local buffType, time, origin, _, _ = strsplit("_", msg);
	if (prefix == "WBT-1") then
		--Rend dropped while we're online, addon comm received without timestamp when buff received.
		--NWB:setRendBuff("wbt", sender);
	elseif (prefix == "WBT-2") then
		--Ony dropped while we're online, addon comm received without timestamp when buff received.
		--NWB:setOnyBuff("wbt", sender);
	elseif (prefix == "WBT-3") then
		--Nef dropped while we're online, addon comm received without timestamp when buff received.
		--NWB:setNefBuff("wbt", sender);
	elseif (prefix == "WBT-0") then
		--Timer sync addon comm received, timestamp is attached (can also be version check with no timestamp).
		--5 second delay check to not instantly overwrite if both addons are installed.
		if (buffType == "1" and tonumber(time) > (NWB.data.rendTimer + 5)) then
			--if (faction == "Horde") then
				if (not NWB:validateNewTimer("rend", "WorldBuffTracker", tonumber(time))) then
					NWB:debug("failed rend wbt timer validation", source);
					return;
				end
				NWB.data.rendTimer = tonumber(time);
				NWB.data.rendTimerWho = sender;
				NWB.data.rendSource = "WorldBuffTracker";
				NWB:resetWarningTimers("rend");
				NWB:timerCleanup();
				NWB:debug("WBT rend data received.");
			--end
		elseif (buffType == "2" and tonumber(time) > (NWB.data.onyTimer + 5)) then
			if ((GetServerTime() - nefLastSet) < 20) then
				NWB:debug("WBT trying to set ony within 20 secs of nef.");
				return;
			end
			if (not NWB:validateNewTimer("ony", "WorldBuffTracker", tonumber(time))) then
				NWB:debug("failed ony wbt timer validation", source);
				return;
			end
			NWB.data.onyTimer = tonumber(time);
			NWB.data.onyTimerWho = sender;
			NWB.data.onySource = "WorldBuffTracker";
			NWB:resetWarningTimers("ony");
			NWB:timerCleanup();
			NWB:debug("WBT ony data received.");
		elseif (buffType == "3" and tonumber(time) > (NWB.data.nefTimer + 5)) then
			if ((GetServerTime() - onyLastSet) < 20) then
				NWB:debug("WBT trying to set nef within 20 secs of ony.");
				return;
			end
			if (not NWB:validateNewTimer("nef", "WorldBuffTracker", tonumber(time))) then
				NWB:debug("failed nef wbt timer validation", source);
				return;
			end
			NWB.data.nefTimer = tonumber(time);
			NWB.data.nefTimerWho = sender;
			NWB.data.nefSource = "WorldBuffTracker";
			NWB:resetWarningTimers("nef");
			NWB:timerCleanup();
			NWB:debug("WBT nef data received.");
		elseif (tonumber(msg)) then
			--Version check.
		end
	elseif (prefix == "WBT-A") then
		--NPC first yell msg before buff drop.
		if (buffType == "1") then
			NWB:doFirstYell("rend");
		elseif (buffType == "2") then
			NWB:doFirstYell("ony");
		elseif (buffType == "3") then
			NWB:doFirstYell("nef");
		end
	else
		NWB:debug("Unknown WorldBuffTracker msg: ", prefix, sender, msg);
	end
end]]

--DBM.
local dbmLastRend, dbmLastOny, dbmLastNef = 0, 0, 0;
function NWB:parseDBM(prefix, msg, channel, sender)
	--Strings.
	--D4C WBA	rendBlackhand	Horde	Warchief's Blessing	59 GUILD
	--D4C WBA	Onyxia	Horde	Rallying Cry of the Dragonslayer	15 GUILD
	--D4C WBA	Nefarian	Horde	Rallying Cry of the Dragonslayer	17 GUILD
	--Same exact string comes from DBM for both yell msgs so disabled timer delay for now.
	if (string.match(msg, "rendBlackhand") and string.match(msg, "Warchief's Blessing")) then
		NWB:doFirstYell("rend");
		--6 seconds between DBM comm (first npc yell) and rend buff drop.
		if (GetServerTime() - dbmLastRend > 30) then
			C_Timer.After(7, function()
				NWB:setRendBuff("dbm", sender);
			end)
			dbmLastRend = GetServerTime();
		end
	end
	--I think maybe DBM is sending ony buff msg sometimes for nef, needs more testing.
	if (string.match(msg, "Onyxia") and string.match(msg, "Rallying Cry of the Dragonslayer")) then
		NWB:debug("DBM doing ony buff");
		NWB:doFirstYell("ony");
		--14 seconds between DBM comm (first npc yell) and buff drop.
		if (GetServerTime() - dbmLastOny > 30) then
			C_Timer.After(15, function()
				NWB:setOnyBuff("dbm", sender);
			end)
			dbmLastOny = GetServerTime();
		end
	end
	if (string.match(msg, "Nefarian") and string.match(msg, "Rallying Cry of the Dragonslayer")) then
		NWB:doFirstYell("nef");
		--15 seconds between DBM comm (first npc yell) and buff drop.
		if (GetServerTime() - dbmLastNef > 30) then
			C_Timer.After(16, function()
				NWB:setNefBuff("dbm", sender);
			end)
			dbmLastNef = GetServerTime();
		end
	end
end

function NWB:parseBigWigs(prefix, msg, channel, sender)
	--NWB:debug("bigwigs", prefix, msg, channel, sender);
end

--Parse FADE addon comms.
--[[Addon comms only get sent on first yell msg and not when buff drops it seems?
function NWB:parseFade(prefix, msg, channel, sender)
	local deserializeResult, deserialized = Serializer:Deserialize(msg);
	if (not deserializeResult) then
		--Some data fade sends doesn't seem to be serialized but it's not data we use anyway.
		NWB:debug("Fade Error deserializing:", msg);
		return;
	end
	local rend, ony, nef = 0, 0, 0;
	if (faction == "Horde") then
		--Orgrimmar map id 1454.
		if (deserialized['FADEWT-WCB3']) then
			rend = deserialized['FADEWT-WCB3']['1454'] or 0;
		end
		if (deserialized['FADEWT-ONY4']) then
			ony = deserialized['FADEWT-ONY4']['1454'] or 0;
		end
		if (deserialized['FADEWT-NEF4']) then
			nef = deserialized['FADEWT-NEF4']['1454'] or 0;
		end
    else
    	--Stormwind map id 1453.
    	if (deserialized['FADEWT-WCB3']) then
			rend = deserialized['FADEWT-WCB3']['1453'] or 0;
		end
		if (deserialized['FADEWT-ONY4']) then
			ony = deserialized['FADEWT-ONY4']['1453'] or 0;
		end
		if (deserialized['FADEWT-NEF4']) then
			nef = deserialized['FADEWT-NEF4']['1453'] or 0;
		end
    end
    --Fade timestamps are when the buff resets not when it was dropped so adjust it.
    rend = rend - NWB.db.global.rendRespawnTime;
    ony = ony - NWB.db.global.onyRespawnTime;
    nef = nef - NWB.db.global.nefRespawnTime;
    --5 second delay check to not instantly overwrite if both addons are installed.
    if (rend and rend > (NWB.data.rendTimer + 5)) then
    	if (not NWB:validateNewTimer("rend", "Fade", rend)) then
			NWB:debug("failed rend fade timer validation", source);
			return;
		end
		NWB.data.rendTimer = rend;
		NWB.data.rendTimerWho = sender;
		NWB.data.rendSource = "Fade";
		NWB:resetWarningTimers("rend");
		NWB:timerCleanup();
		NWB:debug("Fade rend data received.");
	end
	if (ony and ony > (NWB.data.onyTimer + 5)) then
		if ((GetServerTime() - nefLastSet) < 20) then
			NWB:debug("Fade trying to set ony within 20 secs of nef.");
			return;
		end
		if (not NWB:validateNewTimer("ony", "Fade", ony)) then
			NWB:debug("failed ony fade timer validation", source);
			return;
		end
		NWB.data.onyTimer = ony;
		NWB.data.onyTimerWho = sender;
		NWB.data.onySource = "Fade";
		NWB:resetWarningTimers("ony");
		NWB:timerCleanup();
		NWB:debug("Fade ony data received.");
	end
	if (nef and nef > (NWB.data.nefTimer + 5)) then
		if ((GetServerTime() - onyLastSet) < 20) then
			NWB:debug("Fade trying to set nef within 20 secs of ony.");
			return;
		end
		if (not NWB:validateNewTimer("nef", "Fade", nef)) then
			NWB:debug("failed nef fade timer validation", source);
			return;
		end
		NWB.data.nefTimer = nef;
		NWB.data.nefTimerWho = sender;
		NWB.data.nefSource = "Fade";
		NWB:resetWarningTimers("nef");
		NWB:timerCleanup();
		NWB:debug("Fade nef data received.");
	end
end]]

---TODO
--Add sync from bigwigs (if it has comms for world buffs?).
--Add Spirit of Zandalar (if it has a cooldown?).
--Darkmoon faire stuff.
--Add some sounds.
--Check Herald of Thrall yell contains our Thrall yell string segment for each locale.

---================---
---Songflower stuff---
---================---

function NWB:setSongFlowers()
	NWB.songFlowers = {
		--Songflowers in order from north to south.						--Coords taken from NWB.dragonLib:GetPlayerZonePosition().
		["flower1"] = {x = 63.9, y = 6.1, subZone = L["North Felpaw Village"]}, --x 63.907248382611, y 6.0921582958694
		["flower2"] = {x = 55.8, y = 10.4, subZone = L["West Felpaw Village"]}, --x 55.80811845313, y 10.438248169009
		["flower3"] = {x = 50.6, y = 13.9, subZone = L["North of Irontree Woods"]}, --x 50.575074328086, y 13.918245916971
		["flower4"] = {x = 63.3, y = 22.6, subZone = L["Talonbranch Glade"]}, -- x 63.336814849559, y 22.610425663249
		["flower5"] = {x = 40.1, y = 44.4, subZone = L["Shatter Scar Vale"]}, --x 40.142029982253, y 44.353905770542
		["flower6"] = {x = 34.3, y = 52.2, subZone = L["Bloodvenom Post"]}, --x 34.345508209303, y 52.179993391643
		["flower7"] = {x = 40.1, y = 56.5, subZone = L["East of Jaedenar"]}, --x 40.142029982253, y 56.523472021355
		["flower8"] = {x = 48.3, y = 75.7, subZone = L["North of Emerald Sanctuary"]}, -- x 48.260292045699, y 75.650435262435
		["flower9"] = {x = 45.9, y = 85.2, subZone = L["West of Emerald Sanctuary"]}, --x 45.942030228517, y 85.219126632059
		["flower10"] = {x = 52.9, y = 87.8, subZone = L["South of Emerald Sanctuary"]}, --x 52.893336145267, y 87.825217631218
	}
	if (faction == "Horde") then
		NWB.songFlowers.flower6.subZone = "Bloodvenom Post FP";
	end
end

SLASH_NWBSFCMD1, SLASH_NWBSFCMD2, SLASH_NWBSFCMD3, SLASH_NWBSFCMD4 = '/sf', '/sfs', '/songflower', '/songflowers';
function SlashCmdList.NWBSFCMD(msg, editBox)
	if (msg) then
		msg = string.lower(msg);
	end
	if (msg == "map") then
		WorldMapFrame:Show();
		WorldMapFrame:SetMapID(1448);
		return;
	end
	local string = "Songflowers:";
	local found;
	for k, v in pairs(NWB.songFlowers) do
		local time = (NWB.data[k] + 1500) - GetServerTime();
		if (time > 0) then
			local minutes = string.format("%02.f", math.floor(time / 60));
    		local seconds = string.format("%02.f", math.floor(time - minutes * 60));
			string = string .. " (" .. v.subZone .. " " .. minutes .. "m" .. seconds .. "s)";
			found = true;
  		end
	end
	if (not found) then
		string = string .. " " .. L["noActiveTimers"] .. ".";
	end
	if (msg ~= nil and msg ~= "") then
		NWB:print(string, msg);
	else
		NWB:print(string);
	end
end

NWB.detectedPlayers = {};
local f = CreateFrame("Frame")
f:RegisterEvent("PLAYER_TARGET_CHANGED");
f:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED");
f:RegisterEvent("PLAYER_ENTERING_WORLD");
f:SetScript('OnEvent', function(self, event, ...)
	if (event == "COMBAT_LOG_EVENT_UNFILTERED") then
		local _, _, zone = NWB.dragonLib:GetPlayerZonePosition();
		local timestamp, subEvent, hideCaster, sourceGUID, sourceName, sourceFlags, sourceRaidFlags, destGUID, 
				destName, destFlags, destRaidFlags, _, spellName = CombatLogGetCurrentEventInfo();
		if ((subEvent == "SPELL_AURA_APPLIED" or subEvent == "SPELL_AURA_REFRESH") and spellName == L["Songflower Serenade"]) then
			if (destName == UnitName("player")) then
				--If buff is ours we'll validate it's a new buff incase we logon beside a songflower with the buff.
				local expirationTime = NWB:getBuffDuration(L["Songflower Serenade"], 3)
				if (expirationTime >= 3599) then
					local closestFlower = NWB:getClosetSongflower();
					if (NWB.data[closestFlower]) then
						NWB:songflowerPicked(closestFlower);
					end
				end
			elseif (not NWB.db.global.mySongflowerOnly) then
				--If buff is not ours then we'll hope they didn't logon beside us at a songflower and set it.
				--There's an option to make it only set if it's our buff in /wb config.
				--I'll look for a way to tell if a player just entered our view or logged on later and check if buff is new that way.
				local closestFlower = NWB:getClosetSongflower();
				if (NWB.data[closestFlower]) then
					NWB:songflowerPicked(closestFlower, destName);
				end
			end
		end
		if (zone == 1448) then
			if (sourceName) then
				NWB.detectedPlayers[sourceName] = GetServerTime();
			elseif (destName) then
				NWB.detectedPlayers[destName] = GetServerTime();
			end
		end
	elseif (event == "PLAYER_TARGET_CHANGED") then
		local _, _, zone = NWB.dragonLib:GetPlayerZonePosition();
		if (zone == 1448) then
			local name = UnitName("target");
			if (name) then
				NWB.detectedPlayers[UnitName("target")] = GetServerTime();
			end
		end
	elseif (event == "PLAYER_ENTERING_WORLD") then
		--Wipe felwood songflower detected players when leaving, it costs very little to just wipe this on every zone.
		NWB.detectedPlayers = {};
	end
end)

--Check tooltips for players while waiting at the songflower, doesn't really matter if it adds non-player stuff, it gets wiped when leaving.
--This shouldn't be done OnUpdate but it will do for now and only happens in felwood.
--Not sure how to detect tooltip changed, OnShow doesn't work when tooltip changes before fading out.
--This whole thing is pretty ugly right now.
GameTooltip:HookScript("OnUpdate", function()
	--This may need some more work to handle custom tooltip addons like elvui etc.
	local _, _, zone = NWB.dragonLib:GetPlayerZonePosition();
	if (zone == 1448) then
		for i = 1, GameTooltip:NumLines() do
			local line =_G["GameTooltipTextLeft"..i];
			local text = line:GetText();
			if (text and text ~= nil and text ~= "") then
				local name;
				if (string.match(text, " ")) then
					name = NWB:stripColors(string.match(text, "%s(%S+)$"));
				else
					name = NWB:stripColors(text);
				end
				if (name) then
					NWB.detectedPlayers[name] = GetServerTime();
				end
			end
			--Iterate first line only.
			return;
		end
	end
end)

--I record some data to try and make sure if another player picked flower infront of us it's valid and not an old buff.
--Check if player has been seen before (avoid logon buff aura gained events).
--Check if there is already a valid timer for the songflower (they should never be reset except server restart?)
local pickedTime = 0;
function NWB:songflowerPicked(flower, otherPlayer)
	local _, _, zone = NWB.dragonLib:GetPlayerZonePosition();
	if (zone ~= 1448) then
		--We're not in felwood.
		return;
	end
	--If other player has not been seen before it may be someone logging in with the buff.
	if (otherPlayer and not NWB.detectedPlayers[otherPlayer]) then
		NWB:debug("Previously unseen player with buff:", otherPlayer);
		return;
	end
	if (otherPlayer and (GetServerTime() - NWB.detectedPlayers[otherPlayer] > 1500)) then
		NWB:debug("Player seen too long ago:", otherPlayer);
		return;
	end
	if ((GetServerTime() - pickedTime) > 5) then
		--Validate only if another player, we already check ours is valid by duration check.
		if (otherPlayer and NWB.data[flower] > (GetServerTime() - 1500)) then
			NWB:debug("Trying to overwrite a valid timer.");
			return;
		end
		NWB.data[flower] = GetServerTime();
		if (NWB.db.global.guildSongflower and not NWB.db.global.disableAllGuildMsgs) then
			SendChatMessage(string.format(L["songflowerPicked"], NWB.songFlowers[flower].subZone), "guild");
		end
		NWB:sendData("GUILD");
		NWB:sendData("YELL");
		pickedTime = GetServerTime();
	end
end

--Gets which songflower we are closest to, if we are actually beside one.
function NWB:getClosetSongflower()
	local x, y, zone = NWB.dragonLib:GetPlayerZonePosition();
	if (zone ~= 1448) then
		--We're not in felwood.
		return;
	end
	for k, v in pairs(NWB.songFlowers) do
		--The distance returned by this is actually much further than yards like is specifed on the addon page.
		--It returns 2 yards when I'm more like 50 yards away, it's good enough for this check anyway, songflowers aren't close together.
		--Seems it returns the distance in coords you are away not the distance in yards? 1 yard is smaller than x = 1.0 coord?
		local distance = NWB.dragonLib:GetWorldDistance(zone, x*100, y*100, v.x, v.y);
		if (distance <= 2) then
			return k;
		end
	end
end

--Update timers for Felwood worldmap when the map is open.
function NWB:updateWorldmapSongflower(flower)
	--Seconds left.
	local time = (NWB.data[flower] + 1500) - GetServerTime();
	if (time > 0) then
		--If timer is less than 25 minutes old then return time left.
    	local minutes = string.format("%02.f", math.floor(time / 60));
    	local seconds = string.format("%02.f", math.floor(time - minutes * 60));
    	_G[flower .. "NWB"].timerFrame:Show();
    	return minutes .. ":" .. seconds;
  	end
  	_G[flower .. "NWB"].timerFrame:Hide();
	return "";
end

--Update timer for minimap tooltip when icon is hovered over.
function NWB:updateMinimapSongflower(flower)
	--Seconds left.
	local time = (NWB.data[flower] + 1500) - GetServerTime();
	if (time > 0) then
		--If timer is less than 25 minutes old then return time left.
    	local minutes = string.format("%02.f", math.floor(time / 60));
    	local seconds = string.format("%02.f", math.floor(time - minutes * 60));
    	return minutes .. ":" .. seconds;
  	end
	return L["noTimer"];
end

function NWB:createSongflowerMarkers()
	local iconLocation = "Interface\\Icons\\spell_holy_mindvision";
	for k, v in pairs(NWB.songFlowers) do
		--Worldmap marker.
		local obj = CreateFrame("Frame", k .. "NWB", WorldMapFrame);
		obj.flower = k;
		local bg = obj:CreateTexture(nil, "MEDIUM");
		bg:SetTexture(iconLocation);
		bg:SetAllPoints(obj);
		obj.texture = bg;
		obj:SetSize(15, 15);
		--World map tooltip.
		obj.tooltip = CreateFrame("Frame", k.. "Tooltip", obj, "TooltipBorderedFrameTemplate");
		obj.tooltip:SetPoint("CENTER", 0, -36);
		obj.tooltip:SetFrameStrata("HIGH");
		obj.tooltip:SetFrameLevel(9);
		obj.tooltip.fs = obj.tooltip:CreateFontString(k .. "NWBTooltipFS", "ARTWORK");
		obj.tooltip.fs:SetPoint("CENTER", 0, 0);
		obj.tooltip.fs:SetFont("Fonts\\ARIALN.ttf", 12);
		obj.tooltip.fs:SetText("|CffDEDE42Songflower|r\n" .. v.subZone);
		obj.tooltip:SetWidth(obj.tooltip.fs:GetStringWidth() + 18);
		obj.tooltip:SetHeight(obj.tooltip.fs:GetStringHeight() + 12);
		obj:SetScript("OnEnter", function(self)
			obj.tooltip:Show();
		end)
		obj:SetScript("OnLeave", function(self)
			obj.tooltip:Hide();
		end)
		obj.tooltip:Hide();
		--Timer frame that sits above the icon when an active timer is found.
		obj.timerFrame = CreateFrame("Frame", k.. "TimerFrame", obj, "TooltipBorderedFrameTemplate");
		obj.timerFrame:SetPoint("CENTER", 0, 20);
		obj.timerFrame:SetFrameStrata("HIGH");
		obj.timerFrame:SetFrameLevel(9);
		obj.timerFrame.fs = obj.timerFrame:CreateFontString(k .. "NWBTimerFrameFS", "ARTWORK");
		obj.timerFrame.fs:SetPoint("CENTER", 0, 0);
		obj.timerFrame.fs:SetFont("Fonts\\ARIALN.ttf", 13);
		obj.timerFrame:SetWidth(42);
		obj.timerFrame:SetHeight(24);
		obj:SetScript("OnUpdate", function(self)
			--Update timer when map is open.
			obj.timerFrame.fs:SetText(NWB:updateWorldmapSongflower(obj.flower));
		end)
		
		--Minimap marker.
		local obj = CreateFrame("FRAME", k .. "NWBMini");
		obj.flower = k;
		local bg = obj:CreateTexture(nil, "MEDIUM");
		bg:SetTexture(iconLocation);
		bg:SetAllPoints(obj);
		obj.texture = bg;
		obj:SetSize(12, 12);
		--Minimap tooltip.
		obj.tooltip = CreateFrame("Frame", k.. "Tooltip", obj, "TooltipBorderedFrameTemplate");
		obj.tooltip:SetPoint("CENTER", 0, 18);
		obj.tooltip:SetFrameStrata("HIGH");
		obj.tooltip:SetFrameLevel(9);
		obj.tooltip.fs = obj.tooltip:CreateFontString(k .. "NWBTooltipFS", "ARTWORK");
		obj.tooltip.fs:SetPoint("CENTER", 0, 0);
		obj.tooltip.fs:SetFont("Fonts\\ARIALN.ttf", 12);
		obj.tooltip.fs:SetText("|CffDEDE42No Timer");
		obj.tooltip:SetWidth(obj.tooltip.fs:GetStringWidth() + 16);
		obj.tooltip:SetHeight(obj.tooltip.fs:GetStringHeight() + 11);
		obj:SetScript("OnEnter", function(self)
			obj.tooltip:Show();
		end)
		obj:SetScript("OnLeave", function(self)
			obj.tooltip:Hide();
		end)
		obj.tooltip:SetScript("OnUpdate", function(self)
			--Update timer when icon is hovered over and tooltip is shown.
			obj.tooltip.fs:SetText(NWB:updateMinimapSongflower(obj.flower));
		end)
		obj.tooltip:Hide();
	end
	NWB:refreshSongflowerMarkers();
	--Fix a bug with tooltips and first time opening the map.
	WorldMapFrame:Show();
	WorldMapFrame:SetMapID(1448);
	WorldMapFrame:Hide();
end

function NWB:refreshSongflowerMarkers()
	for k, v in pairs(NWB.songFlowers) do
		NWB.dragonLibPins:RemoveWorldMapIcon(k .. "NWB", _G[k .. "NWB"]);
		NWB.dragonLibPins:RemoveMinimapIcon(k .. "NWBMini", _G[k .. "NWBMini"]);
		if (NWB.db.global.showSongflowerWorldmapMarkers) then
			NWB.dragonLibPins:AddWorldMapIconMap(k .. "NWB", _G[k .. "NWB"], 1448, v.x/100, v.y/100);
		end
		if (NWB.db.global.showSongflowerMinimapMarkers) then
			NWB.dragonLibPins:AddMinimapIconMap(k .. "NWBMini", _G[k .. "NWBMini"], 1448, v.x/100, v.y/100);
		end
	end
end

---====================---
---Worldbuff Map Frames---
---====================---

--Update timers for Felwood worldmap when the map is open.
function NWB:updateWorldbuffMarkers(type)
	--Seconds left.
	local time = (NWB.data[type .. "Timer"] + NWB.db.global[type .. "RespawnTime"]) - GetServerTime();
	if (type == "ony" or type == "nef") then
		if (NWB.data[type .. "NpcDied"] > NWB.data[type .. "Timer"]) then
			local killedAgo = NWB:getTimeString(GetServerTime() - NWB.data[type .. "NpcDied"], true) 
			local tooltipString = "|CffDEDE42" .. _G[type .. "NWBWorldMap"].name .. "\n"
    				.. "No Timer\n"
    				.. "NPC Was killed " .. killedAgo .. " ago";
    		_G[type .. "NWBWorldMap"].tooltip.fs:SetText(tooltipString);
    		_G[type .. "NWBWorldMap"].tooltip:SetWidth(_G[type .. "NWBWorldMap"].tooltip.fs:GetStringWidth() + 18);
			_G[type .. "NWBWorldMap"].tooltip:SetHeight(_G[type .. "NWBWorldMap"].tooltip.fs:GetStringHeight() + 12);
			return L["noTimer"];
		end
	end
	if (time > 0) then
    	local timeString = NWB:getTimeString(time, true);
    	local timeStringShort = NWB:getTimeString(time, true, true);
    	local timeStamp = NWB:getTimeFormat(NWB.data[type .. "Timer"] + NWB.db.global[type .. "RespawnTime"]);
    	local tooltipString = "|CffDEDE42" .. _G[type .. "NWBWorldMap"].name .. "\n"
    			.. timeString .. "\n"
    			.. timeStamp;
    	_G[type .. "NWBWorldMap"].tooltip.fs:SetText(tooltipString);
    	_G[type .. "NWBWorldMap"].tooltip:SetWidth(_G[type .. "NWBWorldMap"].tooltip.fs:GetStringWidth() + 18);
		_G[type .. "NWBWorldMap"].tooltip:SetHeight(_G[type .. "NWBWorldMap"].tooltip.fs:GetStringHeight() + 12);
    	return timeStringShort;
  	end
  	_G[type .. "NWBWorldMap"].tooltip.fs:SetText("|CffDEDE42" .. _G[type .. "NWBWorldMap"].name);
	return L["noTimer"];
end

function NWB:createWorldbuffMarkersTable()
	if (faction == "Alliance") then
		NWB.worldBuffMapMarkerTypes = {
			["rend"] = {x = 74.0, y = 73.0, mapID = 1453, icon = "Interface\\Icons\\spell_arcane_teleportorgrimmar", name = L["rend"]},
			["ony"] = {x = 79.5, y = 73.0, mapID = 1453, icon = "Interface\\Icons\\inv_misc_head_dragon_01", name = L["onyxia"]},
			["nef"] = {x = 85.0, y = 73.0, mapID = 1453, icon = "Interface\\Icons\\inv_misc_head_dragon_black", name = L["nefarian"]},
		};
	else
		NWB.worldBuffMapMarkerTypes = {
			["rend"] = {x = 59.0, y = 79.0, mapID = 1454, icon = "Interface\\Icons\\spell_arcane_teleportorgrimmar", name = L["rend"]},
			["ony"] = {x = 64.5, y = 79.0, mapID = 1454, icon = "Interface\\Icons\\inv_misc_head_dragon_01", name = L["onyxia"]},
			["nef"] = {x = 70.0, y = 79.0, mapID = 1454, icon = "Interface\\Icons\\inv_misc_head_dragon_black", name = L["nefarian"]},
		};
	end
end

function NWB:createWorldbuffMarkers()
	for k, v in pairs(NWB.worldBuffMapMarkerTypes) do
		--Worldmap marker.
		local obj = CreateFrame("Frame", k .. "NWBWorldMap", WorldMapFrame);
		obj.name = v.name;
		local bg = obj:CreateTexture(nil, "MEDIUM");
		bg:SetTexture(v.icon);
		bg:SetAllPoints(obj);
		obj.texture = bg;
		obj:SetSize(23, 23);
		--Worldmap tooltip.
		obj.tooltip = CreateFrame("Frame", k.. "WorldMapTooltip", obj, "TooltipBorderedFrameTemplate");
		obj.tooltip:SetPoint("CENTER", 0, -46);
		obj.tooltip:SetFrameStrata("HIGH");
		obj.tooltip:SetFrameLevel(9);
		obj.tooltip.fs = obj.tooltip:CreateFontString(k .. "NWBWorldMapTooltipFS", "ARTWORK");
		obj.tooltip.fs:SetPoint("CENTER", 0, 0);
		obj.tooltip.fs:SetFont("Fonts\\ARIALN.ttf", 14);
		obj.tooltip.fs:SetText("|CffDEDE42" .. v.name);
		obj.tooltip:SetWidth(obj.tooltip.fs:GetStringWidth() + 18);
		obj.tooltip:SetHeight(obj.tooltip.fs:GetStringHeight() + 12);
		obj:SetScript("OnEnter", function(self)
			obj.tooltip:Show();
		end)
		obj:SetScript("OnLeave", function(self)
			obj.tooltip:Hide();
		end)
		obj.tooltip:Hide();
		--Timer frame that sits above the icon when an active timer is found.
		obj.timerFrame = CreateFrame("Frame", k.. "WorldMapTimerFrame", obj, "TooltipBorderedFrameTemplate");
		obj.timerFrame:SetPoint("CENTER", 0, 21);
		obj.timerFrame:SetFrameStrata("HIGH");
		obj.timerFrame:SetFrameLevel(9);
		obj.timerFrame.fs = obj.timerFrame:CreateFontString(k .. "NWBWorldMapTimerFrameFS", "ARTWORK");
		obj.timerFrame.fs:SetPoint("CENTER", 0, 0);
		obj.timerFrame.fs:SetFont("Fonts\\ARIALN.ttf", 13);
		obj.timerFrame:SetWidth(54);
		obj.timerFrame:SetHeight(24);
		obj:SetScript("OnUpdate", function(self)
			--Update timer when map is open.
			obj.timerFrame.fs:SetText(NWB:updateWorldbuffMarkers(k));
		end)
	end
	NWB:refreshWorldbuffMarkers()
	--Fix a bug with tooltips and first time opening the map.
	--Disabled, running this twice taints the blizzard raid frames (wtf?)
	--Running it once already during songflower load.
	--WorldMapFrame:Show();
	--if (faction == "Alliance") then
	--	WorldMapFrame:SetMapID(1453);
	--else
	--	WorldMapFrame:SetMapID(1454);
	--end
	--WorldMapFrame:Hide();
end

function NWB:refreshWorldbuffMarkers()
	for k, v in pairs(NWB.worldBuffMapMarkerTypes) do
		NWB.dragonLibPins:RemoveWorldMapIcon(k .. "NWBWorldMap", _G[k .. "NWBWorldMap"]);
		if (NWB.db.global.showWorldMapMarkers) then
			NWB.dragonLibPins:AddWorldMapIconMap(k .. "NWBWorldMap", _G[k .. "NWBWorldMap"], v.mapID, v.x/100, v.y/100, HBD_PINS_WORLDMAP_SHOW_PARENT);
			--NWB.dragonLibPins:AddWorldMapIconMap(k .. "NWBWorldMap", _G[k .. "NWBWorldMap"], v.mapID, v.x/100, v.y/100);
			if (faction == "Alliance" and k == "rend") then
				if (not NWB.db.global.allianceEnableRend) then
					NWB.dragonLibPins:RemoveWorldMapIcon(k .. "NWBWorldMap", _G[k .. "NWBWorldMap"]);
				end
			end
		end
	end
end