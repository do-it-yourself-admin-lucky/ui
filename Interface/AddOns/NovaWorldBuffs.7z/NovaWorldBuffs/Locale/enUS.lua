local L = LibStub("AceLocale-3.0"):NewLocale("NovaWorldBuffs", "enUS", true);

--Rend buff aura name.
L["Warchief's Blessing"] = true;
--Onyxia and Nefarian buff aura name.
L["Rallying Cry of the Dragonslayer"] = true;
--Songflower buff aura name from felwood.
L["Songflower Serenade"] = true;

---=====---
---Horde---
---=====---

--Horde Orgrimmar Rend buff NPC.
L["Thrall"] = true;
--Horde The Barrens Rend buff NPC.
L["Herald of Thrall"] = true;
--Horde rend buff NPC first yell string (part of his first yell msg before before buff).
L["Rend Blackhand, has fallen"] = true;
--Horde rend buff NPC second yell string (part of his second yell msg before before buff).
L["Be bathed in my power"] = true;

--Horde Onyxia buff NPC.
L["Overlord Runthak"] = true;
--Horde Onyxia buff NPC first yell string (part of his first yell msg before before buff).
L["Onyxia, has been slain"] = true;
--Horde Onyxia buff NPC second yell string (part of his second yell msg before before buff).
L["Be lifted by the rallying cry"] = true;

--Horde Nefarian buff NPC.
L["High Overlord Saurfang"] = true;
--Horde Nefarian buff NPC first yell string (part of his first yell msg before before buff).
L["NEFARIAN IS SLAIN"] = true;
--Horde Nefarian buff NPC second yell string (part of his second yell msg before before buff).
L["Revel in his rallying cry"] = true;

---========---
---Alliance---
---========---

--Alliance Onyxia buff NPC.
L["Major Mattingly"] = true;
--Alliance Onyxia buff NPC first yell string (part of his first yell msg before before buff).
L["history has been made"] = true;
--Alliance Onyxia buff NPC second yell string (part of his second yell msg before before buff).
L["Onyxia, hangs from the arches"] = true;


--Alliance Nefarian buff NPC.
L["Field Marshal Afrasiabi"] = true;
--Alliance Nefarian buff NPC first yell string (part of his first yell msg before before buff).
L["the Lord of Blackrock is slain"] = true;
--Alliance Nefarian buff NPC second yell string (part of his second yell msg before before buff).
L["Revel in the rallying cry"] = true;

---==============---
---Output Strings---
---==============---

L["rend"] = "Rend"; --Rend Blackhand
L["onyxia"] = "Onyxia"; --Onyxia
L["nefarian"] = "Nefarian"; --Nefarian
L["dmf"] = "Darkmoon Faire"; --Darkmoon Faire
L["noTimer"] = "No timer"; --No timer
L["noCurrentTimer"] = "No current timer"; --No current timer
L["noActiveTimers"] = "No active timers";	--No active timers
L["newBuffCanBeDropped"] = "A new %s buff can be dropped now."
L["buffResetsIn"] = "%s resets in %s.";
L["rendFirstYellMsg"] = "Rend will drop in 6 seconds (NPC dialogue started).";
L["onyxiaFirstYellMsg"] = "Onyxia will drop in 14 seconds (NPC dialogue started).";
L["nefarianFirstYellMsg"] = "Nefarian will drop in 15 seconds (NPC dialogue started).";
L["rendBuffDropped"] = "Warchief's Blessing (Rend) has been dropped.";
L["onyxiaBuffDropped"] = "Rallying Cry of the Dragonslayer (Onyxia) has been dropped.";
L["nefarianBuffDropped"] = "Rallying Cry of the Dragonslayer (Nefarian) has been dropped.";
L["onyxiaNpcKilledHorde"] = "Overlord Runthak has just been killed (Onyxia buff NPC).";
L["onyxiaNpcKilledAlliance"] = "Major Mattingly has just been killed (Onyxia buff NPC).";
L["nefarianNpcKilledHorde"] = "High Overlord Saurfang has just been killed (Nefarian buff NPC).";
L["nefarianNpcKilledAlliance"] = "Field Marshal Afrasiabi has just been killed (Nefarian buff NPC).";
L["newSongflowerReceived"] = "New songflower timer received"; --New songflower timer received
L["songflowerPicked"] = "Songflower picked at %s, next spawn in 25mins."; -- Guild msg when songflower picked.
L["North Felpaw Village"] = "North Felpaw Village"; --Felwood map subzones (flower1).
L["West Felpaw Village"] = "West Felpaw Village"; --Felwood map subzones (flower2).
L["North of Irontree Woods"] = "North of Irontree Woods"; --Felwood map subzones (flower3).
L["Talonbranch Glade"] = "Talonbranch Glade"; --Felwood map subzones (flower4).
L["Shatter Scar Vale"] = "Shatter Scar Vale"; --Felwood map subzones (flower5).
L["Bloodvenom Post"] = "Bloodvenom Post"; --Felwood map subzones (flower6).
L["East of Jaedenar"] = "East of Jaedenar"; --Felwood map subzones (flower7).
L["North of Emerald Sanctuary"] = "North of Emerald Sanctuary"; --Felwood map subzones (flower8).
L["West of Emerald Sanctuary"] = "West of Emerald Sanctuary"; --Felwood map subzones (flower9).
L["South of Emerald Sanctuary"] = "South of Emerald Sanctuary"; --Felwood map subzones (flower10).
L["second"] = "second"; --Second (singular).
L["seconds"] = "seconds"; --Seconds (plural).
L["minute"] = "minute"; --Minute (singular).
L["minutes"] = "minutes"; --Minutes (plural).
L["hour"] = "hour"; --Hour (singular).
L["hours"] = "hours"; --Hours (plural).
L["day"] = "day"; --Day (singular).
L["days"] = "days"; --Days (plural).
L["secondShort"] = "s"; --Used in short timers like 1m30s (single letter only, usually the first letter of seconds).
L["minuteShort"] = "m"; --Used in short timers like 1m30s (single letter only, usually the first letter of minutes).
L["hourShort"] = "h"; --Used in short timers like 1h30m (single letter only, usually the first letter of hours).
L["dayShort"] = "d"; --Used in short timers like 1d8h (single letter only, usually the first letter of days).
L["versionOutOfDate"] = "Your Nova World Buffs addon is out of date, please update it at https://www.curseforge.com/wow/addons/nova-world-buffs or through the twitch client";