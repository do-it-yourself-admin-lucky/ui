local L = LibStub("AceLocale-3.0"):NewLocale("NovaWorldBuffs", "deDE");
if (not L) then
	return;
end

--Rend buff aura name.
L["Warchief's Blessing"] = "Segen des Kriegshäuptlings";
--Onyxia and Nefarian buff aura name.
L["Rallying Cry of the Dragonslayer"] = "Schlachtruf der Drachentöter";
--Songflower buff aura name from felwood.
L["Songflower Serenade"] = "Liedblumenserenade";

---=====---
---Horde---
---=====---

--Horde Orgrimmar Rend buff NPC.
L["Thrall"] = "Thrall";
--Horde The Barrens Rend buff NPC.
L["Herald of Thrall"] = "Herold von Thrall";
--Horde rend buff NPC first yell string (part of his first yell msg before before buff).
L["Rend Blackhand, has fallen"] = "Rend Blackhand, der falsche";
--Horde rend buff NPC second yell string (part of his second yell msg before before buff).
L["Be bathed in my power"] = "Badet in meiner Macht";

--Horde Onyxia buff NPC.
L["Overlord Runthak"] = "Oberanführer Runthak";
--Horde Onyxia buff NPC first yell string (part of his first yell msg before before buff).
L["Onyxia, has been slain"] = "Die Brutmutter Onyxia wurde getötet";
--Horde Onyxia buff NPC second yell string (part of his second yell msg before before buff).
L["Be lifted by the rallying cry"] = "Lasst den Siegesschrei der Drachentöter eure Herzen höher schlagen";

--Horde Nefarian buff NPC.
L["High Overlord Saurfang"] = "Hochfürst Saurfang";
--Horde Nefarian buff NPC first yell string (part of his first yell msg before before buff).
L["NEFARIAN IS SLAIN"] = "NAFARIAN IST TOT";
--Horde Nefarian buff NPC second yell string (part of his second yell msg before before buff).
L["Revel in his rallying cry"] = "Lasst seinen Siegesschrei eure Herzen höher schlagen";

---========---
---Alliance---
---========---

--Alliance Onyxia buff NPC.
L["Major Mattingly"] = "Major Mattingly";
--Alliance Onyxia buff NPC first yell string (part of his first yell msg before before buff).
--L["history has been made"] = "";
--Alliance Onyxia buff NPC second yell string (part of his second yell msg before before buff).
--L["Onyxia, hangs from the arches"] = "";


--Alliance Nefarian buff NPC.
L["Field Marshal Afrasiabi"] = "Feldmarschall Afrasiabi";
--Alliance Nefarian buff NPC first yell string (part of his first yell msg before before buff).
--L["the Lord of Blackrock is slain"] = "";
--Alliance Nefarian buff NPC second yell string (part of his second yell msg before before buff).
--L["Revel in the rallying cry"] = "";