### Version 1.0.2 [ September/1st/2019 ]

**New Additions:**  
Gold from quests added to tooltip
Completed quests will show up in the parentheses of the datatext

**Bug Fixes:**  

**Misc. Changes:**