
CT_MailModOptions = {
	["CHAR-Luckypriest-Lucifron"] = {
	},
	["sendmailAutoCompleteOnline"] = true,
	["sendmailAutoCompleteAccount"] = true,
	["sendmailAutoCompleteFriends"] = true,
	["sendmailAutoCompleteGroup"] = true,
	["alts"] = {
		["Luckypriest @ Lucifron"] = true,
	},
	["sendmailAutoCompleteUse"] = true,
	["sendmailAutoCompleteGuild"] = true,
	["sendmailAutoCompleteInteracted"] = true,
}
