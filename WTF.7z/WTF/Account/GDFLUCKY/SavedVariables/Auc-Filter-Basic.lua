
AucAdvancedFilterBasic_IgnoreList = {
	["Lucifron"] = {
		["List"] = {
		},
	},
}
