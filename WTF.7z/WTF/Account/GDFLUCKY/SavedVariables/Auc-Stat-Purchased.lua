
AucAdvancedStatPurchasedData = {
	["Version"] = 3,
	["RealmData"] = {
	},
}
