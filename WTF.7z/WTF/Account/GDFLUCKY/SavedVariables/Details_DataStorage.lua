
DetailsDataStorage = {
	[14] = {
	},
	[16] = {
	},
	[15] = {
	},
	["VERSION"] = 4,
}
