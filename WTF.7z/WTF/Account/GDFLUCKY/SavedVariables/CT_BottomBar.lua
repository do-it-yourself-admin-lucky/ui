
CT_BottomBarOptions = {
	["CHAR-Luckymagic-Lucifron"] = {
		["disableDefaultActionBar"] = true,
	},
}
