
CT_RA_CurrPositions = nil
CT_RA_CustomPositions = nil
CT_RA_DebuffTemplates = nil
CT_RA_HasJoinedRaid = nil
CT_RA_MainTanks = nil
CT_RA_MainTankStats = nil
CT_RA_ModVersion = nil
CT_RA_NumRaidMembers = nil
CT_RA_PartyMembers = nil
CT_RA_PTargets = nil
CT_RA_RaidParticipant = nil
CT_RA_Squelch = nil
CT_RA_Stats = nil
CT_RAMenu_CurrSet = nil
CT_RAMenu_Locked = nil
CT_RAMenu_Options = nil
CT_RASets_ButtonPosition = nil
CT_RATab_AutoPromotions = nil
CT_RATab_DefaultLootMethod = nil
CT_RATarget = nil
CT_RaidAssistOptions = {
	["CHAR-Luckypriest-Lucifron"] = {
		["CTRA_LastConversion"] = 8.205,
	},
}
