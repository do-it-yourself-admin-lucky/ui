
CT_MapMod_Options = nil
CT_MapMod_Notes = {
}
CT_MapModOptions = nil
