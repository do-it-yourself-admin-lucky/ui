
AddOnSkinsDB = {
	["profileKeys"] = {
		["Luckypriest - Lucifron"] = "BenikUI",
	},
	["profiles"] = {
		["Default"] = {
		},
		["BenikUI"] = {
			["WeakAuraAuraBar"] = true,
			["DBMFontSize"] = 10,
			["DetailsBackdrop"] = false,
			["DBMRadarTrans"] = true,
			["TransparentEmbed"] = true,
			["DBMSkinHalf"] = true,
			["DBMFont"] = "Expressway",
			["EmbedSystemDual"] = true,
		},
	},
}
AddOnSkinsDS = {
}
