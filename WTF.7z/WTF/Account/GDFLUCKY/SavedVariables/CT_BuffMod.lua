
CT_BuffModOptions = {
	["CHAR-Luckymagic-Lucifron"] = {
		["optionsFormat"] = 1,
		["windowOptionsList"] = {
			{
				["primaryOptionsList"] = {
					{
						["position"] = {
							"TOPLEFT", -- [1]
							"UIParent", -- [2]
							"TOPLEFT", -- [3]
							827.501586914063, -- [4]
							-530.0009765625, -- [5]
							264.999969482422, -- [6]
							19.9999828338623, -- [7]
						},
					}, -- [1]
				},
			}, -- [1]
		},
	},
}
