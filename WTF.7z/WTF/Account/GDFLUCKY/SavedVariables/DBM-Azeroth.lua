
DBMAzeroth_AllSavedVars = {
	["Luckypriest-Lucifron"] = {
		["Azuregos"] = {
			[0] = {
				["Enabled"] = true,
				["SpecWarn22067spellSWNote"] = true,
				["SpecWarn21147spell"] = true,
				["SpecWarn22067spell"] = true,
				["SpecWarn22067spellSWSound"] = 1,
				["announce21099spell"] = true,
				["SpecWarn21147spellSWSound"] = 2,
				["SpecWarn21147spellSWNote"] = true,
			},
		},
		["Emeriss"] = {
			[0] = {
				["Enabled"] = true,
				["SpecWarn24814dodge"] = true,
				["SpecWarn24814dodgeSWNote"] = true,
				["SpecWarn24814dodgeSWSound"] = 2,
				["Timer24814cdCVoice"] = 0,
				["Timer24814cdTColor"] = 3,
				["Timer24814cd"] = true,
				["announceother24818stack"] = false,
			},
		},
		["Lethon"] = {
			[0] = {
				["Enabled"] = true,
				["SpecWarn24814dodge"] = true,
				["SpecWarn24814dodgeSWNote"] = true,
				["SpecWarn24814dodgeSWSound"] = 2,
				["Timer24814cdCVoice"] = 0,
				["Timer24814cdTColor"] = 3,
				["Timer24814cd"] = true,
				["announceother24818stack"] = false,
			},
		},
		["KazzakClassic"] = {
			[0] = {
				["SpecWarn21056you"] = true,
				["announceother21056target"] = true,
				["announce21341spell"] = true,
				["SpecWarn21056youSWNote"] = true,
				["SpecWarn21056youSWSound"] = 1,
				["Enabled"] = true,
			},
		},
		["Taerar"] = {
			[0] = {
				["Enabled"] = true,
				["SpecWarn24814dodge"] = true,
				["SpecWarn24814dodgeSWNote"] = true,
				["SpecWarn24814dodgeSWSound"] = 2,
				["Timer24814cdCVoice"] = 0,
				["Timer24814cdTColor"] = 3,
				["Timer24814cd"] = true,
				["announceother24818stack"] = false,
			},
		},
		["Ysondre"] = {
			[0] = {
				["Enabled"] = true,
				["SpecWarn24814dodge"] = true,
				["SpecWarn24814dodgeSWNote"] = true,
				["SpecWarn24814dodgeSWSound"] = 2,
				["Timer24814cdCVoice"] = 0,
				["Timer24814cdTColor"] = 3,
				["Timer24814cd"] = true,
				["announceother24818stack"] = false,
			},
		},
	},
}
