
BeanCounterDB = {
	["Lucifron"] = {
		["Luckypriest"] = {
			["vendorsell"] = {
			},
			["postedBids"] = {
			},
			["postedAuctions"] = {
			},
			["completedBidsBuyoutsNeutral"] = {
			},
			["vendorbuy"] = {
			},
			["failedAuctions"] = {
			},
			["failedBidsNeutral"] = {
			},
			["failedBids"] = {
			},
			["completedAuctions"] = {
			},
			["failedAuctionsNeutral"] = {
			},
			["completedAuctionsNeutral"] = {
			},
			["completedBidsBuyouts"] = {
			},
		},
	},
}
BeanCounterDBSettings = {
	["configator.left"] = 666.666931152344,
	["configator.top"] = 825.000183105469,
	["util.beancounter.ButtonuseDateCheck"] = false,
	["Lucifron"] = {
		["Luckypriest"] = {
			["tasks.sortArray"] = 1590547090,
			["version"] = 3.04,
			["faction"] = "Horde",
			["tasks.compactDB"] = 1590547090,
			["wealth"] = 1194158,
			["tasks.prunePostedDB"] = 1590547090,
			["mailbox"] = {
				{
					["read"] = 1,
					["sender"] = "Horde Auction House",
					["time"] = 29.4439010620117,
					["subject"] = "Auction expired: Scroll of Strength IV",
				}, -- [1]
				{
					["read"] = 1,
					["sender"] = "Horde Auction House",
					["time"] = 29.4432640075684,
					["subject"] = "Auction expired: Scroll of Spirit IV",
				}, -- [2]
				{
					["read"] = 1,
					["sender"] = "Horde Auction House",
					["time"] = 29.4432640075684,
					["subject"] = "Auction expired: Scroll of Spirit IV",
				}, -- [3]
				{
					["read"] = 1,
					["sender"] = "Horde Auction House",
					["time"] = 29.1304969787598,
					["subject"] = "Auction successful: Essence of Undeath",
				}, -- [4]
				{
					["read"] = 1,
					["sender"] = "Horde Auction House",
					["time"] = 29.1246528625488,
					["subject"] = "Auction successful: Runecloth (3)",
				}, -- [5]
				{
					["read"] = 1,
					["sender"] = "Horde Auction House",
					["time"] = 29.1217594146729,
					["subject"] = "Auction successful: Rugged Leather (2)",
				}, -- [6]
				{
					["read"] = 1,
					["sender"] = "Horde Auction House",
					["time"] = 29.1101150512695,
					["subject"] = "Auction successful: Silk Cloth (4)",
				}, -- [7]
				{
					["read"] = 1,
					["sender"] = "Horde Auction House",
					["time"] = 10.9480438232422,
					["subject"] = "Auction won: Punctured Voodoo Doll",
				}, -- [8]
			},
		},
	},
}
BeanCounterDBNames = {
}
BeanCounterAccountDB = nil
BeanCounterMailPatch = {
	"Horde Auction House", -- [1]
}
