
CT_RaidTracker_Online = {
	["Orkasmus-Lucifron"] = true,
	["Vacanta-Lucifron"] = true,
	["Naazir-Lucifron"] = true,
	["Lucaro-Lucifron"] = true,
	["Happyziege-Lucifron"] = false,
	["Cramp-Lucifron"] = true,
	["Yamakasie-Lucifron"] = true,
	["Zajini-Lucifron"] = false,
	["Xinea-Lucifron"] = true,
	["Illmore-Lucifron"] = true,
	["Rocat-Lucifron"] = true,
	["Bench-Lucifron"] = true,
	["Dynast-Lucifron"] = true,
	["Balanar-Lucifron"] = true,
	["Tornag-Lucifron"] = true,
	["Maehlîc-Lucifron"] = true,
	["Vengè-Lucifron"] = true,
	["Maybé-Lucifron"] = true,
	["Thungrim-Lucifron"] = true,
	["Herrlich-Lucifron"] = true,
	["Gotshocks-Lucifron"] = true,
	["Testosterpwn-Lucifron"] = true,
	["Schlimmbumm-Lucifron"] = true,
	["Dextros-Lucifron"] = true,
	["Rayle-Lucifron"] = true,
	["Arastus-Lucifron"] = true,
	["Daranasi-Lucifron"] = true,
	["Nakanjo-Lucifron"] = true,
	["Luckypriest-Lucifron"] = true,
	["Guhl-Lucifron"] = true,
	["Givewfproc-Lucifron"] = true,
	["Rondan-Lucifron"] = true,
	["Sukz-Lucifron"] = true,
	["Minzberd-Lucifron"] = true,
	["Painbow-Lucifron"] = true,
}
CT_RaidTracker_RaidLog = {
	{
		["Leave"] = {
			{
				["time"] = "10/30/19 19:06:19",
				["player"] = "Vacanta-Lucifron",
			}, -- [1]
			{
				["time"] = "10/30/19 19:06:19",
				["player"] = "Illmore-Lucifron",
			}, -- [2]
			{
				["time"] = "10/30/19 19:06:19",
				["player"] = "Balanar-Lucifron",
			}, -- [3]
			{
				["time"] = "10/30/19 19:06:19",
				["player"] = "Naazir-Lucifron",
			}, -- [4]
			{
				["time"] = "10/30/19 19:06:19",
				["player"] = "Schlimmbumm-Lucifron",
			}, -- [5]
			{
				["time"] = "10/30/19 19:06:19",
				["player"] = "Arastus-Lucifron",
			}, -- [6]
			{
				["time"] = "10/30/19 19:06:19",
				["player"] = "Daranasi-Lucifron",
			}, -- [7]
			{
				["time"] = "10/30/19 19:06:19",
				["player"] = "Givewfproc-Lucifron",
			}, -- [8]
			{
				["time"] = "10/30/19 19:06:19",
				["player"] = "Nakanjo-Lucifron",
			}, -- [9]
			{
				["time"] = "10/30/19 19:06:19",
				["player"] = "Maehlîc-Lucifron",
			}, -- [10]
			{
				["time"] = "10/30/19 19:06:19",
				["player"] = "Minzberd-Lucifron",
			}, -- [11]
			{
				["time"] = "10/30/19 19:06:19",
				["player"] = "Guhl-Lucifron",
			}, -- [12]
			{
				["time"] = "10/30/19 19:06:19",
				["player"] = "Painbow-Lucifron",
			}, -- [13]
			{
				["time"] = "10/30/19 19:06:19",
				["player"] = "Dextros-Lucifron",
			}, -- [14]
			{
				["time"] = "10/30/19 19:06:19",
				["player"] = "Gotshocks-Lucifron",
			}, -- [15]
			{
				["time"] = "10/30/19 19:06:19",
				["player"] = "Thungrim-Lucifron",
			}, -- [16]
			{
				["time"] = "10/30/19 19:06:19",
				["player"] = "Rondan-Lucifron",
			}, -- [17]
			{
				["time"] = "10/30/19 19:06:19",
				["player"] = "Maybé-Lucifron",
			}, -- [18]
			{
				["time"] = "10/30/19 19:06:19",
				["player"] = "Tornag-Lucifron",
			}, -- [19]
			{
				["time"] = "10/30/19 19:06:19",
				["player"] = "Zajini-Lucifron",
			}, -- [20]
			{
				["time"] = "10/30/19 19:06:19",
				["player"] = "Happyziege-Lucifron",
			}, -- [21]
			{
				["time"] = "10/30/19 19:06:19",
				["player"] = "Xinea-Lucifron",
			}, -- [22]
			{
				["time"] = "10/30/19 19:06:19",
				["player"] = "Dynast-Lucifron",
			}, -- [23]
			{
				["time"] = "10/30/19 19:06:19",
				["player"] = "Rayle-Lucifron",
			}, -- [24]
			{
				["time"] = "10/30/19 19:06:19",
				["player"] = "Lucaro-Lucifron",
			}, -- [25]
			{
				["time"] = "10/30/19 19:06:19",
				["player"] = "Rocat-Lucifron",
			}, -- [26]
			{
				["time"] = "10/30/19 19:06:29",
				["player"] = "Cramp-Lucifron",
			}, -- [27]
			{
				["time"] = "10/30/19 19:06:50",
				["player"] = "Orkasmus-Lucifron",
			}, -- [28]
			{
				["time"] = "10/30/19 19:07:08",
				["player"] = "Sukz-Lucifron",
			}, -- [29]
			{
				["time"] = "10/30/19 19:09:42",
				["player"] = "Bench-Lucifron",
			}, -- [30]
			{
				["time"] = "10/30/19 19:10:27",
				["player"] = "Yamakasie-Lucifron",
			}, -- [31]
			{
				["time"] = "10/30/19 19:14:05",
				["player"] = "Vengè-Lucifron",
			}, -- [32]
			{
				["time"] = "10/30/19 19:14:35",
				["player"] = "Balanar-Lucifron",
			}, -- [33]
			{
				["time"] = "10/30/19 19:14:41",
				["player"] = "Testosterpwn-Lucifron",
			}, -- [34]
			{
				["time"] = "10/30/19 19:15:02",
				["player"] = "Herrlich-Lucifron",
			}, -- [35]
		},
		["Loot"] = {
		},
		["Join"] = {
			{
				["time"] = "10/30/19 19:06:19",
				["player"] = "Vacanta-Lucifron",
			}, -- [1]
			{
				["time"] = "10/30/19 19:06:19",
				["player"] = "Illmore-Lucifron",
			}, -- [2]
			{
				["time"] = "10/30/19 19:06:19",
				["player"] = "Balanar-Lucifron",
			}, -- [3]
			{
				["time"] = "10/30/19 19:06:19",
				["player"] = "Naazir-Lucifron",
			}, -- [4]
			{
				["time"] = "10/30/19 19:06:19",
				["player"] = "Schlimmbumm-Lucifron",
			}, -- [5]
			{
				["time"] = "10/30/19 19:06:19",
				["player"] = "Arastus-Lucifron",
			}, -- [6]
			{
				["time"] = "10/30/19 19:06:19",
				["player"] = "Daranasi-Lucifron",
			}, -- [7]
			{
				["time"] = "10/30/19 19:06:19",
				["player"] = "Givewfproc-Lucifron",
			}, -- [8]
			{
				["time"] = "10/30/19 19:06:19",
				["player"] = "Nakanjo-Lucifron",
			}, -- [9]
			{
				["time"] = "10/30/19 19:06:19",
				["player"] = "Maehlîc-Lucifron",
			}, -- [10]
			{
				["time"] = "10/30/19 19:06:19",
				["player"] = "Minzberd-Lucifron",
			}, -- [11]
			{
				["time"] = "10/30/19 19:06:19",
				["player"] = "Guhl-Lucifron",
			}, -- [12]
			{
				["time"] = "10/30/19 19:06:19",
				["player"] = "Painbow-Lucifron",
			}, -- [13]
			{
				["time"] = "10/30/19 19:06:19",
				["player"] = "Dextros-Lucifron",
			}, -- [14]
			{
				["time"] = "10/30/19 19:06:19",
				["player"] = "Gotshocks-Lucifron",
			}, -- [15]
			{
				["time"] = "10/30/19 19:06:19",
				["player"] = "Thungrim-Lucifron",
			}, -- [16]
			{
				["time"] = "10/30/19 19:06:19",
				["player"] = "Rondan-Lucifron",
			}, -- [17]
			{
				["time"] = "10/30/19 19:06:19",
				["player"] = "Maybé-Lucifron",
			}, -- [18]
			{
				["time"] = "10/30/19 19:06:19",
				["player"] = "Tornag-Lucifron",
			}, -- [19]
			{
				["time"] = "10/30/19 19:06:19",
				["player"] = "Zajini-Lucifron",
			}, -- [20]
			{
				["time"] = "10/30/19 19:06:19",
				["player"] = "Happyziege-Lucifron",
			}, -- [21]
			{
				["time"] = "10/30/19 19:06:19",
				["player"] = "Xinea-Lucifron",
			}, -- [22]
			{
				["time"] = "10/30/19 19:06:19",
				["player"] = "Dynast-Lucifron",
			}, -- [23]
			{
				["time"] = "10/30/19 19:06:19",
				["player"] = "Rayle-Lucifron",
			}, -- [24]
			{
				["time"] = "10/30/19 19:06:19",
				["player"] = "Lucaro-Lucifron",
			}, -- [25]
			{
				["time"] = "10/30/19 19:06:19",
				["player"] = "Rocat-Lucifron",
			}, -- [26]
			{
				["time"] = "10/30/19 19:06:19",
				["player"] = "Luckypriest-Lucifron",
			}, -- [27]
			{
				["time"] = "10/30/19 19:06:19",
				["player"] = "Luckypriest-Lucifron",
			}, -- [28]
			{
				["time"] = "10/30/19 19:06:29",
				["player"] = "Vacanta-Lucifron",
			}, -- [29]
			{
				["time"] = "10/30/19 19:06:29",
				["player"] = "Illmore-Lucifron",
			}, -- [30]
			{
				["time"] = "10/30/19 19:06:29",
				["player"] = "Balanar-Lucifron",
			}, -- [31]
			{
				["time"] = "10/30/19 19:06:29",
				["player"] = "Naazir-Lucifron",
			}, -- [32]
			{
				["time"] = "10/30/19 19:06:29",
				["player"] = "Schlimmbumm-Lucifron",
			}, -- [33]
			{
				["time"] = "10/30/19 19:06:29",
				["player"] = "Arastus-Lucifron",
			}, -- [34]
			{
				["time"] = "10/30/19 19:06:29",
				["player"] = "Daranasi-Lucifron",
			}, -- [35]
			{
				["time"] = "10/30/19 19:06:29",
				["player"] = "Givewfproc-Lucifron",
			}, -- [36]
			{
				["time"] = "10/30/19 19:06:29",
				["player"] = "Nakanjo-Lucifron",
			}, -- [37]
			{
				["time"] = "10/30/19 19:06:29",
				["player"] = "Maehlîc-Lucifron",
			}, -- [38]
			{
				["time"] = "10/30/19 19:06:29",
				["player"] = "Guhl-Lucifron",
			}, -- [39]
			{
				["time"] = "10/30/19 19:06:29",
				["player"] = "Painbow-Lucifron",
			}, -- [40]
			{
				["time"] = "10/30/19 19:06:29",
				["player"] = "Dextros-Lucifron",
			}, -- [41]
			{
				["time"] = "10/30/19 19:06:29",
				["player"] = "Gotshocks-Lucifron",
			}, -- [42]
			{
				["time"] = "10/30/19 19:06:29",
				["player"] = "Thungrim-Lucifron",
			}, -- [43]
			{
				["time"] = "10/30/19 19:06:29",
				["player"] = "Rondan-Lucifron",
			}, -- [44]
			{
				["time"] = "10/30/19 19:06:29",
				["player"] = "Maybé-Lucifron",
			}, -- [45]
			{
				["time"] = "10/30/19 19:06:29",
				["player"] = "Tornag-Lucifron",
			}, -- [46]
			{
				["time"] = "10/30/19 19:06:29",
				["player"] = "Xinea-Lucifron",
			}, -- [47]
			{
				["time"] = "10/30/19 19:06:29",
				["player"] = "Dynast-Lucifron",
			}, -- [48]
			{
				["time"] = "10/30/19 19:06:29",
				["player"] = "Rayle-Lucifron",
			}, -- [49]
			{
				["time"] = "10/30/19 19:06:29",
				["player"] = "Lucaro-Lucifron",
			}, -- [50]
			{
				["time"] = "10/30/19 19:06:29",
				["player"] = "Rocat-Lucifron",
			}, -- [51]
			{
				["time"] = "10/30/19 19:06:50",
				["player"] = "Cramp-Lucifron",
			}, -- [52]
			{
				["time"] = "10/30/19 19:07:08",
				["player"] = "Orkasmus-Lucifron",
			}, -- [53]
			{
				["time"] = "10/30/19 19:09:42",
				["player"] = "Sukz-Lucifron",
			}, -- [54]
			{
				["time"] = "10/30/19 19:10:27",
				["player"] = "Bench-Lucifron",
			}, -- [55]
			{
				["time"] = "10/30/19 19:11:44",
				["player"] = "Minzberd-Lucifron",
			}, -- [56]
			{
				["time"] = "10/30/19 19:11:44",
				["player"] = "Yamakasie-Lucifron",
			}, -- [57]
			{
				["time"] = "10/30/19 19:14:35",
				["player"] = "Vengè-Lucifron",
			}, -- [58]
			{
				["time"] = "10/30/19 19:14:41",
				["player"] = "Balanar-Lucifron",
			}, -- [59]
			{
				["time"] = "10/30/19 19:15:02",
				["player"] = "Testosterpwn-Lucifron",
			}, -- [60]
			{
				["time"] = "10/30/19 19:15:10",
				["player"] = "Herrlich-Lucifron",
			}, -- [61]
		},
		["PlayerInfos"] = {
			["Orkasmus-Lucifron"] = {
			},
			["Vacanta-Lucifron"] = {
			},
			["Naazir-Lucifron"] = {
			},
			["Lucaro-Lucifron"] = {
			},
			["Happyziege-Lucifron"] = {
			},
			["Cramp-Lucifron"] = {
			},
			["Yamakasie-Lucifron"] = {
			},
			["Zajini-Lucifron"] = {
			},
			["Xinea-Lucifron"] = {
			},
			["Illmore-Lucifron"] = {
			},
			["Rocat-Lucifron"] = {
			},
			["Bench-Lucifron"] = {
			},
			["Dynast-Lucifron"] = {
			},
			["Balanar-Lucifron"] = {
			},
			["Tornag-Lucifron"] = {
			},
			["Maehlîc-Lucifron"] = {
			},
			["Vengè-Lucifron"] = {
			},
			["Maybé-Lucifron"] = {
			},
			["Thungrim-Lucifron"] = {
			},
			["Herrlich-Lucifron"] = {
			},
			["Gotshocks-Lucifron"] = {
			},
			["Testosterpwn-Lucifron"] = {
			},
			["Schlimmbumm-Lucifron"] = {
			},
			["Dextros-Lucifron"] = {
			},
			["Rayle-Lucifron"] = {
			},
			["Arastus-Lucifron"] = {
			},
			["Daranasi-Lucifron"] = {
			},
			["Nakanjo-Lucifron"] = {
			},
			["Luckypriest-Lucifron"] = {
			},
			["Guhl-Lucifron"] = {
			},
			["Givewfproc-Lucifron"] = {
			},
			["Rondan-Lucifron"] = {
			},
			["Sukz-Lucifron"] = {
			},
			["Minzberd-Lucifron"] = {
			},
			["Painbow-Lucifron"] = {
			},
		},
		["key"] = "10/30/19 19:06:19",
		["BossKills"] = {
		},
		["Realm"] = "Lucifron",
	}, -- [1]
	{
		["Leave"] = {
			{
				["time"] = "10/28/19 19:05:13",
				["player"] = "Vacanta-Lucifron",
			}, -- [1]
			{
				["time"] = "10/28/19 19:05:13",
				["player"] = "Rocat-Lucifron",
			}, -- [2]
			{
				["time"] = "10/28/19 19:05:13",
				["player"] = "Rayle-Lucifron",
			}, -- [3]
			{
				["time"] = "10/28/19 19:05:13",
				["player"] = "Ratwar-Lucifron",
			}, -- [4]
			{
				["time"] = "10/28/19 19:05:13",
				["player"] = "Naazir-Lucifron",
			}, -- [5]
			{
				["time"] = "10/28/19 19:05:13",
				["player"] = "Zajini-Lucifron",
			}, -- [6]
			{
				["time"] = "10/28/19 19:05:13",
				["player"] = "Minzberd-Lucifron",
			}, -- [7]
			{
				["time"] = "10/28/19 19:05:13",
				["player"] = "Balanar-Lucifron",
			}, -- [8]
			{
				["time"] = "10/28/19 19:05:13",
				["player"] = "Dynast-Lucifron",
			}, -- [9]
			{
				["time"] = "10/28/19 19:05:44",
				["player"] = "Guhl-Lucifron",
			}, -- [10]
			{
				["time"] = "10/28/19 19:06:14",
				["player"] = "Nakanjo-Lucifron",
			}, -- [11]
			{
				["time"] = "10/28/19 19:06:16",
				["player"] = "Covox-Lucifron",
			}, -- [12]
			{
				["time"] = "10/28/19 19:06:35",
				["player"] = "Maehlîc-Lucifron",
			}, -- [13]
			{
				["time"] = "10/28/19 19:07:48",
				["player"] = "Covox-Lucifron",
			}, -- [14]
			{
				["time"] = "10/28/19 19:07:48",
				["player"] = "Bishamoto-Lucifron",
			}, -- [15]
			{
				["time"] = "10/28/19 19:08:20",
				["player"] = "Arastus-Lucifron",
			}, -- [16]
			{
				["time"] = "10/28/19 19:08:30",
				["player"] = "Mattness-Lucifron",
			}, -- [17]
			{
				["time"] = "10/28/19 19:08:56",
				["player"] = "Rondan-Lucifron",
			}, -- [18]
			{
				["time"] = "10/28/19 19:09:36",
				["player"] = "Mattness-Lucifron",
			}, -- [19]
			{
				["time"] = "10/28/19 19:09:39",
				["player"] = "Herrlich-Lucifron",
			}, -- [20]
			{
				["time"] = "10/28/19 19:10:40",
				["player"] = "Bench-Lucifron",
			}, -- [21]
			{
				["time"] = "10/28/19 19:10:40",
				["player"] = "Zajini-Lucifron",
			}, -- [22]
			{
				["time"] = "10/28/19 19:10:57",
				["player"] = "Albion-Lucifron",
			}, -- [23]
			{
				["time"] = "10/28/19 19:12:35",
				["player"] = "Xinea-Lucifron",
			}, -- [24]
			{
				["time"] = "10/28/19 19:13:01",
				["player"] = "Cramp-Lucifron",
			}, -- [25]
			{
				["time"] = "10/28/19 19:13:19",
				["player"] = "Sukz-Lucifron",
			}, -- [26]
			{
				["time"] = "10/28/19 19:13:27",
				["player"] = "Dextros-Lucifron",
			}, -- [27]
			{
				["time"] = "10/28/19 19:13:56",
				["player"] = "Vengè-Lucifron",
			}, -- [28]
			{
				["time"] = "10/28/19 19:14:38",
				["player"] = "Milush-Lucifron",
			}, -- [29]
			{
				["time"] = "10/28/19 19:14:43",
				["player"] = "Tornag-Lucifron",
			}, -- [30]
			{
				["time"] = "10/28/19 19:17:47",
				["player"] = "Eisenhorn-Lucifron",
			}, -- [31]
			{
				["time"] = "10/28/19 19:17:47",
				["player"] = "Mattness-Lucifron",
			}, -- [32]
			{
				["time"] = "10/28/19 19:22:27",
				["player"] = "Testosterpwn-Lucifron",
			}, -- [33]
			{
				["time"] = "10/28/19 19:22:44",
				["player"] = "Schlimmbumm-Lucifron",
			}, -- [34]
			{
				["time"] = "10/28/19 19:22:53",
				["player"] = "Orkasmus-Lucifron",
			}, -- [35]
			{
				["time"] = "10/28/19 19:28:43",
				["player"] = "Happyziege-Lucifron",
			}, -- [36]
			{
				["time"] = "10/28/19 19:28:43",
				["player"] = "Mattness-Lucifron",
			}, -- [37]
			{
				["time"] = "10/28/19 19:28:43",
				["player"] = "Testosterpwn-Lucifron",
			}, -- [38]
			{
				["time"] = "10/28/19 19:28:43",
				["player"] = "Covox-Lucifron",
			}, -- [39]
			{
				["time"] = "10/28/19 19:28:43",
				["player"] = "Sukz-Lucifron",
			}, -- [40]
			{
				["time"] = "10/28/19 19:38:49",
				["player"] = "Rayle-Lucifron",
			}, -- [41]
			{
				["time"] = "10/28/19 19:38:49",
				["player"] = "Maehlîc-Lucifron",
			}, -- [42]
			{
				["time"] = "10/28/19 19:38:49",
				["player"] = "Bishamoto-Lucifron",
			}, -- [43]
			{
				["time"] = "10/28/19 19:38:49",
				["player"] = "Minzberd-Lucifron",
			}, -- [44]
			{
				["time"] = "10/28/19 19:38:49",
				["player"] = "Vengè-Lucifron",
			}, -- [45]
			{
				["time"] = "10/28/19 19:43:01",
				["player"] = "Tornag-Lucifron",
			}, -- [46]
			{
				["time"] = "10/28/19 19:43:04",
				["player"] = "Givewfproc-Lucifron",
			}, -- [47]
			{
				["time"] = "10/28/19 19:45:28",
				["player"] = "Daranasi-Lucifron",
			}, -- [48]
			{
				["time"] = "10/28/19 19:56:43",
				["player"] = "Minzberd-Lucifron",
			}, -- [49]
			{
				["time"] = "10/28/19 20:23:48",
				["player"] = "Covox-Lucifron",
			}, -- [50]
			{
				["time"] = "10/28/19 20:25:08",
				["player"] = "Maehlîc-Lucifron",
			}, -- [51]
			{
				["time"] = "10/28/19 20:25:36",
				["player"] = "Givewfproc-Lucifron",
			}, -- [52]
			{
				["time"] = "10/28/19 20:29:40",
				["player"] = "Covox-Lucifron",
			}, -- [53]
			{
				["time"] = "10/28/19 20:29:40",
				["player"] = "Orkasmus-Lucifron",
			}, -- [54]
			{
				["time"] = "10/28/19 20:29:40",
				["player"] = "Rondan-Lucifron",
			}, -- [55]
			{
				["time"] = "10/28/19 20:29:40",
				["player"] = "Bishamoto-Lucifron",
			}, -- [56]
			{
				["time"] = "10/28/19 20:29:40",
				["player"] = "Happyziege-Lucifron",
			}, -- [57]
			{
				["time"] = "10/28/19 20:29:40",
				["player"] = "Cramp-Lucifron",
			}, -- [58]
			{
				["time"] = "10/28/19 20:29:40",
				["player"] = "Zajini-Lucifron",
			}, -- [59]
			{
				["time"] = "10/28/19 20:29:40",
				["player"] = "Sukz-Lucifron",
			}, -- [60]
			{
				["time"] = "10/28/19 20:29:40",
				["player"] = "Illmore-Lucifron",
			}, -- [61]
			{
				["time"] = "10/28/19 20:29:40",
				["player"] = "Albion-Lucifron",
			}, -- [62]
			{
				["time"] = "10/28/19 20:29:40",
				["player"] = "Rocat-Lucifron",
			}, -- [63]
			{
				["time"] = "10/28/19 20:29:40",
				["player"] = "Bench-Lucifron",
			}, -- [64]
			{
				["time"] = "10/28/19 20:29:40",
				["player"] = "Dynast-Lucifron",
			}, -- [65]
			{
				["time"] = "10/28/19 20:29:40",
				["player"] = "Balanar-Lucifron",
			}, -- [66]
			{
				["time"] = "10/28/19 20:29:40",
				["player"] = "Guhl-Lucifron",
			}, -- [67]
			{
				["time"] = "10/28/19 20:29:40",
				["player"] = "Maehlîc-Lucifron",
			}, -- [68]
			{
				["time"] = "10/28/19 20:29:40",
				["player"] = "Vengè-Lucifron",
			}, -- [69]
			{
				["time"] = "10/28/19 20:29:40",
				["player"] = "Luckypriest-Lucifron",
			}, -- [70]
			{
				["time"] = "10/28/19 20:29:40",
				["player"] = "Daranasi-Lucifron",
			}, -- [71]
			{
				["time"] = "10/28/19 20:29:40",
				["player"] = "Givewfproc-Lucifron",
			}, -- [72]
			{
				["time"] = "10/28/19 20:29:40",
				["player"] = "Herrlich-Lucifron",
			}, -- [73]
			{
				["time"] = "10/28/19 20:29:40",
				["player"] = "Eisenhorn-Lucifron",
			}, -- [74]
			{
				["time"] = "10/28/19 20:29:40",
				["player"] = "Schlimmbumm-Lucifron",
			}, -- [75]
			{
				["time"] = "10/28/19 20:29:40",
				["player"] = "Testosterpwn-Lucifron",
			}, -- [76]
			{
				["time"] = "10/28/19 20:29:40",
				["player"] = "Dextros-Lucifron",
			}, -- [77]
			{
				["time"] = "10/28/19 20:29:40",
				["player"] = "Rayle-Lucifron",
			}, -- [78]
			{
				["time"] = "10/28/19 20:29:40",
				["player"] = "Arastus-Lucifron",
			}, -- [79]
			{
				["time"] = "10/28/19 20:29:40",
				["player"] = "Xinea-Lucifron",
			}, -- [80]
			{
				["time"] = "10/28/19 20:29:40",
				["player"] = "Nakanjo-Lucifron",
			}, -- [81]
			{
				["time"] = "10/28/19 20:29:40",
				["player"] = "Vacanta-Lucifron",
			}, -- [82]
			{
				["time"] = "10/28/19 20:29:40",
				["player"] = "Tornag-Lucifron",
			}, -- [83]
			{
				["time"] = "10/28/19 20:29:40",
				["player"] = "Naazir-Lucifron",
			}, -- [84]
			{
				["time"] = "10/28/19 20:29:40",
				["player"] = "Milush-Lucifron",
			}, -- [85]
			{
				["time"] = "10/28/19 20:29:40",
				["player"] = "Mattness-Lucifron",
			}, -- [86]
			{
				["time"] = "10/28/19 20:29:40",
				["player"] = "Minzberd-Lucifron",
			}, -- [87]
			{
				["time"] = "10/28/19 20:29:40",
				["player"] = "Ratwar-Lucifron",
			}, -- [88]
		},
		["End"] = "10/28/19 20:29:40",
		["Loot"] = {
			{
				["player"] = "Balanar-Lucifron",
				["item"] = {
					["name"] = "Onyxias Kopf",
					["id"] = "18422::::::::60:::::::",
					["count"] = 1,
					["tooltip"] = {
					},
					["subclass"] = "Quest",
					["class"] = "Quest",
					["icon"] = 134153,
					["c"] = "ffa335ee",
				},
				["zone"] = "Onyxias Hort",
				["attendees"] = {
				},
				["event_source"] = "Raid Tracker",
				["time"] = "10/28/19 20:22:22",
				["boss"] = "Trash mob",
			}, -- [1]
			{
				["player"] = "Orkasmus-Lucifron",
				["item"] = {
					["name"] = "Sehne eines ausgewachsenen schwarzen Drachen",
					["id"] = "18705::::::::60:::::::",
					["count"] = 1,
					["tooltip"] = {
					},
					["subclass"] = "Quest",
					["class"] = "Quest",
					["icon"] = 135894,
					["c"] = "ffa335ee",
				},
				["zone"] = "Onyxias Hort",
				["attendees"] = {
				},
				["event_source"] = "Raid Tracker",
				["time"] = "10/28/19 20:14:32",
				["boss"] = "Trash mob",
			}, -- [2]
			{
				["player"] = "Orkasmus-Lucifron",
				["item"] = {
					["name"] = "Bedeckung des Stormrage",
					["id"] = "16900::::::::60:::::::",
					["count"] = 1,
					["tooltip"] = {
					},
					["subclass"] = "Leder",
					["class"] = "Rüstung",
					["icon"] = 133077,
					["c"] = "ffa335ee",
				},
				["zone"] = "Onyxias Hort",
				["attendees"] = {
				},
				["event_source"] = "Raid Tracker",
				["time"] = "10/28/19 20:14:29",
				["boss"] = "Trash mob",
			}, -- [3]
			{
				["player"] = "Orkasmus-Lucifron",
				["item"] = {
					["name"] = "Schädelkappe der Nemesis",
					["id"] = "16929::::::::60:::::::",
					["count"] = 1,
					["tooltip"] = {
					},
					["subclass"] = "Stoff",
					["class"] = "Rüstung",
					["icon"] = 133076,
					["c"] = "ffa335ee",
				},
				["zone"] = "Onyxias Hort",
				["attendees"] = {
				},
				["event_source"] = "Raid Tracker",
				["time"] = "10/28/19 20:14:24",
				["boss"] = "Trash mob",
			}, -- [4]
			{
				["player"] = "Orkasmus-Lucifron",
				["item"] = {
					["name"] = "Saphirontuch",
					["id"] = "17078::::::::60:::::::",
					["count"] = 1,
					["tooltip"] = {
					},
					["subclass"] = "Stoff",
					["class"] = "Rüstung",
					["icon"] = 133768,
					["c"] = "ffa335ee",
				},
				["zone"] = "Onyxias Hort",
				["attendees"] = {
				},
				["event_source"] = "Raid Tracker",
				["time"] = "10/28/19 20:14:10",
				["boss"] = "Trash mob",
			}, -- [5]
		},
		["Join"] = {
			{
				["time"] = "10/28/19 19:05:13",
				["player"] = "Vacanta-Lucifron",
			}, -- [1]
			{
				["time"] = "10/28/19 19:05:13",
				["player"] = "Rocat-Lucifron",
			}, -- [2]
			{
				["time"] = "10/28/19 19:05:13",
				["player"] = "Rayle-Lucifron",
			}, -- [3]
			{
				["time"] = "10/28/19 19:05:13",
				["player"] = "Ratwar-Lucifron",
			}, -- [4]
			{
				["time"] = "10/28/19 19:05:13",
				["player"] = "Naazir-Lucifron",
			}, -- [5]
			{
				["time"] = "10/28/19 19:05:13",
				["player"] = "Zajini-Lucifron",
			}, -- [6]
			{
				["time"] = "10/28/19 19:05:13",
				["player"] = "Minzberd-Lucifron",
			}, -- [7]
			{
				["time"] = "10/28/19 19:05:13",
				["player"] = "Balanar-Lucifron",
			}, -- [8]
			{
				["time"] = "10/28/19 19:05:13",
				["player"] = "Dynast-Lucifron",
			}, -- [9]
			{
				["time"] = "10/28/19 19:05:13",
				["player"] = "Illmore-Lucifron",
			}, -- [10]
			{
				["time"] = "10/28/19 19:05:13",
				["player"] = "Luckypriest-Lucifron",
			}, -- [11]
			{
				["time"] = "10/28/19 19:05:13",
				["player"] = "Illmore-Lucifron",
			}, -- [12]
			{
				["time"] = "10/28/19 19:05:13",
				["player"] = "Luckypriest-Lucifron",
			}, -- [13]
			{
				["time"] = "10/28/19 19:05:44",
				["player"] = "Vacanta-Lucifron",
			}, -- [14]
			{
				["time"] = "10/28/19 19:05:44",
				["player"] = "Rocat-Lucifron",
			}, -- [15]
			{
				["time"] = "10/28/19 19:05:44",
				["player"] = "Rayle-Lucifron",
			}, -- [16]
			{
				["time"] = "10/28/19 19:05:44",
				["player"] = "Ratwar-Lucifron",
			}, -- [17]
			{
				["time"] = "10/28/19 19:05:44",
				["player"] = "Naazir-Lucifron",
			}, -- [18]
			{
				["time"] = "10/28/19 19:05:44",
				["player"] = "Zajini-Lucifron",
			}, -- [19]
			{
				["time"] = "10/28/19 19:05:44",
				["player"] = "Minzberd-Lucifron",
			}, -- [20]
			{
				["time"] = "10/28/19 19:05:44",
				["player"] = "Balanar-Lucifron",
			}, -- [21]
			{
				["time"] = "10/28/19 19:05:44",
				["player"] = "Dynast-Lucifron",
			}, -- [22]
			{
				["time"] = "10/28/19 19:06:14",
				["player"] = "Guhl-Lucifron",
			}, -- [23]
			{
				["time"] = "10/28/19 19:06:16",
				["player"] = "Nakanjo-Lucifron",
			}, -- [24]
			{
				["time"] = "10/28/19 19:06:16",
				["player"] = "Covox-Lucifron",
			}, -- [25]
			{
				["time"] = "10/28/19 19:07:48",
				["player"] = "Maehlîc-Lucifron",
			}, -- [26]
			{
				["time"] = "10/28/19 19:08:20",
				["player"] = "Bishamoto-Lucifron",
			}, -- [27]
			{
				["time"] = "10/28/19 19:08:30",
				["player"] = "Arastus-Lucifron",
			}, -- [28]
			{
				["time"] = "10/28/19 19:08:56",
				["player"] = "Mattness-Lucifron",
			}, -- [29]
			{
				["time"] = "10/28/19 19:09:21",
				["player"] = "Rondan-Lucifron",
			}, -- [30]
			{
				["time"] = "10/28/19 19:09:42",
				["player"] = "Herrlich-Lucifron",
			}, -- [31]
			{
				["time"] = "10/28/19 19:10:57",
				["player"] = "Bench-Lucifron",
			}, -- [32]
			{
				["time"] = "10/28/19 19:12:35",
				["player"] = "Albion-Lucifron",
			}, -- [33]
			{
				["time"] = "10/28/19 19:12:51",
				["player"] = "Xinea-Lucifron",
			}, -- [34]
			{
				["time"] = "10/28/19 19:12:51",
				["player"] = "Zajini-Lucifron",
			}, -- [35]
			{
				["time"] = "10/28/19 19:13:17",
				["player"] = "Cramp-Lucifron",
			}, -- [36]
			{
				["time"] = "10/28/19 19:13:22",
				["player"] = "Sukz-Lucifron",
			}, -- [37]
			{
				["time"] = "10/28/19 19:13:29",
				["player"] = "Dextros-Lucifron",
			}, -- [38]
			{
				["time"] = "10/28/19 19:14:43",
				["player"] = "Milush-Lucifron",
			}, -- [39]
			{
				["time"] = "10/28/19 19:14:44",
				["player"] = "Tornag-Lucifron",
			}, -- [40]
			{
				["time"] = "10/28/19 19:15:31",
				["player"] = "Mattness-Lucifron",
			}, -- [41]
			{
				["time"] = "10/28/19 19:17:47",
				["player"] = "Vengè-Lucifron",
			}, -- [42]
			{
				["time"] = "10/28/19 19:17:58",
				["player"] = "Eisenhorn-Lucifron",
			}, -- [43]
			{
				["time"] = "10/28/19 19:22:31",
				["player"] = "Testosterpwn-Lucifron",
			}, -- [44]
			{
				["time"] = "10/28/19 19:22:47",
				["player"] = "Schlimmbumm-Lucifron",
			}, -- [45]
			{
				["time"] = "10/28/19 19:23:08",
				["player"] = "Orkasmus-Lucifron",
			}, -- [46]
			{
				["time"] = "10/28/19 19:23:44",
				["player"] = "Covox-Lucifron",
			}, -- [47]
			{
				["time"] = "10/28/19 19:24:23",
				["player"] = "Mattness-Lucifron",
			}, -- [48]
			{
				["time"] = "10/28/19 19:28:48",
				["player"] = "Happyziege-Lucifron",
			}, -- [49]
			{
				["time"] = "10/28/19 19:38:49",
				["player"] = "Sukz-Lucifron",
			}, -- [50]
			{
				["time"] = "10/28/19 19:38:58",
				["player"] = "Testosterpwn-Lucifron",
			}, -- [51]
			{
				["time"] = "10/28/19 19:43:01",
				["player"] = "Rayle-Lucifron",
			}, -- [52]
			{
				["time"] = "10/28/19 19:43:09",
				["player"] = "Givewfproc-Lucifron",
			}, -- [53]
			{
				["time"] = "10/28/19 19:46:14",
				["player"] = "Daranasi-Lucifron",
			}, -- [54]
			{
				["time"] = "10/28/19 19:48:22",
				["player"] = "Minzberd-Lucifron",
			}, -- [55]
			{
				["time"] = "10/28/19 19:48:36",
				["player"] = "Vengè-Lucifron",
			}, -- [56]
			{
				["time"] = "10/28/19 19:56:44",
				["player"] = "Minzberd-Lucifron",
			}, -- [57]
			{
				["time"] = "10/28/19 19:57:16",
				["player"] = "Tornag-Lucifron",
			}, -- [58]
			{
				["time"] = "10/28/19 19:57:37",
				["player"] = "Maehlîc-Lucifron",
			}, -- [59]
			{
				["time"] = "10/28/19 19:57:40",
				["player"] = "Bishamoto-Lucifron",
			}, -- [60]
			{
				["time"] = "10/28/19 19:58:17",
				["player"] = "Covox-Lucifron",
			}, -- [61]
			{
				["time"] = "10/28/19 20:01:43",
				["player"] = "Mattness-Lucifron",
			}, -- [62]
			{
				["time"] = "10/28/19 20:25:36",
				["player"] = "Givewfproc-Lucifron",
			}, -- [63]
		},
		["PlayerInfos"] = {
			["Covox-Lucifron"] = {
			},
			["Orkasmus-Lucifron"] = {
			},
			["Rondan-Lucifron"] = {
			},
			["Bishamoto-Lucifron"] = {
			},
			["Happyziege-Lucifron"] = {
			},
			["Cramp-Lucifron"] = {
			},
			["Zajini-Lucifron"] = {
			},
			["Sukz-Lucifron"] = {
			},
			["Illmore-Lucifron"] = {
			},
			["Albion-Lucifron"] = {
			},
			["Rocat-Lucifron"] = {
			},
			["Bench-Lucifron"] = {
			},
			["Dynast-Lucifron"] = {
			},
			["Balanar-Lucifron"] = {
			},
			["Guhl-Lucifron"] = {
			},
			["Maehlîc-Lucifron"] = {
			},
			["Vengè-Lucifron"] = {
			},
			["Luckypriest-Lucifron"] = {
			},
			["Daranasi-Lucifron"] = {
			},
			["Givewfproc-Lucifron"] = {
			},
			["Herrlich-Lucifron"] = {
			},
			["Eisenhorn-Lucifron"] = {
			},
			["Testosterpwn-Lucifron"] = {
			},
			["Schlimmbumm-Lucifron"] = {
			},
			["Dextros-Lucifron"] = {
			},
			["Rayle-Lucifron"] = {
			},
			["Arastus-Lucifron"] = {
			},
			["Xinea-Lucifron"] = {
			},
			["Nakanjo-Lucifron"] = {
			},
			["Vacanta-Lucifron"] = {
			},
			["Tornag-Lucifron"] = {
			},
			["Naazir-Lucifron"] = {
			},
			["Milush-Lucifron"] = {
			},
			["Mattness-Lucifron"] = {
			},
			["Minzberd-Lucifron"] = {
			},
			["Ratwar-Lucifron"] = {
			},
		},
		["key"] = "10/28/19 19:05:13",
		["BossKills"] = {
		},
		["Realm"] = "Lucifron",
	}, -- [2]
	{
		["Leave"] = {
			{
				["time"] = "10/27/19 01:48:33",
				["player"] = "Herrlich-Lucifron",
			}, -- [1]
			{
				["time"] = "10/27/19 01:48:37",
				["player"] = "Tornag-Lucifron",
			}, -- [2]
			{
				["time"] = "10/27/19 01:52:49",
				["player"] = "Dynast-Lucifron",
			}, -- [3]
			{
				["time"] = "10/27/19 01:59:55",
				["player"] = "Herrlich-Lucifron",
			}, -- [4]
			{
				["time"] = "10/27/19 01:59:55",
				["player"] = "Älska-Lucifron",
			}, -- [5]
			{
				["time"] = "10/27/19 01:59:55",
				["player"] = "Dynast-Lucifron",
			}, -- [6]
			{
				["time"] = "10/27/19 01:59:55",
				["player"] = "Dextros-Lucifron",
			}, -- [7]
			{
				["time"] = "10/27/19 01:59:55",
				["player"] = "Luckypriest-Lucifron",
			}, -- [8]
			{
				["time"] = "10/27/19 01:59:55",
				["player"] = "Balanar-Lucifron",
			}, -- [9]
			{
				["time"] = "10/27/19 01:59:55",
				["player"] = "Tornag-Lucifron",
			}, -- [10]
		},
		["Join"] = {
			{
				["time"] = "10/27/19 01:48:33",
				["player"] = "Dextros-Lucifron",
			}, -- [1]
			{
				["time"] = "10/27/19 01:48:33",
				["player"] = "Herrlich-Lucifron",
			}, -- [2]
			{
				["time"] = "10/27/19 01:48:33",
				["player"] = "Balanar-Lucifron",
			}, -- [3]
			{
				["time"] = "10/27/19 01:48:33",
				["player"] = "Luckypriest-Lucifron",
			}, -- [4]
			{
				["time"] = "10/27/19 01:48:33",
				["player"] = "Älska-Lucifron",
			}, -- [5]
			{
				["time"] = "10/27/19 01:48:33",
				["player"] = "Dextros-Lucifron",
			}, -- [6]
			{
				["time"] = "10/27/19 01:48:33",
				["player"] = "Balanar-Lucifron",
			}, -- [7]
			{
				["time"] = "10/27/19 01:48:33",
				["player"] = "Luckypriest-Lucifron",
			}, -- [8]
			{
				["time"] = "10/27/19 01:48:33",
				["player"] = "Älska-Lucifron",
			}, -- [9]
			{
				["time"] = "10/27/19 01:49:12",
				["player"] = "Tornag-Lucifron",
			}, -- [10]
			{
				["time"] = "10/27/19 01:49:12",
				["player"] = "Herrlich-Lucifron",
			}, -- [11]
			{
				["time"] = "10/27/19 01:53:51",
				["player"] = "Dynast-Lucifron",
			}, -- [12]
		},
		["Loot"] = {
		},
		["End"] = "10/27/19 01:59:55",
		["BossKills"] = {
		},
		["key"] = "10/27/19 01:48:33",
		["PlayerInfos"] = {
			["Herrlich-Lucifron"] = {
			},
			["Dextros-Lucifron"] = {
			},
			["Dynast-Lucifron"] = {
			},
			["Älska-Lucifron"] = {
			},
			["Luckypriest-Lucifron"] = {
			},
			["Balanar-Lucifron"] = {
			},
			["Tornag-Lucifron"] = {
			},
		},
		["Realm"] = "Lucifron",
	}, -- [3]
	{
		["Leave"] = {
			{
				["time"] = "10/26/19 22:13:48",
				["player"] = "Odin-Lucifron",
			}, -- [1]
			{
				["time"] = "10/26/19 22:13:48",
				["player"] = "Nebogipfel-Lucifron",
			}, -- [2]
			{
				["time"] = "10/26/19 22:13:48",
				["player"] = "Unbekannt-Lucifron",
			}, -- [3]
			{
				["time"] = "10/26/19 22:13:48",
				["player"] = "Taigaful-Lucifron",
			}, -- [4]
			{
				["time"] = "10/26/19 22:13:48",
				["player"] = "Kurog-Lucifron",
			}, -- [5]
			{
				["time"] = "10/26/19 22:15:45",
				["player"] = "Balanar-Lucifron",
			}, -- [6]
			{
				["time"] = "10/26/19 22:16:55",
				["player"] = "Guhl-Lucifron",
			}, -- [7]
			{
				["time"] = "10/26/19 22:18:36",
				["player"] = "Herrlich-Lucifron",
			}, -- [8]
			{
				["time"] = "10/26/19 23:31:33",
				["player"] = "Herrlich-Lucifron",
			}, -- [9]
			{
				["time"] = "10/26/19 23:31:33",
				["player"] = "Nebogipfel-Lucifron",
			}, -- [10]
			{
				["time"] = "10/26/19 23:31:33",
				["player"] = "Unbekannt-Lucifron",
			}, -- [11]
			{
				["time"] = "10/26/19 23:31:33",
				["player"] = "Odin-Lucifron",
			}, -- [12]
			{
				["time"] = "10/26/19 23:31:33",
				["player"] = "Guhl-Lucifron",
			}, -- [13]
			{
				["time"] = "10/26/19 23:31:33",
				["player"] = "Taigaful-Lucifron",
			}, -- [14]
			{
				["time"] = "10/26/19 23:31:33",
				["player"] = "Kurog-Lucifron",
			}, -- [15]
			{
				["time"] = "10/26/19 23:31:33",
				["player"] = "Luckypriest-Lucifron",
			}, -- [16]
			{
				["time"] = "10/26/19 23:31:33",
				["player"] = "Balanar-Lucifron",
			}, -- [17]
			{
				["time"] = "10/26/19 23:31:33",
				["player"] = "Nyhhx-Lucifron",
			}, -- [18]
		},
		["Join"] = {
			{
				["time"] = "10/26/19 22:13:48",
				["player"] = "Odin-Lucifron",
			}, -- [1]
			{
				["time"] = "10/26/19 22:13:48",
				["player"] = "Nebogipfel-Lucifron",
			}, -- [2]
			{
				["time"] = "10/26/19 22:13:48",
				["player"] = "Unbekannt-Lucifron",
			}, -- [3]
			{
				["time"] = "10/26/19 22:13:48",
				["player"] = "Taigaful-Lucifron",
			}, -- [4]
			{
				["time"] = "10/26/19 22:13:48",
				["player"] = "Kurog-Lucifron",
			}, -- [5]
			{
				["time"] = "10/26/19 22:13:48",
				["player"] = "Luckypriest-Lucifron",
			}, -- [6]
			{
				["time"] = "10/26/19 22:13:48",
				["player"] = "Luckypriest-Lucifron",
			}, -- [7]
			{
				["time"] = "10/26/19 22:14:10",
				["player"] = "Odin-Lucifron",
			}, -- [8]
			{
				["time"] = "10/26/19 22:14:10",
				["player"] = "Nebogipfel-Lucifron",
			}, -- [9]
			{
				["time"] = "10/26/19 22:14:10",
				["player"] = "Nyhhx-Lucifron",
			}, -- [10]
			{
				["time"] = "10/26/19 22:14:10",
				["player"] = "Taigaful-Lucifron",
			}, -- [11]
			{
				["time"] = "10/26/19 22:14:10",
				["player"] = "Kurog-Lucifron",
			}, -- [12]
			{
				["time"] = "10/26/19 22:16:55",
				["player"] = "Balanar-Lucifron",
			}, -- [13]
			{
				["time"] = "10/26/19 22:18:36",
				["player"] = "Guhl-Lucifron",
			}, -- [14]
			{
				["time"] = "10/26/19 22:25:39",
				["player"] = "Herrlich-Lucifron",
			}, -- [15]
		},
		["Loot"] = {
		},
		["End"] = "10/26/19 23:31:33",
		["BossKills"] = {
		},
		["key"] = "10/26/19 22:13:48",
		["PlayerInfos"] = {
			["Herrlich-Lucifron"] = {
			},
			["Nebogipfel-Lucifron"] = {
			},
			["Unbekannt-Lucifron"] = {
			},
			["Odin-Lucifron"] = {
			},
			["Guhl-Lucifron"] = {
			},
			["Taigaful-Lucifron"] = {
			},
			["Kurog-Lucifron"] = {
			},
			["Luckypriest-Lucifron"] = {
			},
			["Nyhhx-Lucifron"] = {
			},
			["Balanar-Lucifron"] = {
			},
		},
		["Realm"] = "Lucifron",
	}, -- [4]
	{
		["Leave"] = {
			{
				["time"] = "10/23/19 18:29:50",
				["player"] = "Vacanta-Lucifron",
			}, -- [1]
			{
				["time"] = "10/23/19 18:29:50",
				["player"] = "Zajini-Lucifron",
			}, -- [2]
			{
				["time"] = "10/23/19 18:29:50",
				["player"] = "Arastus-Lucifron",
			}, -- [3]
			{
				["time"] = "10/23/19 18:29:50",
				["player"] = "Herrlich-Lucifron",
			}, -- [4]
			{
				["time"] = "10/23/19 18:29:50",
				["player"] = "Kindel-Lucifron",
			}, -- [5]
			{
				["time"] = "10/23/19 18:29:50",
				["player"] = "Cramp-Lucifron",
			}, -- [6]
			{
				["time"] = "10/23/19 18:29:50",
				["player"] = "Rayle-Lucifron",
			}, -- [7]
			{
				["time"] = "10/23/19 18:29:50",
				["player"] = "Sukz-Lucifron",
			}, -- [8]
			{
				["time"] = "10/23/19 18:29:50",
				["player"] = "Mattness-Lucifron",
			}, -- [9]
			{
				["time"] = "10/23/19 18:29:50",
				["player"] = "Yamakasie-Lucifron",
			}, -- [10]
			{
				["time"] = "10/23/19 18:29:50",
				["player"] = "Maybé-Lucifron",
			}, -- [11]
			{
				["time"] = "10/23/19 18:29:50",
				["player"] = "Givewfproc-Lucifron",
			}, -- [12]
			{
				["time"] = "10/23/19 18:29:50",
				["player"] = "Bishamoto-Lucifron",
			}, -- [13]
			{
				["time"] = "10/23/19 18:29:50",
				["player"] = "Naazir-Lucifron",
			}, -- [14]
			{
				["time"] = "10/23/19 18:29:50",
				["player"] = "Schlimmbumm-Lucifron",
			}, -- [15]
			{
				["time"] = "10/23/19 18:29:50",
				["player"] = "Balanar-Lucifron",
			}, -- [16]
			{
				["time"] = "10/23/19 18:32:02",
				["player"] = "Lucaro-Lucifron",
			}, -- [17]
			{
				["time"] = "10/23/19 18:37:32",
				["player"] = "Lucaro-Lucifron",
			}, -- [18]
			{
				["time"] = "10/23/19 18:39:43",
				["player"] = "Lucaro-Lucifron",
			}, -- [19]
			{
				["time"] = "10/23/19 18:42:22",
				["player"] = "Bishamoto-Lucifron",
			}, -- [20]
			{
				["time"] = "10/23/19 18:44:15",
				["player"] = "Zajini-Lucifron",
			}, -- [21]
			{
				["time"] = "10/23/19 18:44:15",
				["player"] = "Maybé-Lucifron",
			}, -- [22]
			{
				["time"] = "10/23/19 18:47:29",
				["player"] = "Mattness-Lucifron",
			}, -- [23]
			{
				["time"] = "10/23/19 18:47:56",
				["player"] = "Sukz-Lucifron",
			}, -- [24]
			{
				["time"] = "10/23/19 18:49:04",
				["player"] = "Zajini-Lucifron",
			}, -- [25]
			{
				["time"] = "10/23/19 18:49:04",
				["player"] = "Mattness-Lucifron",
			}, -- [26]
			{
				["time"] = "10/23/19 18:50:55",
				["player"] = "Sukz-Lucifron",
			}, -- [27]
			{
				["time"] = "10/23/19 18:50:55",
				["player"] = "Mattness-Lucifron",
			}, -- [28]
			{
				["time"] = "10/23/19 18:53:03",
				["player"] = "Herrlich-Lucifron",
			}, -- [29]
			{
				["time"] = "10/23/19 18:53:03",
				["player"] = "Mattness-Lucifron",
			}, -- [30]
			{
				["time"] = "10/23/19 18:53:03",
				["player"] = "Givewfproc-Lucifron",
			}, -- [31]
			{
				["time"] = "10/23/19 18:53:03",
				["player"] = "Maehlîc-Lucifron",
			}, -- [32]
			{
				["time"] = "10/23/19 18:54:23",
				["player"] = "Daranasi-Lucifron",
			}, -- [33]
			{
				["time"] = "10/23/19 18:55:02",
				["player"] = "Illmore-Lucifron",
			}, -- [34]
			{
				["time"] = "10/23/19 18:55:03",
				["player"] = "Happyziege-Lucifron",
			}, -- [35]
			{
				["time"] = "10/23/19 18:56:09",
				["player"] = "Bench-Lucifron",
			}, -- [36]
			{
				["time"] = "10/23/19 18:56:43",
				["player"] = "Pumpelz-Lucifron",
			}, -- [37]
			{
				["time"] = "10/23/19 18:57:06",
				["player"] = "Kindel-Lucifron",
			}, -- [38]
			{
				["time"] = "10/23/19 18:57:08",
				["player"] = "Mattness-Lucifron",
			}, -- [39]
			{
				["time"] = "10/23/19 18:57:15",
				["player"] = "Zajini-Lucifron",
			}, -- [40]
			{
				["time"] = "10/23/19 18:58:41",
				["player"] = "Eisenhorn-Lucifron",
			}, -- [41]
			{
				["time"] = "10/23/19 18:59:19",
				["player"] = "Mattness-Lucifron",
			}, -- [42]
			{
				["time"] = "10/23/19 18:59:34",
				["player"] = "Covox-Lucifron",
			}, -- [43]
			{
				["time"] = "10/23/19 19:00:32",
				["player"] = "Givewfproc-Lucifron",
			}, -- [44]
			{
				["time"] = "10/23/19 19:01:51",
				["player"] = "Pymplegionär-Lucifron",
			}, -- [45]
			{
				["time"] = "10/23/19 19:04:39",
				["player"] = "Bishamoto-Lucifron",
			}, -- [46]
			{
				["time"] = "10/23/19 19:04:50",
				["player"] = "Guhl-Lucifron",
			}, -- [47]
			{
				["time"] = "10/23/19 19:05:09",
				["player"] = "Minzberd-Lucifron",
			}, -- [48]
			{
				["time"] = "10/23/19 19:06:40",
				["player"] = "Herrlich-Lucifron",
			}, -- [49]
			{
				["time"] = "10/23/19 19:06:57",
				["player"] = "Yamakasie-Lucifron",
			}, -- [50]
			{
				["time"] = "10/23/19 19:07:46",
				["player"] = "Vacanta-Lucifron",
			}, -- [51]
			{
				["time"] = "10/23/19 19:07:46",
				["player"] = "Wassersklave-Lucifron",
			}, -- [52]
			{
				["time"] = "10/23/19 19:07:46",
				["player"] = "Balanar-Lucifron",
			}, -- [53]
			{
				["time"] = "10/23/19 19:07:59",
				["player"] = "Vengè-Lucifron",
			}, -- [54]
			{
				["time"] = "10/23/19 19:08:36",
				["player"] = "Vacanta-Lucifron",
			}, -- [55]
			{
				["time"] = "10/23/19 19:08:57",
				["player"] = "Tornag-Lucifron",
			}, -- [56]
			{
				["time"] = "10/23/19 19:10:29",
				["player"] = "Balanar-Lucifron",
			}, -- [57]
			{
				["time"] = "10/23/19 19:11:29",
				["player"] = "Rocat-Lucifron",
			}, -- [58]
			{
				["time"] = "10/23/19 19:11:30",
				["player"] = "Lucaro-Lucifron",
			}, -- [59]
			{
				["time"] = "10/23/19 19:11:49",
				["player"] = "Lyxembrulez-Lucifron",
			}, -- [60]
			{
				["time"] = "10/23/19 19:15:06",
				["player"] = "Bishamoto-Lucifron",
			}, -- [61]
			{
				["time"] = "10/23/19 19:16:06",
				["player"] = "Versasus-Lucifron",
			}, -- [62]
			{
				["time"] = "10/23/19 19:18:01",
				["player"] = "Ratwar-Lucifron",
			}, -- [63]
			{
				["time"] = "10/23/19 19:20:59",
				["player"] = "Nakanjo-Lucifron",
			}, -- [64]
			{
				["time"] = "10/23/19 19:23:10",
				["player"] = "Mattness-Lucifron",
			}, -- [65]
			{
				["time"] = "10/23/19 19:23:10",
				["player"] = "Zajini-Lucifron",
			}, -- [66]
			{
				["time"] = "10/23/19 19:31:59",
				["player"] = "Testosterpwn-Lucifron",
			}, -- [67]
			{
				["time"] = "10/23/19 19:48:18",
				["player"] = "Fulltaste-Lucifron",
			}, -- [68]
			{
				["time"] = "10/23/19 20:06:31",
				["player"] = "Dextros-Lucifron",
			}, -- [69]
			{
				["time"] = "10/23/19 20:23:52",
				["player"] = "Milush-Lucifron",
			}, -- [70]
			{
				["time"] = "10/23/19 20:33:50",
				["player"] = "Lyxembrulez-Lucifron",
			}, -- [71]
			{
				["time"] = "10/23/19 21:04:34",
				["player"] = "Poe-Lucifron",
			}, -- [72]
			{
				["time"] = "10/23/19 21:24:33",
				["player"] = "Lyxembrulez-Lucifron",
			}, -- [73]
			{
				["time"] = "10/23/19 21:29:39",
				["player"] = "Bench-Lucifron",
			}, -- [74]
			{
				["time"] = "10/23/19 21:45:01",
				["player"] = "Cramp-Lucifron",
			}, -- [75]
			{
				["time"] = "10/23/19 21:47:49",
				["player"] = "Yamakasie-Lucifron",
			}, -- [76]
			{
				["time"] = "10/23/19 21:51:56",
				["player"] = "Maehlîc-Lucifron",
			}, -- [77]
			{
				["time"] = "10/23/19 21:51:56",
				["player"] = "Cramp-Lucifron",
			}, -- [78]
			{
				["time"] = "10/23/19 21:55:27",
				["player"] = "Pumpelz-Lucifron",
			}, -- [79]
			{
				["time"] = "10/23/19 21:55:27",
				["player"] = "Covox-Lucifron",
			}, -- [80]
			{
				["time"] = "10/23/19 21:55:27",
				["player"] = "Vacanta-Lucifron",
			}, -- [81]
			{
				["time"] = "10/23/19 21:55:27",
				["player"] = "Naazir-Lucifron",
			}, -- [82]
			{
				["time"] = "10/23/19 21:55:27",
				["player"] = "Versasus-Lucifron",
			}, -- [83]
			{
				["time"] = "10/23/19 21:55:27",
				["player"] = "Lucaro-Lucifron",
			}, -- [84]
			{
				["time"] = "10/23/19 21:55:27",
				["player"] = "Happyziege-Lucifron",
			}, -- [85]
			{
				["time"] = "10/23/19 21:55:27",
				["player"] = "Cramp-Lucifron",
			}, -- [86]
			{
				["time"] = "10/23/19 21:55:27",
				["player"] = "Yamakasie-Lucifron",
			}, -- [87]
			{
				["time"] = "10/23/19 21:55:27",
				["player"] = "Zajini-Lucifron",
			}, -- [88]
			{
				["time"] = "10/23/19 21:55:27",
				["player"] = "Sukz-Lucifron",
			}, -- [89]
			{
				["time"] = "10/23/19 21:55:27",
				["player"] = "Illmore-Lucifron",
			}, -- [90]
			{
				["time"] = "10/23/19 21:55:27",
				["player"] = "Ratwar-Lucifron",
			}, -- [91]
			{
				["time"] = "10/23/19 21:55:27",
				["player"] = "Rocat-Lucifron",
			}, -- [92]
			{
				["time"] = "10/23/19 21:55:27",
				["player"] = "Bench-Lucifron",
			}, -- [93]
			{
				["time"] = "10/23/19 21:55:27",
				["player"] = "Pymplegionär-Lucifron",
			}, -- [94]
			{
				["time"] = "10/23/19 21:55:27",
				["player"] = "Wassersklave-Lucifron",
			}, -- [95]
			{
				["time"] = "10/23/19 21:55:27",
				["player"] = "Balanar-Lucifron",
			}, -- [96]
			{
				["time"] = "10/23/19 21:55:27",
				["player"] = "Guhl-Lucifron",
			}, -- [97]
			{
				["time"] = "10/23/19 21:55:27",
				["player"] = "Poe-Lucifron",
			}, -- [98]
			{
				["time"] = "10/23/19 21:55:27",
				["player"] = "Maehlîc-Lucifron",
			}, -- [99]
			{
				["time"] = "10/23/19 21:55:27",
				["player"] = "Maybé-Lucifron",
			}, -- [100]
			{
				["time"] = "10/23/19 21:55:27",
				["player"] = "Vengè-Lucifron",
			}, -- [101]
			{
				["time"] = "10/23/19 21:55:27",
				["player"] = "Milush-Lucifron",
			}, -- [102]
			{
				["time"] = "10/23/19 21:55:27",
				["player"] = "Fulltaste-Lucifron",
			}, -- [103]
			{
				["time"] = "10/23/19 21:55:27",
				["player"] = "Givewfproc-Lucifron",
			}, -- [104]
			{
				["time"] = "10/23/19 21:55:27",
				["player"] = "Herrlich-Lucifron",
			}, -- [105]
			{
				["time"] = "10/23/19 21:55:27",
				["player"] = "Eisenhorn-Lucifron",
			}, -- [106]
			{
				["time"] = "10/23/19 21:55:27",
				["player"] = "Luckypriest-Lucifron",
			}, -- [107]
			{
				["time"] = "10/23/19 21:55:27",
				["player"] = "Testosterpwn-Lucifron",
			}, -- [108]
			{
				["time"] = "10/23/19 21:55:27",
				["player"] = "Dextros-Lucifron",
			}, -- [109]
			{
				["time"] = "10/23/19 21:55:27",
				["player"] = "Rayle-Lucifron",
			}, -- [110]
			{
				["time"] = "10/23/19 21:55:27",
				["player"] = "Arastus-Lucifron",
			}, -- [111]
			{
				["time"] = "10/23/19 21:55:27",
				["player"] = "Mattness-Lucifron",
			}, -- [112]
			{
				["time"] = "10/23/19 21:55:27",
				["player"] = "Nakanjo-Lucifron",
			}, -- [113]
			{
				["time"] = "10/23/19 21:55:27",
				["player"] = "Bishamoto-Lucifron",
			}, -- [114]
			{
				["time"] = "10/23/19 21:55:27",
				["player"] = "Daranasi-Lucifron",
			}, -- [115]
			{
				["time"] = "10/23/19 21:55:27",
				["player"] = "Tornag-Lucifron",
			}, -- [116]
			{
				["time"] = "10/23/19 21:55:27",
				["player"] = "Lyxembrulez-Lucifron",
			}, -- [117]
			{
				["time"] = "10/23/19 21:55:27",
				["player"] = "Schlimmbumm-Lucifron",
			}, -- [118]
			{
				["time"] = "10/23/19 21:55:27",
				["player"] = "Minzberd-Lucifron",
			}, -- [119]
			{
				["time"] = "10/23/19 21:55:27",
				["player"] = "Kindel-Lucifron",
			}, -- [120]
		},
		["Join"] = {
			{
				["time"] = "10/23/19 18:29:50",
				["player"] = "Vacanta-Lucifron",
			}, -- [1]
			{
				["time"] = "10/23/19 18:29:50",
				["player"] = "Zajini-Lucifron",
			}, -- [2]
			{
				["time"] = "10/23/19 18:29:50",
				["player"] = "Arastus-Lucifron",
			}, -- [3]
			{
				["time"] = "10/23/19 18:29:50",
				["player"] = "Herrlich-Lucifron",
			}, -- [4]
			{
				["time"] = "10/23/19 18:29:50",
				["player"] = "Kindel-Lucifron",
			}, -- [5]
			{
				["time"] = "10/23/19 18:29:50",
				["player"] = "Cramp-Lucifron",
			}, -- [6]
			{
				["time"] = "10/23/19 18:29:50",
				["player"] = "Rayle-Lucifron",
			}, -- [7]
			{
				["time"] = "10/23/19 18:29:50",
				["player"] = "Sukz-Lucifron",
			}, -- [8]
			{
				["time"] = "10/23/19 18:29:50",
				["player"] = "Mattness-Lucifron",
			}, -- [9]
			{
				["time"] = "10/23/19 18:29:50",
				["player"] = "Yamakasie-Lucifron",
			}, -- [10]
			{
				["time"] = "10/23/19 18:29:50",
				["player"] = "Luckypriest-Lucifron",
			}, -- [11]
			{
				["time"] = "10/23/19 18:29:50",
				["player"] = "Maybé-Lucifron",
			}, -- [12]
			{
				["time"] = "10/23/19 18:29:50",
				["player"] = "Givewfproc-Lucifron",
			}, -- [13]
			{
				["time"] = "10/23/19 18:29:50",
				["player"] = "Bishamoto-Lucifron",
			}, -- [14]
			{
				["time"] = "10/23/19 18:29:50",
				["player"] = "Naazir-Lucifron",
			}, -- [15]
			{
				["time"] = "10/23/19 18:29:50",
				["player"] = "Schlimmbumm-Lucifron",
			}, -- [16]
			{
				["time"] = "10/23/19 18:29:50",
				["player"] = "Balanar-Lucifron",
			}, -- [17]
			{
				["time"] = "10/23/19 18:29:50",
				["player"] = "Luckypriest-Lucifron",
			}, -- [18]
			{
				["time"] = "10/23/19 18:32:02",
				["player"] = "Vacanta-Lucifron",
			}, -- [19]
			{
				["time"] = "10/23/19 18:32:02",
				["player"] = "Zajini-Lucifron",
			}, -- [20]
			{
				["time"] = "10/23/19 18:32:02",
				["player"] = "Arastus-Lucifron",
			}, -- [21]
			{
				["time"] = "10/23/19 18:32:02",
				["player"] = "Kindel-Lucifron",
			}, -- [22]
			{
				["time"] = "10/23/19 18:32:02",
				["player"] = "Rayle-Lucifron",
			}, -- [23]
			{
				["time"] = "10/23/19 18:32:02",
				["player"] = "Sukz-Lucifron",
			}, -- [24]
			{
				["time"] = "10/23/19 18:32:02",
				["player"] = "Mattness-Lucifron",
			}, -- [25]
			{
				["time"] = "10/23/19 18:32:02",
				["player"] = "Yamakasie-Lucifron",
			}, -- [26]
			{
				["time"] = "10/23/19 18:32:02",
				["player"] = "Maybé-Lucifron",
			}, -- [27]
			{
				["time"] = "10/23/19 18:32:02",
				["player"] = "Givewfproc-Lucifron",
			}, -- [28]
			{
				["time"] = "10/23/19 18:32:02",
				["player"] = "Bishamoto-Lucifron",
			}, -- [29]
			{
				["time"] = "10/23/19 18:32:02",
				["player"] = "Naazir-Lucifron",
			}, -- [30]
			{
				["time"] = "10/23/19 18:32:02",
				["player"] = "Schlimmbumm-Lucifron",
			}, -- [31]
			{
				["time"] = "10/23/19 18:32:02",
				["player"] = "Balanar-Lucifron",
			}, -- [32]
			{
				["time"] = "10/23/19 18:32:04",
				["player"] = "Lucaro-Lucifron",
			}, -- [33]
			{
				["time"] = "10/23/19 18:37:32",
				["player"] = "Cramp-Lucifron",
			}, -- [34]
			{
				["time"] = "10/23/19 18:37:33",
				["player"] = "Lucaro-Lucifron",
			}, -- [35]
			{
				["time"] = "10/23/19 18:42:23",
				["player"] = "Bishamoto-Lucifron",
			}, -- [36]
			{
				["time"] = "10/23/19 18:44:47",
				["player"] = "Maybé-Lucifron",
			}, -- [37]
			{
				["time"] = "10/23/19 18:45:43",
				["player"] = "Herrlich-Lucifron",
			}, -- [38]
			{
				["time"] = "10/23/19 18:47:56",
				["player"] = "Mattness-Lucifron",
			}, -- [39]
			{
				["time"] = "10/23/19 18:47:57",
				["player"] = "Sukz-Lucifron",
			}, -- [40]
			{
				["time"] = "10/23/19 18:48:05",
				["player"] = "Zajini-Lucifron",
			}, -- [41]
			{
				["time"] = "10/23/19 18:49:05",
				["player"] = "Mattness-Lucifron",
			}, -- [42]
			{
				["time"] = "10/23/19 18:49:08",
				["player"] = "Zajini-Lucifron",
			}, -- [43]
			{
				["time"] = "10/23/19 18:50:56",
				["player"] = "Mattness-Lucifron",
			}, -- [44]
			{
				["time"] = "10/23/19 18:53:08",
				["player"] = "Givewfproc-Lucifron",
			}, -- [45]
			{
				["time"] = "10/23/19 18:53:08",
				["player"] = "Maehlîc-Lucifron",
			}, -- [46]
			{
				["time"] = "10/23/19 18:53:20",
				["player"] = "Mattness-Lucifron",
			}, -- [47]
			{
				["time"] = "10/23/19 18:53:59",
				["player"] = "Herrlich-Lucifron",
			}, -- [48]
			{
				["time"] = "10/23/19 18:54:23",
				["player"] = "Daranasi-Lucifron",
			}, -- [49]
			{
				["time"] = "10/23/19 18:55:03",
				["player"] = "Illmore-Lucifron",
			}, -- [50]
			{
				["time"] = "10/23/19 18:56:09",
				["player"] = "Vengè-Lucifron",
			}, -- [51]
			{
				["time"] = "10/23/19 18:56:09",
				["player"] = "Happyziege-Lucifron",
			}, -- [52]
			{
				["time"] = "10/23/19 18:56:26",
				["player"] = "Bench-Lucifron",
			}, -- [53]
			{
				["time"] = "10/23/19 18:56:34",
				["player"] = "Lucaro-Lucifron",
			}, -- [54]
			{
				["time"] = "10/23/19 18:57:06",
				["player"] = "Pumpelz-Lucifron",
			}, -- [55]
			{
				["time"] = "10/23/19 18:57:13",
				["player"] = "Mattness-Lucifron",
			}, -- [56]
			{
				["time"] = "10/23/19 18:58:48",
				["player"] = "Eisenhorn-Lucifron",
			}, -- [57]
			{
				["time"] = "10/23/19 19:00:32",
				["player"] = "Covox-Lucifron",
			}, -- [58]
			{
				["time"] = "10/23/19 19:01:51",
				["player"] = "Givewfproc-Lucifron",
			}, -- [59]
			{
				["time"] = "10/23/19 19:02:03",
				["player"] = "Pymplegionär-Lucifron",
			}, -- [60]
			{
				["time"] = "10/23/19 19:05:09",
				["player"] = "Guhl-Lucifron",
			}, -- [61]
			{
				["time"] = "10/23/19 19:06:40",
				["player"] = "Minzberd-Lucifron",
			}, -- [62]
			{
				["time"] = "10/23/19 19:07:59",
				["player"] = "Vacanta-Lucifron",
			}, -- [63]
			{
				["time"] = "10/23/19 19:08:07",
				["player"] = "Balanar-Lucifron",
			}, -- [64]
			{
				["time"] = "10/23/19 19:08:57",
				["player"] = "Wassersklave-Lucifron",
			}, -- [65]
			{
				["time"] = "10/23/19 19:10:29",
				["player"] = "Tornag-Lucifron",
			}, -- [66]
			{
				["time"] = "10/23/19 19:11:30",
				["player"] = "Rocat-Lucifron",
			}, -- [67]
			{
				["time"] = "10/23/19 19:11:30",
				["player"] = "Sukz-Lucifron",
			}, -- [68]
			{
				["time"] = "10/23/19 19:11:45",
				["player"] = "Bishamoto-Lucifron",
			}, -- [69]
			{
				["time"] = "10/23/19 19:11:55",
				["player"] = "Lyxembrulez-Lucifron",
			}, -- [70]
			{
				["time"] = "10/23/19 19:12:32",
				["player"] = "Herrlich-Lucifron",
			}, -- [71]
			{
				["time"] = "10/23/19 19:12:53",
				["player"] = "Vengè-Lucifron",
			}, -- [72]
			{
				["time"] = "10/23/19 19:13:21",
				["player"] = "Zajini-Lucifron",
			}, -- [73]
			{
				["time"] = "10/23/19 19:14:12",
				["player"] = "Balanar-Lucifron",
			}, -- [74]
			{
				["time"] = "10/23/19 19:15:07",
				["player"] = "Mattness-Lucifron",
			}, -- [75]
			{
				["time"] = "10/23/19 19:15:23",
				["player"] = "Kindel-Lucifron",
			}, -- [76]
			{
				["time"] = "10/23/19 19:17:51",
				["player"] = "Versasus-Lucifron",
			}, -- [77]
			{
				["time"] = "10/23/19 19:18:02",
				["player"] = "Ratwar-Lucifron",
			}, -- [78]
			{
				["time"] = "10/23/19 19:19:29",
				["player"] = "Vacanta-Lucifron",
			}, -- [79]
			{
				["time"] = "10/23/19 19:20:53",
				["player"] = "Bishamoto-Lucifron",
			}, -- [80]
			{
				["time"] = "10/23/19 19:21:00",
				["player"] = "Nakanjo-Lucifron",
			}, -- [81]
			{
				["time"] = "10/23/19 19:23:10",
				["player"] = "Yamakasie-Lucifron",
			}, -- [82]
			{
				["time"] = "10/23/19 19:23:16",
				["player"] = "Zajini-Lucifron",
			}, -- [83]
			{
				["time"] = "10/23/19 19:23:23",
				["player"] = "Mattness-Lucifron",
			}, -- [84]
			{
				["time"] = "10/23/19 19:29:30",
				["player"] = "Lucaro-Lucifron",
			}, -- [85]
			{
				["time"] = "10/23/19 19:33:53",
				["player"] = "Testosterpwn-Lucifron",
			}, -- [86]
			{
				["time"] = "10/23/19 20:06:31",
				["player"] = "Fulltaste-Lucifron",
			}, -- [87]
			{
				["time"] = "10/23/19 20:23:52",
				["player"] = "Dextros-Lucifron",
			}, -- [88]
			{
				["time"] = "10/23/19 20:24:04",
				["player"] = "Milush-Lucifron",
			}, -- [89]
			{
				["time"] = "10/23/19 20:33:50",
				["player"] = "Lyxembrulez-Lucifron",
			}, -- [90]
			{
				["time"] = "10/23/19 21:24:33",
				["player"] = "Poe-Lucifron",
			}, -- [91]
			{
				["time"] = "10/23/19 21:24:33",
				["player"] = "Lyxembrulez-Lucifron",
			}, -- [92]
			{
				["time"] = "10/23/19 21:29:39",
				["player"] = "Bench-Lucifron",
			}, -- [93]
			{
				["time"] = "10/23/19 21:49:33",
				["player"] = "Cramp-Lucifron",
			}, -- [94]
		},
		["Loot"] = {
			{
				["player"] = "Poe-Lucifron",
				["item"] = {
					["c"] = "ffa335ee",
					["subclass"] = "Stoff",
					["name"] = "Gamaschen der Erhabenheit",
					["class"] = "Rüstung",
					["id"] = "16922::::::::58:::::::",
					["tooltip"] = {
					},
					["icon"] = 134588,
					["count"] = 1,
				},
				["zone"] = "Geschmolzener Kern",
				["boss"] = "Trash mob",
				["event_source"] = "Raid Tracker",
				["time"] = "10/23/19 21:42:38",
				["attendees"] = {
				},
			}, -- [1]
			{
				["player"] = "Vacanta-Lucifron",
				["item"] = {
					["c"] = "ffa335ee",
					["subclass"] = "Platte",
					["name"] = "Beinplatten des Zorns",
					["class"] = "Rüstung",
					["id"] = "16962::::::::58:::::::",
					["tooltip"] = {
					},
					["icon"] = 134584,
					["count"] = 1,
				},
				["zone"] = "Geschmolzener Kern",
				["boss"] = "Trash mob",
				["event_source"] = "Raid Tracker",
				["time"] = "10/23/19 21:41:31",
				["attendees"] = {
				},
			}, -- [2]
			{
				["player"] = "Rayle-Lucifron",
				["item"] = {
					["c"] = "ffa335ee",
					["subclass"] = "Dolche",
					["name"] = "Kernhundzahn",
					["class"] = "Waffe",
					["id"] = "18805::::::::58:::::::",
					["tooltip"] = {
					},
					["icon"] = 135647,
					["count"] = 1,
				},
				["zone"] = "Geschmolzener Kern",
				["boss"] = "Trash mob",
				["event_source"] = "Raid Tracker",
				["time"] = "10/23/19 21:23:07",
				["attendees"] = {
				},
			}, -- [3]
			{
				["player"] = "Vengè-Lucifron",
				["item"] = {
					["c"] = "ffa335ee",
					["subclass"] = "Verschiedenes",
					["name"] = "Das Auge der Offenbarung",
					["class"] = "Rüstung",
					["id"] = "18646::::::::58:::::::",
					["tooltip"] = {
					},
					["icon"] = 135933,
					["count"] = 1,
				},
				["zone"] = "Geschmolzener Kern",
				["boss"] = "Trash mob",
				["event_source"] = "Raid Tracker",
				["time"] = "10/23/19 21:21:07",
				["attendees"] = {
				},
			}, -- [4]
			{
				["player"] = "Schlimmbumm-Lucifron",
				["item"] = {
					["c"] = "ffa335ee",
					["subclass"] = "Stäbe",
					["name"] = "Stab der Dominanz",
					["class"] = "Waffe",
					["id"] = "18842::::::::58:::::::",
					["tooltip"] = {
					},
					["icon"] = 135150,
					["count"] = 1,
				},
				["zone"] = "Geschmolzener Kern",
				["boss"] = "Trash mob",
				["event_source"] = "Raid Tracker",
				["time"] = "10/23/19 21:13:04",
				["attendees"] = {
				},
			}, -- [5]
			{
				["player"] = "Rocat-Lucifron",
				["item"] = {
					["c"] = "ffa335ee",
					["subclass"] = "Schwere Rüstung",
					["name"] = "Brustplatte des Riesenjägers",
					["class"] = "Rüstung",
					["id"] = "16845::::::::58:::::::",
					["tooltip"] = {
					},
					["icon"] = 132625,
					["count"] = 1,
				},
				["zone"] = "Geschmolzener Kern",
				["boss"] = "Trash mob",
				["event_source"] = "Raid Tracker",
				["time"] = "10/23/19 21:10:53",
				["attendees"] = {
				},
			}, -- [6]
			{
				["player"] = "Fulltaste-Lucifron",
				["item"] = {
					["c"] = "ffa335ee",
					["subclass"] = "Stangenwaffen",
					["name"] = "Schattenschlag",
					["class"] = "Waffe",
					["id"] = "17074::::::::58:::::::",
					["tooltip"] = {
					},
					["icon"] = 135131,
					["count"] = 1,
				},
				["zone"] = "Geschmolzener Kern",
				["boss"] = "Trash mob",
				["event_source"] = "Raid Tracker",
				["time"] = "10/23/19 21:03:47",
				["attendees"] = {
				},
			}, -- [7]
			{
				["player"] = "Versasus-Lucifron",
				["item"] = {
					["c"] = "ffa335ee",
					["subclass"] = "Leder",
					["name"] = "Schulterklappen des Nachtmeuchlers",
					["class"] = "Rüstung",
					["id"] = "16823::::::::58:::::::",
					["tooltip"] = {
					},
					["icon"] = 135056,
					["count"] = 1,
				},
				["zone"] = "Geschmolzener Kern",
				["boss"] = "Trash mob",
				["event_source"] = "Raid Tracker",
				["time"] = "10/23/19 21:02:50",
				["attendees"] = {
				},
			}, -- [8]
			{
				["player"] = "Maybé-Lucifron",
				["item"] = {
					["c"] = "ffa335ee",
					["subclass"] = "Leder",
					["name"] = "Armschienen des Cenarius",
					["class"] = "Rüstung",
					["id"] = "16830::::::::58:::::::",
					["tooltip"] = {
					},
					["icon"] = 132602,
					["count"] = 1,
				},
				["zone"] = "Geschmolzener Kern",
				["boss"] = "Trash mob",
				["event_source"] = "Raid Tracker",
				["time"] = "10/23/19 20:54:45",
				["attendees"] = {
				},
			}, -- [9]
			{
				["player"] = "Eisenhorn-Lucifron",
				["item"] = {
					["c"] = "ffa335ee",
					["subclass"] = "Stoff",
					["name"] = "Teufelsherzschuhe",
					["class"] = "Rüstung",
					["id"] = "16803::::::::58:::::::",
					["tooltip"] = {
					},
					["icon"] = 132562,
					["count"] = 1,
				},
				["zone"] = "Geschmolzener Kern",
				["boss"] = "Trash mob",
				["event_source"] = "Raid Tracker",
				["time"] = "10/23/19 20:44:30",
				["attendees"] = {
				},
			}, -- [10]
			{
				["player"] = "Naazir-Lucifron",
				["item"] = {
					["c"] = "ffa335ee",
					["subclass"] = "Schwere Rüstung",
					["name"] = "Handschuhe des Riesenjägers",
					["class"] = "Rüstung",
					["id"] = "16852::::::::58:::::::",
					["tooltip"] = {
					},
					["icon"] = 132944,
					["count"] = 1,
				},
				["zone"] = "Geschmolzener Kern",
				["boss"] = "Trash mob",
				["event_source"] = "Raid Tracker",
				["time"] = "10/23/19 20:44:06",
				["attendees"] = {
				},
			}, -- [11]
			{
				["player"] = "Guhl-Lucifron",
				["item"] = {
					["count"] = 1,
					["id"] = "16807::::::::58:::::::",
					["c"] = "ffa335ee",
					["tooltip"] = {
					},
					["subclass"] = "Stoff",
					["class"] = "Rüstung",
					["icon"] = 135054,
					["name"] = "Teufelsherzschulterpolster",
				},
				["zone"] = "Geschmolzener Kern",
				["attendees"] = {
				},
				["event_source"] = "Raid Tracker",
				["time"] = "10/23/19 20:33:56",
				["boss"] = "Trash mob",
			}, -- [12]
			{
				["player"] = "Nakanjo-Lucifron",
				["item"] = {
					["count"] = 1,
					["id"] = "16836::::::::58:::::::",
					["c"] = "ffa335ee",
					["tooltip"] = {
					},
					["subclass"] = "Leder",
					["class"] = "Rüstung",
					["icon"] = 135038,
					["name"] = "Schiftung des Cenarius",
				},
				["zone"] = "Geschmolzener Kern",
				["attendees"] = {
				},
				["event_source"] = "Raid Tracker",
				["time"] = "10/23/19 20:33:23",
				["boss"] = "Trash mob",
			}, -- [13]
			{
				["player"] = "Mattness-Lucifron",
				["item"] = {
					["count"] = 1,
					["id"] = "18822::::::::58:::::::",
					["c"] = "ffa335ee",
					["tooltip"] = {
					},
					["subclass"] = "Zweihandschwerter",
					["class"] = "Waffe",
					["icon"] = 135329,
					["name"] = "Scharfkantige Obsidianklinge",
				},
				["zone"] = "Geschmolzener Kern",
				["attendees"] = {
				},
				["event_source"] = "Raid Tracker",
				["time"] = "10/23/19 20:24:38",
				["boss"] = "Trash mob",
			}, -- [14]
			{
				["player"] = "Rayle-Lucifron",
				["item"] = {
					["count"] = 1,
					["id"] = "16821::::::::58:::::::",
					["c"] = "ffa335ee",
					["tooltip"] = {
					},
					["subclass"] = "Leder",
					["class"] = "Rüstung",
					["icon"] = 133143,
					["name"] = "Kopfschutz des Nachtmeuchlers",
				},
				["zone"] = "Geschmolzener Kern",
				["attendees"] = {
				},
				["event_source"] = "Raid Tracker",
				["time"] = "10/23/19 20:22:19",
				["boss"] = "Trash mob",
			}, -- [15]
			{
				["player"] = "Tornag-Lucifron",
				["item"] = {
					["count"] = 1,
					["id"] = "16842::::::::58:::::::",
					["c"] = "ffa335ee",
					["tooltip"] = {
					},
					["subclass"] = "Schwere Rüstung",
					["class"] = "Rüstung",
					["icon"] = 133077,
					["name"] = "Helm der Erdenwut",
				},
				["zone"] = "Geschmolzener Kern",
				["attendees"] = {
				},
				["event_source"] = "Raid Tracker",
				["time"] = "10/23/19 20:21:13",
				["boss"] = "Trash mob",
			}, -- [16]
			{
				["player"] = "Rocat-Lucifron",
				["item"] = {
					["count"] = 1,
					["id"] = "16849::::::::58:::::::",
					["c"] = "ffa335ee",
					["tooltip"] = {
					},
					["subclass"] = "Schwere Rüstung",
					["class"] = "Rüstung",
					["icon"] = 132556,
					["name"] = "Stiefel des Riesenjägers",
				},
				["zone"] = "Geschmolzener Kern",
				["attendees"] = {
				},
				["event_source"] = "Raid Tracker",
				["time"] = "10/23/19 20:06:11",
				["boss"] = "Trash mob",
			}, -- [17]
			{
				["player"] = "Givewfproc-Lucifron",
				["item"] = {
					["count"] = 1,
					["id"] = "16839::::::::58:::::::",
					["c"] = "ffa335ee",
					["tooltip"] = {
					},
					["subclass"] = "Schwere Rüstung",
					["class"] = "Rüstung",
					["icon"] = 132945,
					["name"] = "Stulpen der Erdenwut",
				},
				["zone"] = "Geschmolzener Kern",
				["attendees"] = {
				},
				["event_source"] = "Raid Tracker",
				["time"] = "10/23/19 20:05:39",
				["boss"] = "Trash mob",
			}, -- [18]
			{
				["player"] = "Arastus-Lucifron",
				["item"] = {
					["count"] = 1,
					["id"] = "17069::::::::58:::::::",
					["c"] = "ffa335ee",
					["tooltip"] = {
					},
					["subclass"] = "Bogen",
					["class"] = "Waffe",
					["icon"] = 135496,
					["name"] = "Schläger-Mal",
				},
				["zone"] = "Geschmolzener Kern",
				["attendees"] = {
				},
				["event_source"] = "Raid Tracker",
				["time"] = "10/23/19 19:59:43",
				["boss"] = "Trash mob",
			}, -- [19]
			{
				["player"] = "Lyxembrulez-Lucifron",
				["item"] = {
					["count"] = 1,
					["id"] = "16843::::::::58:::::::",
					["c"] = "ffa335ee",
					["tooltip"] = {
					},
					["subclass"] = "Schwere Rüstung",
					["class"] = "Rüstung",
					["icon"] = 134583,
					["name"] = "Beinschützer der Erdenwut",
				},
				["zone"] = "Geschmolzener Kern",
				["attendees"] = {
				},
				["event_source"] = "Raid Tracker",
				["time"] = "10/23/19 19:56:17",
				["boss"] = "Trash mob",
			}, -- [20]
			{
				["player"] = "Tornag-Lucifron",
				["item"] = {
					["count"] = 1,
					["id"] = "17073::::::::58:::::::",
					["c"] = "ffa335ee",
					["tooltip"] = {
					},
					["subclass"] = "Zweihandstreitkolben",
					["class"] = "Waffe",
					["icon"] = 133041,
					["name"] = "Erderschütterer",
				},
				["zone"] = "Geschmolzener Kern",
				["attendees"] = {
				},
				["event_source"] = "Raid Tracker",
				["time"] = "10/23/19 19:55:04",
				["boss"] = "Trash mob",
			}, -- [21]
			{
				["player"] = "Bishamoto-Lucifron",
				["item"] = {
					["count"] = 1,
					["id"] = "16800::::::::58:::::::",
					["c"] = "ffa335ee",
					["tooltip"] = {
					},
					["subclass"] = "Stoff",
					["class"] = "Rüstung",
					["icon"] = 132541,
					["name"] = "Stiefel des Arkanisten",
				},
				["zone"] = "Geschmolzener Kern",
				["attendees"] = {
				},
				["event_source"] = "Raid Tracker",
				["time"] = "10/23/19 19:49:32",
				["boss"] = "Trash mob",
			}, -- [22]
			{
				["player"] = "Herrlich-Lucifron",
				["item"] = {
					["count"] = 1,
					["id"] = "16863::::::::58:::::::",
					["c"] = "ffa335ee",
					["tooltip"] = {
					},
					["subclass"] = "Platte",
					["class"] = "Rüstung",
					["icon"] = 132944,
					["name"] = "Stulpen der Macht",
				},
				["zone"] = "Geschmolzener Kern",
				["attendees"] = {
				},
				["event_source"] = "Raid Tracker",
				["time"] = "10/23/19 19:47:34",
				["boss"] = "Trash mob",
			}, -- [23]
		},
		["End"] = "10/23/19 21:55:27",
		["BossKills"] = {
		},
		["key"] = "10/23/19 18:29:50",
		["PlayerInfos"] = {
			["Pumpelz-Lucifron"] = {
			},
			["Covox-Lucifron"] = {
			},
			["Vacanta-Lucifron"] = {
			},
			["Naazir-Lucifron"] = {
			},
			["Versasus-Lucifron"] = {
			},
			["Lucaro-Lucifron"] = {
			},
			["Happyziege-Lucifron"] = {
			},
			["Cramp-Lucifron"] = {
			},
			["Yamakasie-Lucifron"] = {
			},
			["Zajini-Lucifron"] = {
			},
			["Sukz-Lucifron"] = {
			},
			["Illmore-Lucifron"] = {
			},
			["Ratwar-Lucifron"] = {
			},
			["Rocat-Lucifron"] = {
			},
			["Bench-Lucifron"] = {
			},
			["Pymplegionär-Lucifron"] = {
			},
			["Wassersklave-Lucifron"] = {
			},
			["Balanar-Lucifron"] = {
			},
			["Guhl-Lucifron"] = {
			},
			["Poe-Lucifron"] = {
			},
			["Maehlîc-Lucifron"] = {
			},
			["Milush-Lucifron"] = {
			},
			["Vengè-Lucifron"] = {
			},
			["Maybé-Lucifron"] = {
			},
			["Fulltaste-Lucifron"] = {
			},
			["Schlimmbumm-Lucifron"] = {
			},
			["Herrlich-Lucifron"] = {
			},
			["Eisenhorn-Lucifron"] = {
			},
			["Lyxembrulez-Lucifron"] = {
			},
			["Testosterpwn-Lucifron"] = {
			},
			["Dextros-Lucifron"] = {
			},
			["Rayle-Lucifron"] = {
			},
			["Arastus-Lucifron"] = {
			},
			["Tornag-Lucifron"] = {
			},
			["Nakanjo-Lucifron"] = {
			},
			["Daranasi-Lucifron"] = {
			},
			["Bishamoto-Lucifron"] = {
			},
			["Mattness-Lucifron"] = {
			},
			["Luckypriest-Lucifron"] = {
			},
			["Givewfproc-Lucifron"] = {
			},
			["Minzberd-Lucifron"] = {
			},
			["Kindel-Lucifron"] = {
			},
		},
		["Realm"] = "Lucifron",
	}, -- [5]
	{
		["Leave"] = {
			{
				["time"] = "10/23/19 18:14:22",
				["player"] = "Mattness-Lucifron",
			}, -- [1]
			{
				["time"] = "10/23/19 18:14:22",
				["player"] = "Zajini-Lucifron",
			}, -- [2]
			{
				["time"] = "10/23/19 18:14:22",
				["player"] = "Herrlich-Lucifron",
			}, -- [3]
			{
				["time"] = "10/23/19 18:14:22",
				["player"] = "Helmar-Lucifron",
			}, -- [4]
			{
				["time"] = "10/23/19 18:14:22",
				["player"] = "Cramp-Lucifron",
			}, -- [5]
			{
				["time"] = "10/23/19 18:14:22",
				["player"] = "Rayle-Lucifron",
			}, -- [6]
			{
				["time"] = "10/23/19 18:20:39",
				["player"] = "Kindel-Lucifron",
			}, -- [7]
			{
				["time"] = "10/23/19 18:21:06",
				["player"] = "Vacanta-Lucifron",
			}, -- [8]
			{
				["time"] = "10/23/19 18:21:21",
				["player"] = "Yamakasie-Lucifron",
			}, -- [9]
			{
				["time"] = "10/23/19 18:22:39",
				["player"] = "Sukz-Lucifron",
			}, -- [10]
			{
				["time"] = "10/23/19 18:23:35",
				["player"] = "Maybé-Lucifron",
			}, -- [11]
			{
				["time"] = "10/23/19 18:23:37",
				["player"] = "Givewfproc-Lucifron",
			}, -- [12]
			{
				["time"] = "10/23/19 18:23:48",
				["player"] = "Bishamoto-Lucifron",
			}, -- [13]
			{
				["time"] = "10/23/19 18:23:59",
				["player"] = "Naazir-Lucifron",
			}, -- [14]
			{
				["time"] = "10/23/19 18:24:42",
				["player"] = "Schlimmbumm-Lucifron",
			}, -- [15]
			{
				["time"] = "10/23/19 18:27:56",
				["player"] = "Kindel-Lucifron",
			}, -- [16]
			{
				["time"] = "10/23/19 18:27:56",
				["player"] = "Balanar-Lucifron",
			}, -- [17]
			{
				["time"] = "10/23/19 18:29:26",
				["player"] = "Helmar-Lucifron",
			}, -- [18]
			{
				["time"] = "10/23/19 18:29:26",
				["player"] = "Balanar-Lucifron",
			}, -- [19]
			{
				["time"] = "10/23/19 18:29:26",
				["player"] = "Vacanta-Lucifron",
			}, -- [20]
			{
				["time"] = "10/23/19 18:29:26",
				["player"] = "Bishamoto-Lucifron",
			}, -- [21]
			{
				["time"] = "10/23/19 18:29:26",
				["player"] = "Mattness-Lucifron",
			}, -- [22]
			{
				["time"] = "10/23/19 18:29:26",
				["player"] = "Luckypriest-Lucifron",
			}, -- [23]
			{
				["time"] = "10/23/19 18:29:26",
				["player"] = "Herrlich-Lucifron",
			}, -- [24]
			{
				["time"] = "10/23/19 18:29:26",
				["player"] = "Cramp-Lucifron",
			}, -- [25]
			{
				["time"] = "10/23/19 18:29:26",
				["player"] = "Yamakasie-Lucifron",
			}, -- [26]
			{
				["time"] = "10/23/19 18:29:26",
				["player"] = "Zajini-Lucifron",
			}, -- [27]
			{
				["time"] = "10/23/19 18:29:26",
				["player"] = "Sukz-Lucifron",
			}, -- [28]
			{
				["time"] = "10/23/19 18:29:26",
				["player"] = "Arastus-Lucifron",
			}, -- [29]
			{
				["time"] = "10/23/19 18:29:26",
				["player"] = "Givewfproc-Lucifron",
			}, -- [30]
			{
				["time"] = "10/23/19 18:29:26",
				["player"] = "Schlimmbumm-Lucifron",
			}, -- [31]
			{
				["time"] = "10/23/19 18:29:26",
				["player"] = "Naazir-Lucifron",
			}, -- [32]
			{
				["time"] = "10/23/19 18:29:26",
				["player"] = "Rayle-Lucifron",
			}, -- [33]
			{
				["time"] = "10/23/19 18:29:26",
				["player"] = "Maybé-Lucifron",
			}, -- [34]
			{
				["time"] = "10/23/19 18:29:26",
				["player"] = "Kindel-Lucifron",
			}, -- [35]
		},
		["Join"] = {
			{
				["time"] = "10/23/19 18:14:22",
				["player"] = "Mattness-Lucifron",
			}, -- [1]
			{
				["time"] = "10/23/19 18:14:22",
				["player"] = "Zajini-Lucifron",
			}, -- [2]
			{
				["time"] = "10/23/19 18:14:22",
				["player"] = "Arastus-Lucifron",
			}, -- [3]
			{
				["time"] = "10/23/19 18:14:22",
				["player"] = "Herrlich-Lucifron",
			}, -- [4]
			{
				["time"] = "10/23/19 18:14:22",
				["player"] = "Helmar-Lucifron",
			}, -- [5]
			{
				["time"] = "10/23/19 18:14:22",
				["player"] = "Cramp-Lucifron",
			}, -- [6]
			{
				["time"] = "10/23/19 18:14:22",
				["player"] = "Rayle-Lucifron",
			}, -- [7]
			{
				["time"] = "10/23/19 18:14:22",
				["player"] = "Luckypriest-Lucifron",
			}, -- [8]
			{
				["time"] = "10/23/19 18:14:22",
				["player"] = "Arastus-Lucifron",
			}, -- [9]
			{
				["time"] = "10/23/19 18:14:22",
				["player"] = "Luckypriest-Lucifron",
			}, -- [10]
			{
				["time"] = "10/23/19 18:15:56",
				["player"] = "Mattness-Lucifron",
			}, -- [11]
			{
				["time"] = "10/23/19 18:15:56",
				["player"] = "Zajini-Lucifron",
			}, -- [12]
			{
				["time"] = "10/23/19 18:15:56",
				["player"] = "Herrlich-Lucifron",
			}, -- [13]
			{
				["time"] = "10/23/19 18:15:56",
				["player"] = "Cramp-Lucifron",
			}, -- [14]
			{
				["time"] = "10/23/19 18:15:56",
				["player"] = "Rayle-Lucifron",
			}, -- [15]
			{
				["time"] = "10/23/19 18:21:06",
				["player"] = "Kindel-Lucifron",
			}, -- [16]
			{
				["time"] = "10/23/19 18:21:21",
				["player"] = "Vacanta-Lucifron",
			}, -- [17]
			{
				["time"] = "10/23/19 18:22:39",
				["player"] = "Yamakasie-Lucifron",
			}, -- [18]
			{
				["time"] = "10/23/19 18:23:16",
				["player"] = "Sukz-Lucifron",
			}, -- [19]
			{
				["time"] = "10/23/19 18:23:37",
				["player"] = "Maybé-Lucifron",
			}, -- [20]
			{
				["time"] = "10/23/19 18:23:48",
				["player"] = "Givewfproc-Lucifron",
			}, -- [21]
			{
				["time"] = "10/23/19 18:23:59",
				["player"] = "Bishamoto-Lucifron",
			}, -- [22]
			{
				["time"] = "10/23/19 18:24:42",
				["player"] = "Naazir-Lucifron",
			}, -- [23]
			{
				["time"] = "10/23/19 18:26:06",
				["player"] = "Schlimmbumm-Lucifron",
			}, -- [24]
			{
				["time"] = "10/23/19 18:28:20",
				["player"] = "Balanar-Lucifron",
			}, -- [25]
			{
				["time"] = "10/23/19 18:29:19",
				["player"] = "Kindel-Lucifron",
			}, -- [26]
		},
		["Loot"] = {
		},
		["End"] = "10/23/19 18:29:26",
		["BossKills"] = {
		},
		["key"] = "10/23/19 18:14:22",
		["PlayerInfos"] = {
			["Helmar-Lucifron"] = {
			},
			["Balanar-Lucifron"] = {
			},
			["Vacanta-Lucifron"] = {
			},
			["Bishamoto-Lucifron"] = {
			},
			["Mattness-Lucifron"] = {
			},
			["Luckypriest-Lucifron"] = {
			},
			["Herrlich-Lucifron"] = {
			},
			["Cramp-Lucifron"] = {
			},
			["Yamakasie-Lucifron"] = {
			},
			["Zajini-Lucifron"] = {
			},
			["Sukz-Lucifron"] = {
			},
			["Arastus-Lucifron"] = {
			},
			["Givewfproc-Lucifron"] = {
			},
			["Schlimmbumm-Lucifron"] = {
			},
			["Maybé-Lucifron"] = {
			},
			["Rayle-Lucifron"] = {
			},
			["Naazir-Lucifron"] = {
			},
			["Kindel-Lucifron"] = {
			},
		},
		["Realm"] = "Lucifron",
	}, -- [6]
	{
		["Leave"] = {
			{
				["time"] = "10/21/19 22:44:25",
				["player"] = "Críspy-Lucifron",
			}, -- [1]
			{
				["time"] = "10/21/19 22:45:03",
				["player"] = "Unbekannt-Lucifron",
			}, -- [2]
			{
				["time"] = "10/21/19 22:56:33",
				["player"] = "Kujoh-Lucifron",
			}, -- [3]
			{
				["time"] = "10/21/19 22:58:05",
				["player"] = "Srkzlol-Lucifron",
			}, -- [4]
			{
				["time"] = "10/21/19 23:07:17",
				["player"] = "Dirona-Lucifron",
			}, -- [5]
			{
				["time"] = "10/21/19 23:08:56",
				["player"] = "Rath-Lucifron",
			}, -- [6]
			{
				["time"] = "10/21/19 23:17:32",
				["player"] = "Srkzlol-Lucifron",
			}, -- [7]
			{
				["time"] = "10/22/19 00:10:13",
				["player"] = "Kujoh-Lucifron",
			}, -- [8]
			{
				["time"] = "10/22/19 00:10:13",
				["player"] = "Dirona-Lucifron",
			}, -- [9]
			{
				["time"] = "10/22/19 00:10:13",
				["player"] = "Sinntex-Lucifron",
			}, -- [10]
			{
				["time"] = "10/22/19 00:10:13",
				["player"] = "Unbekannt-Lucifron",
			}, -- [11]
			{
				["time"] = "10/22/19 00:10:13",
				["player"] = "Sephyron-Lucifron",
			}, -- [12]
			{
				["time"] = "10/22/19 00:10:13",
				["player"] = "Críspy-Lucifron",
			}, -- [13]
			{
				["time"] = "10/22/19 00:10:13",
				["player"] = "Skeltah-Lucifron",
			}, -- [14]
			{
				["time"] = "10/22/19 00:10:13",
				["player"] = "Chârly-Lucifron",
			}, -- [15]
			{
				["time"] = "10/22/19 00:10:13",
				["player"] = "Rath-Lucifron",
			}, -- [16]
			{
				["time"] = "10/22/19 00:10:13",
				["player"] = "Luckypriest-Lucifron",
			}, -- [17]
			{
				["time"] = "10/22/19 00:10:13",
				["player"] = "Agana-Lucifron",
			}, -- [18]
			{
				["time"] = "10/22/19 00:10:13",
				["player"] = "Srkzlol-Lucifron",
			}, -- [19]
		},
		["Join"] = {
			{
				["time"] = "10/21/19 22:44:18",
				["player"] = "Agana-Lucifron",
			}, -- [1]
			{
				["time"] = "10/21/19 22:44:18",
				["player"] = "Kujoh-Lucifron",
			}, -- [2]
			{
				["time"] = "10/21/19 22:44:18",
				["player"] = "Luckypriest-Lucifron",
			}, -- [3]
			{
				["time"] = "10/21/19 22:44:18",
				["player"] = "Sephyron-Lucifron",
			}, -- [4]
			{
				["time"] = "10/21/19 22:44:18",
				["player"] = "Dirona-Lucifron",
			}, -- [5]
			{
				["time"] = "10/21/19 22:44:18",
				["player"] = "Agana-Lucifron",
			}, -- [6]
			{
				["time"] = "10/21/19 22:44:18",
				["player"] = "Kujoh-Lucifron",
			}, -- [7]
			{
				["time"] = "10/21/19 22:44:18",
				["player"] = "Luckypriest-Lucifron",
			}, -- [8]
			{
				["time"] = "10/21/19 22:44:18",
				["player"] = "Sephyron-Lucifron",
			}, -- [9]
			{
				["time"] = "10/21/19 22:44:18",
				["player"] = "Dirona-Lucifron",
			}, -- [10]
			{
				["time"] = "10/21/19 22:44:27",
				["player"] = "Críspy-Lucifron",
			}, -- [11]
			{
				["time"] = "10/21/19 22:45:08",
				["player"] = "Skeltah-Lucifron",
			}, -- [12]
			{
				["time"] = "10/21/19 22:45:33",
				["player"] = "Sinntex-Lucifron",
			}, -- [13]
			{
				["time"] = "10/21/19 22:49:01",
				["player"] = "Chârly-Lucifron",
			}, -- [14]
			{
				["time"] = "10/21/19 22:56:33",
				["player"] = "Rath-Lucifron",
			}, -- [15]
			{
				["time"] = "10/21/19 22:58:05",
				["player"] = "Kujoh-Lucifron",
			}, -- [16]
			{
				["time"] = "10/21/19 22:58:22",
				["player"] = "Srkzlol-Lucifron",
			}, -- [17]
			{
				["time"] = "10/21/19 23:08:38",
				["player"] = "Dirona-Lucifron",
			}, -- [18]
			{
				["time"] = "10/21/19 23:09:17",
				["player"] = "Rath-Lucifron",
			}, -- [19]
			{
				["time"] = "10/21/19 23:17:32",
				["player"] = "Srkzlol-Lucifron",
			}, -- [20]
		},
		["Loot"] = {
		},
		["End"] = "10/22/19 00:10:13",
		["key"] = "10/21/19 22:44:18",
		["BossKills"] = {
		},
		["PlayerInfos"] = {
			["Kujoh-Lucifron"] = {
			},
			["Dirona-Lucifron"] = {
			},
			["Sinntex-Lucifron"] = {
			},
			["Unbekannt-Lucifron"] = {
			},
			["Sephyron-Lucifron"] = {
			},
			["Críspy-Lucifron"] = {
			},
			["Rath-Lucifron"] = {
			},
			["Chârly-Lucifron"] = {
			},
			["Skeltah-Lucifron"] = {
			},
			["Luckypriest-Lucifron"] = {
			},
			["Agana-Lucifron"] = {
			},
			["Srkzlol-Lucifron"] = {
			},
		},
		["Realm"] = "Lucifron",
	}, -- [7]
	{
		["Leave"] = {
			{
				["time"] = "10/21/19 21:20:50",
				["player"] = "Luthy-Lucifron",
			}, -- [1]
			{
				["time"] = "10/21/19 21:20:50",
				["player"] = "Unbekannt-Lucifron",
			}, -- [2]
			{
				["time"] = "10/21/19 21:20:50",
				["player"] = "Darkenrahl-Lucifron",
			}, -- [3]
			{
				["time"] = "10/21/19 21:21:07",
				["player"] = "Agana-Lucifron",
			}, -- [4]
			{
				["time"] = "10/21/19 21:21:43",
				["player"] = "Kujoh-Lucifron",
			}, -- [5]
			{
				["time"] = "10/21/19 22:34:27",
				["player"] = "Kujoh-Lucifron",
			}, -- [6]
			{
				["time"] = "10/21/19 22:34:27",
				["player"] = "Dodoo-Lucifron",
			}, -- [7]
			{
				["time"] = "10/21/19 22:34:27",
				["player"] = "Unbekannt-Lucifron",
			}, -- [8]
			{
				["time"] = "10/21/19 22:34:27",
				["player"] = "Goya-Lucifron",
			}, -- [9]
			{
				["time"] = "10/21/19 22:34:27",
				["player"] = "Sikkiz-Lucifron",
			}, -- [10]
			{
				["time"] = "10/21/19 22:34:27",
				["player"] = "Sunwukong-Lucifron",
			}, -- [11]
			{
				["time"] = "10/21/19 22:34:27",
				["player"] = "Agana-Lucifron",
			}, -- [12]
			{
				["time"] = "10/21/19 22:34:27",
				["player"] = "Darkenrahl-Lucifron",
			}, -- [13]
			{
				["time"] = "10/21/19 22:34:27",
				["player"] = "Luckypriest-Lucifron",
			}, -- [14]
			{
				["time"] = "10/21/19 22:34:27",
				["player"] = "Hascar-Lucifron",
			}, -- [15]
			{
				["time"] = "10/21/19 22:34:27",
				["player"] = "Luthy-Lucifron",
			}, -- [16]
		},
		["End"] = "10/21/19 22:34:27",
		["Loot"] = {
		},
		["Join"] = {
			{
				["time"] = "10/21/19 21:20:50",
				["player"] = "Luthy-Lucifron",
			}, -- [1]
			{
				["time"] = "10/21/19 21:20:50",
				["player"] = "Unbekannt-Lucifron",
			}, -- [2]
			{
				["time"] = "10/21/19 21:20:50",
				["player"] = "Unbekannt-Lucifron",
			}, -- [3]
			{
				["time"] = "10/21/19 21:20:50",
				["player"] = "Darkenrahl-Lucifron",
			}, -- [4]
			{
				["time"] = "10/21/19 21:20:50",
				["player"] = "Unbekannt-Lucifron",
			}, -- [5]
			{
				["time"] = "10/21/19 21:20:50",
				["player"] = "Unbekannt-Lucifron",
			}, -- [6]
			{
				["time"] = "10/21/19 21:20:50",
				["player"] = "Luckypriest-Lucifron",
			}, -- [7]
			{
				["time"] = "10/21/19 21:20:50",
				["player"] = "Luckypriest-Lucifron",
			}, -- [8]
			{
				["time"] = "10/21/19 21:21:07",
				["player"] = "Luthy-Lucifron",
			}, -- [9]
			{
				["time"] = "10/21/19 21:21:07",
				["player"] = "Dodoo-Lucifron",
			}, -- [10]
			{
				["time"] = "10/21/19 21:21:07",
				["player"] = "Goya-Lucifron",
			}, -- [11]
			{
				["time"] = "10/21/19 21:21:07",
				["player"] = "Darkenrahl-Lucifron",
			}, -- [12]
			{
				["time"] = "10/21/19 21:21:07",
				["player"] = "Hascar-Lucifron",
			}, -- [13]
			{
				["time"] = "10/21/19 21:21:07",
				["player"] = "Sikkiz-Lucifron",
			}, -- [14]
			{
				["time"] = "10/21/19 21:21:13",
				["player"] = "Agana-Lucifron",
			}, -- [15]
			{
				["time"] = "10/21/19 21:21:43",
				["player"] = "Sunwukong-Lucifron",
			}, -- [16]
			{
				["time"] = "10/21/19 21:22:21",
				["player"] = "Kujoh-Lucifron",
			}, -- [17]
		},
		["PlayerInfos"] = {
			["Kujoh-Lucifron"] = {
			},
			["Dodoo-Lucifron"] = {
			},
			["Unbekannt-Lucifron"] = {
			},
			["Goya-Lucifron"] = {
			},
			["Sikkiz-Lucifron"] = {
			},
			["Sunwukong-Lucifron"] = {
			},
			["Hascar-Lucifron"] = {
			},
			["Agana-Lucifron"] = {
			},
			["Luckypriest-Lucifron"] = {
			},
			["Darkenrahl-Lucifron"] = {
			},
			["Luthy-Lucifron"] = {
			},
		},
		["key"] = "10/21/19 21:20:50",
		["BossKills"] = {
		},
		["Realm"] = "Lucifron",
	}, -- [8]
	{
		["Leave"] = {
			{
				["time"] = "10/21/19 08:41:40",
				["player"] = "Bizepsberti-Lucifron",
			}, -- [1]
			{
				["time"] = "10/21/19 08:41:53",
				["player"] = "Jexo-Lucifron",
			}, -- [2]
			{
				["time"] = "10/21/19 08:42:28",
				["player"] = "Wamboe-Lucifron",
			}, -- [3]
			{
				["time"] = "10/21/19 08:43:47",
				["player"] = "Ambrosìa-Lucifron",
			}, -- [4]
			{
				["time"] = "10/21/19 08:44:31",
				["player"] = "Xandör-Lucifron",
			}, -- [5]
			{
				["time"] = "10/21/19 08:47:28",
				["player"] = "Nordan-Lucifron",
			}, -- [6]
			{
				["time"] = "10/21/19 09:13:58",
				["player"] = "Guko-Lucifron",
			}, -- [7]
			{
				["time"] = "10/21/19 09:20:33",
				["player"] = "Ambrosìa-Lucifron",
			}, -- [8]
			{
				["time"] = "10/21/19 21:01:09",
				["player"] = "raid1",
			}, -- [9]
			{
				["time"] = "10/21/19 21:01:11",
				["player"] = "Nordan-Lucifron",
			}, -- [10]
			{
				["time"] = "10/21/19 21:01:11",
				["player"] = "Jexo-Lucifron",
			}, -- [11]
			{
				["time"] = "10/21/19 21:01:11",
				["player"] = "Hamyr-Lucifron",
			}, -- [12]
			{
				["time"] = "10/21/19 21:01:11",
				["player"] = "Guko-Lucifron",
			}, -- [13]
			{
				["time"] = "10/21/19 21:01:11",
				["player"] = "Wamboe-Lucifron",
			}, -- [14]
			{
				["time"] = "10/21/19 21:01:11",
				["player"] = "Bizepsberti-Lucifron",
			}, -- [15]
			{
				["time"] = "10/21/19 21:01:11",
				["player"] = "raid1",
			}, -- [16]
			{
				["time"] = "10/21/19 21:01:11",
				["player"] = "Luckypriest-Lucifron",
			}, -- [17]
			{
				["time"] = "10/21/19 21:01:11",
				["player"] = "Ambrosìa-Lucifron",
			}, -- [18]
			{
				["time"] = "10/21/19 21:01:11",
				["player"] = "Xandör-Lucifron",
			}, -- [19]
		},
		["End"] = "10/21/19 21:01:11",
		["Loot"] = {
		},
		["Join"] = {
			{
				["time"] = "10/21/19 08:41:27",
				["player"] = "Luckypriest-Lucifron",
			}, -- [1]
			{
				["time"] = "10/21/19 08:41:27",
				["player"] = "Guko-Lucifron",
			}, -- [2]
			{
				["time"] = "10/21/19 08:41:27",
				["player"] = "Hamyr-Lucifron",
			}, -- [3]
			{
				["time"] = "10/21/19 08:41:27",
				["player"] = "Wamboe-Lucifron",
			}, -- [4]
			{
				["time"] = "10/21/19 08:41:27",
				["player"] = "Luckypriest-Lucifron",
			}, -- [5]
			{
				["time"] = "10/21/19 08:41:27",
				["player"] = "Guko-Lucifron",
			}, -- [6]
			{
				["time"] = "10/21/19 08:41:27",
				["player"] = "Hamyr-Lucifron",
			}, -- [7]
			{
				["time"] = "10/21/19 08:41:27",
				["player"] = "Wamboe-Lucifron",
			}, -- [8]
			{
				["time"] = "10/21/19 08:41:43",
				["player"] = "Bizepsberti-Lucifron",
			}, -- [9]
			{
				["time"] = "10/21/19 08:41:53",
				["player"] = "Jexo-Lucifron",
			}, -- [10]
			{
				["time"] = "10/21/19 08:43:47",
				["player"] = "Wamboe-Lucifron",
			}, -- [11]
			{
				["time"] = "10/21/19 08:44:20",
				["player"] = "Ambrosìa-Lucifron",
			}, -- [12]
			{
				["time"] = "10/21/19 08:44:51",
				["player"] = "Xandör-Lucifron",
			}, -- [13]
			{
				["time"] = "10/21/19 08:53:52",
				["player"] = "Nordan-Lucifron",
			}, -- [14]
			{
				["time"] = "10/21/19 09:20:33",
				["player"] = "Ambrosìa-Lucifron",
			}, -- [15]
		},
		["PlayerInfos"] = {
			["Nordan-Lucifron"] = {
			},
			["Jexo-Lucifron"] = {
			},
			["Hamyr-Lucifron"] = {
			},
			["Guko-Lucifron"] = {
			},
			["Wamboe-Lucifron"] = {
			},
			["Bizepsberti-Lucifron"] = {
			},
			["raid1"] = {
			},
			["Luckypriest-Lucifron"] = {
			},
			["Ambrosìa-Lucifron"] = {
			},
			["Xandör-Lucifron"] = {
			},
		},
		["BossKills"] = {
		},
		["key"] = "10/21/19 08:41:27",
		["Realm"] = "Lucifron",
	}, -- [9]
	{
		["Leave"] = {
			{
				["time"] = "10/21/19 00:13:05",
				["player"] = "Solomon-Lucifron",
			}, -- [1]
			{
				["time"] = "10/21/19 00:13:05",
				["player"] = "Zafiel-Lucifron",
			}, -- [2]
			{
				["time"] = "10/21/19 00:13:05",
				["player"] = "Unbekannt-Lucifron",
			}, -- [3]
			{
				["time"] = "10/21/19 00:21:07",
				["player"] = "Zafiel-Lucifron",
			}, -- [4]
			{
				["time"] = "10/21/19 00:21:07",
				["player"] = "Ominotago-Lucifron",
			}, -- [5]
			{
				["time"] = "10/21/19 00:21:07",
				["player"] = "Solomon-Lucifron",
			}, -- [6]
			{
				["time"] = "10/21/19 00:21:07",
				["player"] = "Älska-Lucifron",
			}, -- [7]
			{
				["time"] = "10/21/19 00:21:07",
				["player"] = "Unbekannt-Lucifron",
			}, -- [8]
			{
				["time"] = "10/21/19 00:21:07",
				["player"] = "Luckypriest-Lucifron",
			}, -- [9]
			{
				["time"] = "10/21/19 00:21:07",
				["player"] = "Givewfproc-Lucifron",
			}, -- [10]
		},
		["End"] = "10/21/19 00:21:07",
		["Loot"] = {
		},
		["Join"] = {
			{
				["time"] = "10/21/19 00:13:05",
				["player"] = "Solomon-Lucifron",
			}, -- [1]
			{
				["time"] = "10/21/19 00:13:05",
				["player"] = "Zafiel-Lucifron",
			}, -- [2]
			{
				["time"] = "10/21/19 00:13:05",
				["player"] = "Unbekannt-Lucifron",
			}, -- [3]
			{
				["time"] = "10/21/19 00:13:05",
				["player"] = "Givewfproc-Lucifron",
			}, -- [4]
			{
				["time"] = "10/21/19 00:13:05",
				["player"] = "Luckypriest-Lucifron",
			}, -- [5]
			{
				["time"] = "10/21/19 00:13:05",
				["player"] = "Givewfproc-Lucifron",
			}, -- [6]
			{
				["time"] = "10/21/19 00:13:05",
				["player"] = "Luckypriest-Lucifron",
			}, -- [7]
			{
				["time"] = "10/21/19 00:13:11",
				["player"] = "Solomon-Lucifron",
			}, -- [8]
			{
				["time"] = "10/21/19 00:13:11",
				["player"] = "Zafiel-Lucifron",
			}, -- [9]
			{
				["time"] = "10/21/19 00:13:11",
				["player"] = "Ominotago-Lucifron",
			}, -- [10]
			{
				["time"] = "10/21/19 00:13:11",
				["player"] = "Älska-Lucifron",
			}, -- [11]
		},
		["PlayerInfos"] = {
			["Zafiel-Lucifron"] = {
			},
			["Ominotago-Lucifron"] = {
			},
			["Solomon-Lucifron"] = {
			},
			["Älska-Lucifron"] = {
			},
			["Unbekannt-Lucifron"] = {
			},
			["Luckypriest-Lucifron"] = {
			},
			["Givewfproc-Lucifron"] = {
			},
		},
		["key"] = "10/21/19 00:13:05",
		["BossKills"] = {
		},
		["Realm"] = "Lucifron",
	}, -- [10]
	{
		["Leave"] = {
			{
				["time"] = "10/21/19 00:12:59",
				["player"] = "Älska-Lucifron",
			}, -- [1]
			{
				["time"] = "10/21/19 00:12:59",
				["player"] = "Luckypriest-Lucifron",
			}, -- [2]
			{
				["time"] = "10/21/19 00:12:59",
				["player"] = "Givewfproc-Lucifron",
			}, -- [3]
		},
		["End"] = "10/21/19 00:12:59",
		["Loot"] = {
		},
		["Join"] = {
			{
				["time"] = "10/21/19 00:10:51",
				["player"] = "Givewfproc-Lucifron",
			}, -- [1]
			{
				["time"] = "10/21/19 00:10:51",
				["player"] = "Luckypriest-Lucifron",
			}, -- [2]
			{
				["time"] = "10/21/19 00:10:51",
				["player"] = "Älska-Lucifron",
			}, -- [3]
			{
				["time"] = "10/21/19 00:10:51",
				["player"] = "Givewfproc-Lucifron",
			}, -- [4]
			{
				["time"] = "10/21/19 00:10:51",
				["player"] = "Luckypriest-Lucifron",
			}, -- [5]
			{
				["time"] = "10/21/19 00:10:51",
				["player"] = "Älska-Lucifron",
			}, -- [6]
		},
		["PlayerInfos"] = {
			["Älska-Lucifron"] = {
			},
			["Luckypriest-Lucifron"] = {
			},
			["Givewfproc-Lucifron"] = {
			},
		},
		["key"] = "10/21/19 00:10:51",
		["BossKills"] = {
		},
		["Realm"] = "Lucifron",
	}, -- [11]
	{
		["Leave"] = {
			{
				["time"] = "10/20/19 23:26:47",
				["player"] = "Unbekannt-Lucifron",
			}, -- [1]
			{
				["time"] = "10/20/19 23:30:29",
				["player"] = "Liszt-Lucifron",
			}, -- [2]
			{
				["time"] = "10/20/19 23:30:29",
				["player"] = "Ramdox-Lucifron",
			}, -- [3]
			{
				["time"] = "10/20/19 23:30:29",
				["player"] = "Älska-Lucifron",
			}, -- [4]
			{
				["time"] = "10/20/19 23:30:29",
				["player"] = "Unbekannt-Lucifron",
			}, -- [5]
			{
				["time"] = "10/20/19 23:30:29",
				["player"] = "Luckypriest-Lucifron",
			}, -- [6]
			{
				["time"] = "10/20/19 23:30:29",
				["player"] = "Givewfproc-Lucifron",
			}, -- [7]
		},
		["End"] = "10/20/19 23:30:29",
		["Loot"] = {
		},
		["Join"] = {
			{
				["time"] = "10/20/19 23:21:19",
				["player"] = "Luckypriest-Lucifron",
			}, -- [1]
			{
				["time"] = "10/20/19 23:21:19",
				["player"] = "Älska-Lucifron",
			}, -- [2]
			{
				["time"] = "10/20/19 23:21:19",
				["player"] = "Givewfproc-Lucifron",
			}, -- [3]
			{
				["time"] = "10/20/19 23:21:19",
				["player"] = "Luckypriest-Lucifron",
			}, -- [4]
			{
				["time"] = "10/20/19 23:21:19",
				["player"] = "Älska-Lucifron",
			}, -- [5]
			{
				["time"] = "10/20/19 23:21:19",
				["player"] = "Givewfproc-Lucifron",
			}, -- [6]
			{
				["time"] = "10/20/19 23:26:50",
				["player"] = "Ramdox-Lucifron",
			}, -- [7]
			{
				["time"] = "10/20/19 23:26:50",
				["player"] = "Liszt-Lucifron",
			}, -- [8]
		},
		["PlayerInfos"] = {
			["Liszt-Lucifron"] = {
			},
			["Ramdox-Lucifron"] = {
			},
			["Älska-Lucifron"] = {
			},
			["Unbekannt-Lucifron"] = {
			},
			["Luckypriest-Lucifron"] = {
			},
			["Givewfproc-Lucifron"] = {
			},
		},
		["key"] = "10/20/19 23:21:19",
		["BossKills"] = {
		},
		["Realm"] = "Lucifron",
	}, -- [12]
	{
		["Leave"] = {
			{
				["time"] = "10/20/19 21:54:24",
				["player"] = "Vespir-Lucifron",
			}, -- [1]
			{
				["time"] = "10/20/19 21:54:24",
				["player"] = "Unbekannt-Lucifron",
			}, -- [2]
			{
				["time"] = "10/20/19 21:54:24",
				["player"] = "Sokcen-Lucifron",
			}, -- [3]
			{
				["time"] = "10/20/19 21:54:24",
				["player"] = "Taîlz-Lucifron",
			}, -- [4]
			{
				["time"] = "10/20/19 21:54:24",
				["player"] = "Laidana-Lucifron",
			}, -- [5]
			{
				["time"] = "10/20/19 22:37:42",
				["player"] = "Laidana-Lucifron",
			}, -- [6]
			{
				["time"] = "10/20/19 22:37:42",
				["player"] = "Unbekannt-Lucifron",
			}, -- [7]
			{
				["time"] = "10/20/19 22:37:42",
				["player"] = "Tulgrim-Lucifron",
			}, -- [8]
			{
				["time"] = "10/20/19 22:37:42",
				["player"] = "Taîlz-Lucifron",
			}, -- [9]
			{
				["time"] = "10/20/19 22:37:42",
				["player"] = "Roxnod-Lucifron",
			}, -- [10]
			{
				["time"] = "10/20/19 22:37:42",
				["player"] = "Vespir-Lucifron",
			}, -- [11]
			{
				["time"] = "10/20/19 22:37:42",
				["player"] = "Luckypriest-Lucifron",
			}, -- [12]
			{
				["time"] = "10/20/19 22:37:42",
				["player"] = "Sokcen-Lucifron",
			}, -- [13]
			{
				["time"] = "10/20/19 22:37:42",
				["player"] = "Iltkll-Lucifron",
			}, -- [14]
		},
		["End"] = "10/20/19 22:37:42",
		["Loot"] = {
		},
		["Join"] = {
			{
				["time"] = "10/20/19 21:54:24",
				["player"] = "Vespir-Lucifron",
			}, -- [1]
			{
				["time"] = "10/20/19 21:54:24",
				["player"] = "Unbekannt-Lucifron",
			}, -- [2]
			{
				["time"] = "10/20/19 21:54:24",
				["player"] = "Sokcen-Lucifron",
			}, -- [3]
			{
				["time"] = "10/20/19 21:54:24",
				["player"] = "Taîlz-Lucifron",
			}, -- [4]
			{
				["time"] = "10/20/19 21:54:24",
				["player"] = "Laidana-Lucifron",
			}, -- [5]
			{
				["time"] = "10/20/19 21:54:24",
				["player"] = "Unbekannt-Lucifron",
			}, -- [6]
			{
				["time"] = "10/20/19 21:54:24",
				["player"] = "Unbekannt-Lucifron",
			}, -- [7]
			{
				["time"] = "10/20/19 21:54:24",
				["player"] = "Luckypriest-Lucifron",
			}, -- [8]
			{
				["time"] = "10/20/19 21:54:24",
				["player"] = "Luckypriest-Lucifron",
			}, -- [9]
			{
				["time"] = "10/20/19 21:54:31",
				["player"] = "Vespir-Lucifron",
			}, -- [10]
			{
				["time"] = "10/20/19 21:54:31",
				["player"] = "Iltkll-Lucifron",
			}, -- [11]
			{
				["time"] = "10/20/19 21:54:31",
				["player"] = "Sokcen-Lucifron",
			}, -- [12]
			{
				["time"] = "10/20/19 21:54:31",
				["player"] = "Taîlz-Lucifron",
			}, -- [13]
			{
				["time"] = "10/20/19 21:54:31",
				["player"] = "Laidana-Lucifron",
			}, -- [14]
			{
				["time"] = "10/20/19 21:54:31",
				["player"] = "Tulgrim-Lucifron",
			}, -- [15]
			{
				["time"] = "10/20/19 21:54:31",
				["player"] = "Roxnod-Lucifron",
			}, -- [16]
		},
		["PlayerInfos"] = {
			["Laidana-Lucifron"] = {
			},
			["Unbekannt-Lucifron"] = {
			},
			["Tulgrim-Lucifron"] = {
			},
			["Taîlz-Lucifron"] = {
			},
			["Roxnod-Lucifron"] = {
			},
			["Vespir-Lucifron"] = {
			},
			["Luckypriest-Lucifron"] = {
			},
			["Sokcen-Lucifron"] = {
			},
			["Iltkll-Lucifron"] = {
			},
		},
		["key"] = "10/20/19 21:54:24",
		["BossKills"] = {
		},
		["Realm"] = "Lucifron",
	}, -- [13]
	{
		["Leave"] = {
			{
				["time"] = "10/20/19 16:06:09",
				["player"] = "Agana-Lucifron",
			}, -- [1]
			{
				["time"] = "10/20/19 16:06:09",
				["player"] = "Dnx-Lucifron",
			}, -- [2]
			{
				["time"] = "10/20/19 16:06:09",
				["player"] = "Detsub-Lucifron",
			}, -- [3]
			{
				["time"] = "10/20/19 16:06:09",
				["player"] = "Darain-Lucifron",
			}, -- [4]
			{
				["time"] = "10/20/19 16:06:09",
				["player"] = "Albion-Lucifron",
			}, -- [5]
			{
				["time"] = "10/20/19 16:06:09",
				["player"] = "Mammon-Lucifron",
			}, -- [6]
			{
				["time"] = "10/20/19 16:06:09",
				["player"] = "Lii-Lucifron",
			}, -- [7]
			{
				["time"] = "10/20/19 16:06:09",
				["player"] = "Kurtlore-Lucifron",
			}, -- [8]
			{
				["time"] = "10/20/19 16:11:44",
				["player"] = "Triqsx-Lucifron",
			}, -- [9]
			{
				["time"] = "10/20/19 16:13:45",
				["player"] = "Detsub-Lucifron",
			}, -- [10]
			{
				["time"] = "10/20/19 16:19:55",
				["player"] = "Triqsx-Lucifron",
			}, -- [11]
			{
				["time"] = "10/20/19 16:23:42",
				["player"] = "Bleachi-Lucifron",
			}, -- [12]
			{
				["time"] = "10/20/19 17:11:21",
				["player"] = "Albion-Lucifron",
			}, -- [13]
			{
				["time"] = "10/20/19 17:12:16",
				["player"] = "Detsub-Lucifron",
			}, -- [14]
			{
				["time"] = "10/20/19 17:12:49",
				["player"] = "Katomar-Lucifron",
			}, -- [15]
			{
				["time"] = "10/20/19 17:46:17",
				["player"] = "Cesor-Lucifron",
			}, -- [16]
			{
				["time"] = "10/20/19 17:46:39",
				["player"] = "Artaîos-Lucifron",
			}, -- [17]
			{
				["time"] = "10/20/19 17:54:24",
				["player"] = "Mammon-Lucifron",
			}, -- [18]
			{
				["time"] = "10/20/19 17:54:24",
				["player"] = "Darain-Lucifron",
			}, -- [19]
			{
				["time"] = "10/20/19 17:54:24",
				["player"] = "Artaîos-Lucifron",
			}, -- [20]
			{
				["time"] = "10/20/19 17:54:24",
				["player"] = "Dnx-Lucifron",
			}, -- [21]
			{
				["time"] = "10/20/19 17:54:24",
				["player"] = "Cesor-Lucifron",
			}, -- [22]
			{
				["time"] = "10/20/19 17:54:24",
				["player"] = "Katomar-Lucifron",
			}, -- [23]
			{
				["time"] = "10/20/19 17:54:24",
				["player"] = "Bleachi-Lucifron",
			}, -- [24]
			{
				["time"] = "10/20/19 17:54:24",
				["player"] = "Albion-Lucifron",
			}, -- [25]
			{
				["time"] = "10/20/19 17:54:24",
				["player"] = "Detsub-Lucifron",
			}, -- [26]
			{
				["time"] = "10/20/19 17:54:24",
				["player"] = "Kurtlore-Lucifron",
			}, -- [27]
			{
				["time"] = "10/20/19 17:54:24",
				["player"] = "Triqsx-Lucifron",
			}, -- [28]
			{
				["time"] = "10/20/19 17:54:24",
				["player"] = "Agana-Lucifron",
			}, -- [29]
			{
				["time"] = "10/20/19 17:54:24",
				["player"] = "Lii-Lucifron",
			}, -- [30]
			{
				["time"] = "10/20/19 17:54:24",
				["player"] = "Luckypriest-Lucifron",
			}, -- [31]
		},
		["Join"] = {
			{
				["time"] = "10/20/19 16:06:09",
				["player"] = "Agana-Lucifron",
			}, -- [1]
			{
				["time"] = "10/20/19 16:06:09",
				["player"] = "Dnx-Lucifron",
			}, -- [2]
			{
				["time"] = "10/20/19 16:06:09",
				["player"] = "Detsub-Lucifron",
			}, -- [3]
			{
				["time"] = "10/20/19 16:06:09",
				["player"] = "Darain-Lucifron",
			}, -- [4]
			{
				["time"] = "10/20/19 16:06:09",
				["player"] = "Albion-Lucifron",
			}, -- [5]
			{
				["time"] = "10/20/19 16:06:09",
				["player"] = "Mammon-Lucifron",
			}, -- [6]
			{
				["time"] = "10/20/19 16:06:09",
				["player"] = "Luckypriest-Lucifron",
			}, -- [7]
			{
				["time"] = "10/20/19 16:06:09",
				["player"] = "Lii-Lucifron",
			}, -- [8]
			{
				["time"] = "10/20/19 16:06:09",
				["player"] = "Kurtlore-Lucifron",
			}, -- [9]
			{
				["time"] = "10/20/19 16:06:09",
				["player"] = "Luckypriest-Lucifron",
			}, -- [10]
			{
				["time"] = "10/20/19 16:06:23",
				["player"] = "Agana-Lucifron",
			}, -- [11]
			{
				["time"] = "10/20/19 16:06:23",
				["player"] = "Dnx-Lucifron",
			}, -- [12]
			{
				["time"] = "10/20/19 16:06:23",
				["player"] = "Detsub-Lucifron",
			}, -- [13]
			{
				["time"] = "10/20/19 16:06:23",
				["player"] = "Darain-Lucifron",
			}, -- [14]
			{
				["time"] = "10/20/19 16:06:23",
				["player"] = "Albion-Lucifron",
			}, -- [15]
			{
				["time"] = "10/20/19 16:06:23",
				["player"] = "Mammon-Lucifron",
			}, -- [16]
			{
				["time"] = "10/20/19 16:06:23",
				["player"] = "Lii-Lucifron",
			}, -- [17]
			{
				["time"] = "10/20/19 16:06:45",
				["player"] = "Kurtlore-Lucifron",
			}, -- [18]
			{
				["time"] = "10/20/19 16:12:21",
				["player"] = "Triqsx-Lucifron",
			}, -- [19]
			{
				["time"] = "10/20/19 16:14:43",
				["player"] = "Detsub-Lucifron",
			}, -- [20]
			{
				["time"] = "10/20/19 16:20:28",
				["player"] = "Triqsx-Lucifron",
			}, -- [21]
			{
				["time"] = "10/20/19 16:23:47",
				["player"] = "Bleachi-Lucifron",
			}, -- [22]
			{
				["time"] = "10/20/19 17:11:53",
				["player"] = "Albion-Lucifron",
			}, -- [23]
			{
				["time"] = "10/20/19 17:12:49",
				["player"] = "Detsub-Lucifron",
			}, -- [24]
			{
				["time"] = "10/20/19 17:46:39",
				["player"] = "Cesor-Lucifron",
			}, -- [25]
			{
				["time"] = "10/20/19 17:54:20",
				["player"] = "Artaîos-Lucifron",
			}, -- [26]
		},
		["Loot"] = {
		},
		["End"] = "10/20/19 17:54:24",
		["BossKills"] = {
		},
		["key"] = "10/20/19 16:06:09",
		["PlayerInfos"] = {
			["Mammon-Lucifron"] = {
			},
			["Darain-Lucifron"] = {
			},
			["Luckypriest-Lucifron"] = {
			},
			["Dnx-Lucifron"] = {
			},
			["Lii-Lucifron"] = {
			},
			["Agana-Lucifron"] = {
			},
			["Albion-Lucifron"] = {
			},
			["Bleachi-Lucifron"] = {
			},
			["Kurtlore-Lucifron"] = {
			},
			["Detsub-Lucifron"] = {
			},
			["Triqsx-Lucifron"] = {
			},
			["Artaîos-Lucifron"] = {
			},
			["Cesor-Lucifron"] = {
			},
			["Katomar-Lucifron"] = {
			},
		},
		["Realm"] = "Lucifron",
	}, -- [14]
	{
		["Leave"] = {
			{
				["time"] = "10/20/19 15:41:18",
				["player"] = "Detsub-Lucifron",
			}, -- [1]
			{
				["time"] = "10/20/19 15:41:51",
				["player"] = "Kurtlore-Lucifron",
			}, -- [2]
			{
				["time"] = "10/20/19 15:43:53",
				["player"] = "Dnx-Lucifron",
			}, -- [3]
			{
				["time"] = "10/20/19 15:45:43",
				["player"] = "Darain-Lucifron",
			}, -- [4]
			{
				["time"] = "10/20/19 15:46:48",
				["player"] = "Albion-Lucifron",
			}, -- [5]
			{
				["time"] = "10/20/19 16:01:54",
				["player"] = "Mammon-Lucifron",
			}, -- [6]
			{
				["time"] = "10/20/19 16:04:18",
				["player"] = "Mammon-Lucifron",
			}, -- [7]
			{
				["time"] = "10/20/19 16:04:18",
				["player"] = "Darain-Lucifron",
			}, -- [8]
			{
				["time"] = "10/20/19 16:04:18",
				["player"] = "Dnx-Lucifron",
			}, -- [9]
			{
				["time"] = "10/20/19 16:04:18",
				["player"] = "Kurtlore-Lucifron",
			}, -- [10]
			{
				["time"] = "10/20/19 16:04:18",
				["player"] = "Albion-Lucifron",
			}, -- [11]
			{
				["time"] = "10/20/19 16:04:18",
				["player"] = "Detsub-Lucifron",
			}, -- [12]
			{
				["time"] = "10/20/19 16:04:18",
				["player"] = "Luckypriest-Lucifron",
			}, -- [13]
			{
				["time"] = "10/20/19 16:04:18",
				["player"] = "Lii-Lucifron",
			}, -- [14]
			{
				["time"] = "10/20/19 16:04:18",
				["player"] = "Agana-Lucifron",
			}, -- [15]
		},
		["Join"] = {
			{
				["time"] = "10/20/19 15:36:04",
				["player"] = "Luckypriest-Lucifron",
			}, -- [1]
			{
				["time"] = "10/20/19 15:36:04",
				["player"] = "Agana-Lucifron",
			}, -- [2]
			{
				["time"] = "10/20/19 15:36:04",
				["player"] = "Lii-Lucifron",
			}, -- [3]
			{
				["time"] = "10/20/19 15:36:04",
				["player"] = "Luckypriest-Lucifron",
			}, -- [4]
			{
				["time"] = "10/20/19 15:36:04",
				["player"] = "Agana-Lucifron",
			}, -- [5]
			{
				["time"] = "10/20/19 15:36:04",
				["player"] = "Lii-Lucifron",
			}, -- [6]
			{
				["time"] = "10/20/19 15:41:51",
				["player"] = "Detsub-Lucifron",
			}, -- [7]
			{
				["time"] = "10/20/19 15:42:14",
				["player"] = "Kurtlore-Lucifron",
			}, -- [8]
			{
				["time"] = "10/20/19 15:45:43",
				["player"] = "Dnx-Lucifron",
			}, -- [9]
			{
				["time"] = "10/20/19 15:46:48",
				["player"] = "Darain-Lucifron",
			}, -- [10]
			{
				["time"] = "10/20/19 15:48:23",
				["player"] = "Albion-Lucifron",
			}, -- [11]
			{
				["time"] = "10/20/19 16:03:20",
				["player"] = "Mammon-Lucifron",
			}, -- [12]
		},
		["Loot"] = {
		},
		["End"] = "10/20/19 16:04:18",
		["BossKills"] = {
		},
		["key"] = "10/20/19 15:36:04",
		["PlayerInfos"] = {
			["Mammon-Lucifron"] = {
			},
			["Darain-Lucifron"] = {
			},
			["Dnx-Lucifron"] = {
			},
			["Kurtlore-Lucifron"] = {
			},
			["Detsub-Lucifron"] = {
			},
			["Agana-Lucifron"] = {
			},
			["Luckypriest-Lucifron"] = {
			},
			["Lii-Lucifron"] = {
			},
			["Albion-Lucifron"] = {
			},
		},
		["Realm"] = "Lucifron",
	}, -- [15]
	{
		["Leave"] = {
			{
				["time"] = "10/19/19 18:31:37",
				["player"] = "Unbekannt-Lucifron",
			}, -- [1]
			{
				["time"] = "10/19/19 18:32:29",
				["player"] = "Neorx-Lucifron",
			}, -- [2]
			{
				["time"] = "10/19/19 18:36:48",
				["player"] = "Neorx-Lucifron",
			}, -- [3]
			{
				["time"] = "10/19/19 19:27:36",
				["player"] = "Xerker-Lucifron",
			}, -- [4]
			{
				["time"] = "10/19/19 19:27:36",
				["player"] = "Neorx-Lucifron",
			}, -- [5]
			{
				["time"] = "10/19/19 19:27:36",
				["player"] = "Eskalor-Lucifron",
			}, -- [6]
			{
				["time"] = "10/19/19 19:27:36",
				["player"] = "Lacrimas-Lucifron",
			}, -- [7]
			{
				["time"] = "10/19/19 19:27:36",
				["player"] = "Leanside-Lucifron",
			}, -- [8]
			{
				["time"] = "10/19/19 19:27:36",
				["player"] = "Unbekannt-Lucifron",
			}, -- [9]
			{
				["time"] = "10/19/19 19:27:36",
				["player"] = "Luckypriest-Lucifron",
			}, -- [10]
			{
				["time"] = "10/19/19 19:27:36",
				["player"] = "Likenik-Lucifron",
			}, -- [11]
			{
				["time"] = "10/19/19 19:27:36",
				["player"] = "Greentomato-Lucifron",
			}, -- [12]
		},
		["End"] = "10/19/19 19:27:36",
		["Loot"] = {
		},
		["Join"] = {
			{
				["time"] = "10/19/19 18:30:31",
				["player"] = "Xerker-Lucifron",
			}, -- [1]
			{
				["time"] = "10/19/19 18:30:31",
				["player"] = "Lacrimas-Lucifron",
			}, -- [2]
			{
				["time"] = "10/19/19 18:30:31",
				["player"] = "Eskalor-Lucifron",
			}, -- [3]
			{
				["time"] = "10/19/19 18:30:31",
				["player"] = "Likenik-Lucifron",
			}, -- [4]
			{
				["time"] = "10/19/19 18:30:31",
				["player"] = "Luckypriest-Lucifron",
			}, -- [5]
			{
				["time"] = "10/19/19 18:30:31",
				["player"] = "Xerker-Lucifron",
			}, -- [6]
			{
				["time"] = "10/19/19 18:30:31",
				["player"] = "Lacrimas-Lucifron",
			}, -- [7]
			{
				["time"] = "10/19/19 18:30:31",
				["player"] = "Eskalor-Lucifron",
			}, -- [8]
			{
				["time"] = "10/19/19 18:30:31",
				["player"] = "Likenik-Lucifron",
			}, -- [9]
			{
				["time"] = "10/19/19 18:30:31",
				["player"] = "Luckypriest-Lucifron",
			}, -- [10]
			{
				["time"] = "10/19/19 18:32:29",
				["player"] = "Greentomato-Lucifron",
			}, -- [11]
			{
				["time"] = "10/19/19 18:34:38",
				["player"] = "Neorx-Lucifron",
			}, -- [12]
			{
				["time"] = "10/19/19 18:43:11",
				["player"] = "Neorx-Lucifron",
			}, -- [13]
			{
				["time"] = "10/19/19 18:44:03",
				["player"] = "Leanside-Lucifron",
			}, -- [14]
		},
		["PlayerInfos"] = {
			["Xerker-Lucifron"] = {
			},
			["Neorx-Lucifron"] = {
			},
			["Eskalor-Lucifron"] = {
			},
			["Lacrimas-Lucifron"] = {
			},
			["Leanside-Lucifron"] = {
			},
			["Unbekannt-Lucifron"] = {
			},
			["Luckypriest-Lucifron"] = {
			},
			["Likenik-Lucifron"] = {
			},
			["Greentomato-Lucifron"] = {
			},
		},
		["key"] = "10/19/19 18:30:31",
		["BossKills"] = {
		},
		["Realm"] = "Lucifron",
	}, -- [16]
	{
		["Leave"] = {
			{
				["time"] = "10/14/19 22:59:55",
				["player"] = "Yeste-Lucifron",
			}, -- [1]
			{
				["time"] = "10/14/19 23:00:32",
				["player"] = "raid1",
			}, -- [2]
			{
				["time"] = "10/14/19 23:00:32",
				["player"] = "raid2",
			}, -- [3]
			{
				["time"] = "10/14/19 23:00:32",
				["player"] = "raid3",
			}, -- [4]
			{
				["time"] = "10/14/19 23:00:32",
				["player"] = "raid4",
			}, -- [5]
			{
				["time"] = "10/14/19 23:00:32",
				["player"] = "raid5",
			}, -- [6]
			{
				["time"] = "10/15/19 00:07:40",
				["player"] = "Seekây-Lucifron",
			}, -- [7]
			{
				["time"] = "10/15/19 00:07:40",
				["player"] = "raid5",
			}, -- [8]
			{
				["time"] = "10/15/19 00:07:40",
				["player"] = "raid4",
			}, -- [9]
			{
				["time"] = "10/15/19 00:07:40",
				["player"] = "raid3",
			}, -- [10]
			{
				["time"] = "10/15/19 00:07:40",
				["player"] = "Zorkar-Lucifron",
			}, -- [11]
			{
				["time"] = "10/15/19 00:07:40",
				["player"] = "raid1",
			}, -- [12]
			{
				["time"] = "10/15/19 00:07:40",
				["player"] = "Tarlen-Lucifron",
			}, -- [13]
			{
				["time"] = "10/15/19 00:07:40",
				["player"] = "raid2",
			}, -- [14]
			{
				["time"] = "10/15/19 00:07:40",
				["player"] = "Luckypriest-Lucifron",
			}, -- [15]
			{
				["time"] = "10/15/19 00:07:40",
				["player"] = "Yeste-Lucifron",
			}, -- [16]
			{
				["time"] = "10/15/19 00:07:40",
				["player"] = "Juze-Lucifron",
			}, -- [17]
		},
		["Join"] = {
			{
				["time"] = "10/14/19 22:59:53",
				["player"] = "Juze-Lucifron",
			}, -- [1]
			{
				["time"] = "10/14/19 22:59:53",
				["player"] = "Zorkar-Lucifron",
			}, -- [2]
			{
				["time"] = "10/14/19 22:59:53",
				["player"] = "Seekây-Lucifron",
			}, -- [3]
			{
				["time"] = "10/14/19 22:59:53",
				["player"] = "Tarlen-Lucifron",
			}, -- [4]
			{
				["time"] = "10/14/19 22:59:53",
				["player"] = "Luckypriest-Lucifron",
			}, -- [5]
			{
				["time"] = "10/14/19 22:59:53",
				["player"] = "Juze-Lucifron",
			}, -- [6]
			{
				["time"] = "10/14/19 22:59:53",
				["player"] = "Zorkar-Lucifron",
			}, -- [7]
			{
				["time"] = "10/14/19 22:59:53",
				["player"] = "Seekây-Lucifron",
			}, -- [8]
			{
				["time"] = "10/14/19 22:59:53",
				["player"] = "Tarlen-Lucifron",
			}, -- [9]
			{
				["time"] = "10/14/19 22:59:53",
				["player"] = "Luckypriest-Lucifron",
			}, -- [10]
			{
				["time"] = "10/14/19 23:00:27",
				["player"] = "Yeste-Lucifron",
			}, -- [11]
		},
		["Loot"] = {
		},
		["End"] = "10/15/19 00:07:40",
		["BossKills"] = {
		},
		["key"] = "10/14/19 22:59:53",
		["PlayerInfos"] = {
			["Seekây-Lucifron"] = {
			},
			["raid3"] = {
			},
			["raid4"] = {
			},
			["Yeste-Lucifron"] = {
			},
			["Zorkar-Lucifron"] = {
			},
			["raid1"] = {
			},
			["Tarlen-Lucifron"] = {
			},
			["Juze-Lucifron"] = {
			},
			["Luckypriest-Lucifron"] = {
			},
			["raid2"] = {
			},
			["raid5"] = {
			},
		},
		["Realm"] = "Lucifron",
	}, -- [17]
	{
		["Leave"] = {
			{
				["time"] = "10/11/19 00:04:43",
				["player"] = "Sukramrossi-Lucifron",
			}, -- [1]
			{
				["time"] = "10/11/19 00:04:44",
				["player"] = "Zavîer-Lucifron",
			}, -- [2]
			{
				["time"] = "10/11/19 00:04:48",
				["player"] = "Abxynth-Lucifron",
			}, -- [3]
			{
				["time"] = "10/11/19 00:04:48",
				["player"] = "Kotzogon-Lucifron",
			}, -- [4]
			{
				["time"] = "10/11/19 00:06:03",
				["player"] = "raid1",
			}, -- [5]
			{
				["time"] = "10/11/19 00:06:03",
				["player"] = "raid2",
			}, -- [6]
			{
				["time"] = "10/11/19 00:06:03",
				["player"] = "raid3",
			}, -- [7]
			{
				["time"] = "10/11/19 00:06:03",
				["player"] = "raid4",
			}, -- [8]
			{
				["time"] = "10/11/19 00:06:03",
				["player"] = "raid5",
			}, -- [9]
			{
				["time"] = "10/11/19 00:06:22",
				["player"] = "Abxynth-Lucifron",
			}, -- [10]
			{
				["time"] = "10/11/19 00:06:22",
				["player"] = "raid5",
			}, -- [11]
			{
				["time"] = "10/11/19 00:06:22",
				["player"] = "Kotzogon-Lucifron",
			}, -- [12]
			{
				["time"] = "10/11/19 00:06:22",
				["player"] = "raid4",
			}, -- [13]
			{
				["time"] = "10/11/19 00:06:22",
				["player"] = "Xardies-Lucifron",
			}, -- [14]
			{
				["time"] = "10/11/19 00:06:22",
				["player"] = "raid1",
			}, -- [15]
			{
				["time"] = "10/11/19 00:06:22",
				["player"] = "Zavîer-Lucifron",
			}, -- [16]
			{
				["time"] = "10/11/19 00:06:22",
				["player"] = "raid3",
			}, -- [17]
			{
				["time"] = "10/11/19 00:06:22",
				["player"] = "Sukramrossi-Lucifron",
			}, -- [18]
			{
				["time"] = "10/11/19 00:06:22",
				["player"] = "raid2",
			}, -- [19]
			{
				["time"] = "10/11/19 00:06:22",
				["player"] = "Luckypriest-Lucifron",
			}, -- [20]
		},
		["End"] = "10/11/19 00:06:22",
		["Loot"] = {
		},
		["Join"] = {
			{
				["time"] = "10/11/19 00:04:43",
				["player"] = "Xardies-Lucifron",
			}, -- [1]
			{
				["time"] = "10/11/19 00:04:43",
				["player"] = "Abxynth-Lucifron",
			}, -- [2]
			{
				["time"] = "10/11/19 00:04:43",
				["player"] = "Kotzogon-Lucifron",
			}, -- [3]
			{
				["time"] = "10/11/19 00:04:43",
				["player"] = "Sukramrossi-Lucifron",
			}, -- [4]
			{
				["time"] = "10/11/19 00:04:43",
				["player"] = "Luckypriest-Lucifron",
			}, -- [5]
			{
				["time"] = "10/11/19 00:04:43",
				["player"] = "Xardies-Lucifron",
			}, -- [6]
			{
				["time"] = "10/11/19 00:04:43",
				["player"] = "Abxynth-Lucifron",
			}, -- [7]
			{
				["time"] = "10/11/19 00:04:43",
				["player"] = "Kotzogon-Lucifron",
			}, -- [8]
			{
				["time"] = "10/11/19 00:04:43",
				["player"] = "Luckypriest-Lucifron",
			}, -- [9]
			{
				["time"] = "10/11/19 00:04:48",
				["player"] = "Zavîer-Lucifron",
			}, -- [10]
		},
		["PlayerInfos"] = {
			["Abxynth-Lucifron"] = {
			},
			["raid5"] = {
			},
			["Kotzogon-Lucifron"] = {
			},
			["raid4"] = {
			},
			["Xardies-Lucifron"] = {
			},
			["raid1"] = {
			},
			["Zavîer-Lucifron"] = {
			},
			["raid3"] = {
			},
			["Luckypriest-Lucifron"] = {
			},
			["raid2"] = {
			},
			["Sukramrossi-Lucifron"] = {
			},
		},
		["BossKills"] = {
		},
		["key"] = "10/11/19 00:04:43",
		["Realm"] = "Lucifron",
	}, -- [18]
	{
		["Leave"] = {
			{
				["time"] = "10/08/19 19:39:01",
				["player"] = "Illmore-Lucifron",
			}, -- [1]
			{
				["time"] = "10/08/19 19:39:01",
				["player"] = "Herrlich-Lucifron",
			}, -- [2]
			{
				["time"] = "10/08/19 19:39:01",
				["player"] = "Unbekannt-Lucifron",
			}, -- [3]
			{
				["time"] = "10/08/19 19:39:01",
				["player"] = "Riku-Lucifron",
			}, -- [4]
			{
				["time"] = "10/08/19 19:39:01",
				["player"] = "Sukz-Lucifron",
			}, -- [5]
			{
				["time"] = "10/08/19 19:39:01",
				["player"] = "Testosterpwn-Lucifron",
			}, -- [6]
			{
				["time"] = "10/08/19 19:39:01",
				["player"] = "Minzberd-Lucifron",
			}, -- [7]
			{
				["time"] = "10/08/19 19:39:01",
				["player"] = "Vengè-Lucifron",
			}, -- [8]
			{
				["time"] = "10/08/19 19:39:01",
				["player"] = "Dynast-Lucifron",
			}, -- [9]
			{
				["time"] = "10/08/19 19:39:01",
				["player"] = "Bench-Lucifron",
			}, -- [10]
			{
				["time"] = "10/08/19 19:39:01",
				["player"] = "Nakanjo-Lucifron",
			}, -- [11]
			{
				["time"] = "10/08/19 19:39:01",
				["player"] = "Metrus-Lucifron",
			}, -- [12]
			{
				["time"] = "10/08/19 19:39:50",
				["player"] = "Herrlich-Lucifron",
			}, -- [13]
			{
				["time"] = "10/08/19 19:39:50",
				["player"] = "Bench-Lucifron",
			}, -- [14]
			{
				["time"] = "10/08/19 19:39:50",
				["player"] = "Testosterpwn-Lucifron",
			}, -- [15]
			{
				["time"] = "10/08/19 19:39:50",
				["player"] = "Jokerfrost-Lucifron",
			}, -- [16]
			{
				["time"] = "10/08/19 19:39:50",
				["player"] = "Riku-Lucifron",
			}, -- [17]
			{
				["time"] = "10/08/19 19:39:50",
				["player"] = "Shadowlink-Lucifron",
			}, -- [18]
			{
				["time"] = "10/08/19 19:39:50",
				["player"] = "Illmore-Lucifron",
			}, -- [19]
			{
				["time"] = "10/08/19 19:39:50",
				["player"] = "Nakanjo-Lucifron",
			}, -- [20]
			{
				["time"] = "10/08/19 19:39:50",
				["player"] = "Dynast-Lucifron",
			}, -- [21]
			{
				["time"] = "10/08/19 19:39:50",
				["player"] = "Metrus-Lucifron",
			}, -- [22]
			{
				["time"] = "10/08/19 19:39:50",
				["player"] = "Unbekannt-Lucifron",
			}, -- [23]
			{
				["time"] = "10/08/19 19:39:50",
				["player"] = "Vengè-Lucifron",
			}, -- [24]
			{
				["time"] = "10/08/19 19:39:50",
				["player"] = "Luckypriest-Lucifron",
			}, -- [25]
			{
				["time"] = "10/08/19 19:39:50",
				["player"] = "Minzberd-Lucifron",
			}, -- [26]
			{
				["time"] = "10/08/19 19:39:50",
				["player"] = "Sukz-Lucifron",
			}, -- [27]
		},
		["End"] = "10/08/19 19:39:50",
		["Loot"] = {
		},
		["Join"] = {
			{
				["time"] = "10/08/19 19:39:01",
				["player"] = "Illmore-Lucifron",
			}, -- [1]
			{
				["time"] = "10/08/19 19:39:01",
				["player"] = "Herrlich-Lucifron",
			}, -- [2]
			{
				["time"] = "10/08/19 19:39:01",
				["player"] = "Unbekannt-Lucifron",
			}, -- [3]
			{
				["time"] = "10/08/19 19:39:01",
				["player"] = "Luckypriest-Lucifron",
			}, -- [4]
			{
				["time"] = "10/08/19 19:39:01",
				["player"] = "Riku-Lucifron",
			}, -- [5]
			{
				["time"] = "10/08/19 19:39:01",
				["player"] = "Sukz-Lucifron",
			}, -- [6]
			{
				["time"] = "10/08/19 19:39:01",
				["player"] = "Testosterpwn-Lucifron",
			}, -- [7]
			{
				["time"] = "10/08/19 19:39:01",
				["player"] = "Unbekannt-Lucifron",
			}, -- [8]
			{
				["time"] = "10/08/19 19:39:01",
				["player"] = "Minzberd-Lucifron",
			}, -- [9]
			{
				["time"] = "10/08/19 19:39:01",
				["player"] = "Vengè-Lucifron",
			}, -- [10]
			{
				["time"] = "10/08/19 19:39:01",
				["player"] = "Dynast-Lucifron",
			}, -- [11]
			{
				["time"] = "10/08/19 19:39:01",
				["player"] = "Bench-Lucifron",
			}, -- [12]
			{
				["time"] = "10/08/19 19:39:01",
				["player"] = "Nakanjo-Lucifron",
			}, -- [13]
			{
				["time"] = "10/08/19 19:39:01",
				["player"] = "Metrus-Lucifron",
			}, -- [14]
			{
				["time"] = "10/08/19 19:39:01",
				["player"] = "Luckypriest-Lucifron",
			}, -- [15]
			{
				["time"] = "10/08/19 19:39:09",
				["player"] = "Illmore-Lucifron",
			}, -- [16]
			{
				["time"] = "10/08/19 19:39:09",
				["player"] = "Herrlich-Lucifron",
			}, -- [17]
			{
				["time"] = "10/08/19 19:39:09",
				["player"] = "Shadowlink-Lucifron",
			}, -- [18]
			{
				["time"] = "10/08/19 19:39:09",
				["player"] = "Riku-Lucifron",
			}, -- [19]
			{
				["time"] = "10/08/19 19:39:09",
				["player"] = "Sukz-Lucifron",
			}, -- [20]
			{
				["time"] = "10/08/19 19:39:09",
				["player"] = "Testosterpwn-Lucifron",
			}, -- [21]
			{
				["time"] = "10/08/19 19:39:09",
				["player"] = "Jokerfrost-Lucifron",
			}, -- [22]
			{
				["time"] = "10/08/19 19:39:09",
				["player"] = "Minzberd-Lucifron",
			}, -- [23]
			{
				["time"] = "10/08/19 19:39:09",
				["player"] = "Vengè-Lucifron",
			}, -- [24]
			{
				["time"] = "10/08/19 19:39:09",
				["player"] = "Dynast-Lucifron",
			}, -- [25]
			{
				["time"] = "10/08/19 19:39:09",
				["player"] = "Bench-Lucifron",
			}, -- [26]
			{
				["time"] = "10/08/19 19:39:09",
				["player"] = "Nakanjo-Lucifron",
			}, -- [27]
			{
				["time"] = "10/08/19 19:39:09",
				["player"] = "Metrus-Lucifron",
			}, -- [28]
		},
		["PlayerInfos"] = {
			["Herrlich-Lucifron"] = {
			},
			["Bench-Lucifron"] = {
			},
			["Testosterpwn-Lucifron"] = {
			},
			["Jokerfrost-Lucifron"] = {
			},
			["Riku-Lucifron"] = {
			},
			["Dynast-Lucifron"] = {
			},
			["Illmore-Lucifron"] = {
			},
			["Nakanjo-Lucifron"] = {
			},
			["Shadowlink-Lucifron"] = {
			},
			["Metrus-Lucifron"] = {
			},
			["Unbekannt-Lucifron"] = {
			},
			["Vengè-Lucifron"] = {
			},
			["Luckypriest-Lucifron"] = {
			},
			["Minzberd-Lucifron"] = {
			},
			["Sukz-Lucifron"] = {
			},
		},
		["key"] = "10/08/19 19:39:01",
		["BossKills"] = {
		},
		["Realm"] = "Lucifron",
	}, -- [19]
	{
		["Leave"] = {
			{
				["time"] = "10/08/19 18:59:49",
				["player"] = "Selvmorrd-Lucifron",
			}, -- [1]
			{
				["time"] = "10/08/19 18:59:49",
				["player"] = "Luckypriest-Lucifron",
			}, -- [2]
		},
		["End"] = "10/08/19 18:59:49",
		["Loot"] = {
		},
		["Join"] = {
			{
				["time"] = "10/08/19 18:47:20",
				["player"] = "Luckypriest-Lucifron",
			}, -- [1]
			{
				["time"] = "10/08/19 18:47:20",
				["player"] = "Selvmorrd-Lucifron",
			}, -- [2]
			{
				["time"] = "10/08/19 18:47:20",
				["player"] = "Luckypriest-Lucifron",
			}, -- [3]
			{
				["time"] = "10/08/19 18:47:20",
				["player"] = "Selvmorrd-Lucifron",
			}, -- [4]
		},
		["PlayerInfos"] = {
			["Selvmorrd-Lucifron"] = {
			},
			["Luckypriest-Lucifron"] = {
			},
		},
		["key"] = "10/08/19 18:47:20",
		["BossKills"] = {
		},
		["Realm"] = "Lucifron",
	}, -- [20]
	{
		["Leave"] = {
			{
				["time"] = "10/01/19 17:28:52",
				["player"] = "Pumpelz-Lucifron",
			}, -- [1]
			{
				["time"] = "10/01/19 17:28:52",
				["player"] = "Luckypriest-Lucifron",
			}, -- [2]
		},
		["End"] = "10/01/19 17:28:52",
		["Loot"] = {
		},
		["Join"] = {
			{
				["time"] = "10/01/19 17:22:23",
				["player"] = "Luckypriest-Lucifron",
			}, -- [1]
			{
				["time"] = "10/01/19 17:22:23",
				["player"] = "Pumpelz-Lucifron",
			}, -- [2]
			{
				["time"] = "10/01/19 17:22:23",
				["player"] = "Luckypriest-Lucifron",
			}, -- [3]
			{
				["time"] = "10/01/19 17:22:23",
				["player"] = "Pumpelz-Lucifron",
			}, -- [4]
		},
		["PlayerInfos"] = {
			["Pumpelz-Lucifron"] = {
			},
			["Luckypriest-Lucifron"] = {
			},
		},
		["key"] = "10/01/19 17:22:23",
		["BossKills"] = {
		},
		["Realm"] = "Lucifron",
	}, -- [21]
	{
		["Leave"] = {
			{
				["time"] = "09/28/19 10:04:13",
				["player"] = "Nakanjo-Lucifron",
			}, -- [1]
			{
				["time"] = "09/28/19 10:05:22",
				["player"] = "Nakanjo-Lucifron",
			}, -- [2]
			{
				["time"] = "09/28/19 10:07:06",
				["player"] = "Nakanjo-Lucifron",
			}, -- [3]
			{
				["time"] = "09/28/19 10:37:34",
				["player"] = "Nakanjo-Lucifron",
			}, -- [4]
			{
				["time"] = "09/28/19 10:37:34",
				["player"] = "Luckypriest-Lucifron",
			}, -- [5]
		},
		["Join"] = {
			{
				["time"] = "09/28/19 09:55:29",
				["player"] = "Luckypriest-Lucifron",
			}, -- [1]
			{
				["time"] = "09/28/19 09:55:29",
				["player"] = "Nakanjo-Lucifron",
			}, -- [2]
			{
				["time"] = "09/28/19 09:55:29",
				["player"] = "Luckypriest-Lucifron",
			}, -- [3]
			{
				["time"] = "09/28/19 09:55:29",
				["player"] = "Nakanjo-Lucifron",
			}, -- [4]
			{
				["time"] = "09/28/19 10:04:14",
				["player"] = "Nakanjo-Lucifron",
			}, -- [5]
			{
				["time"] = "09/28/19 10:05:23",
				["player"] = "Nakanjo-Lucifron",
			}, -- [6]
			{
				["time"] = "09/28/19 10:07:06",
				["player"] = "Nakanjo-Lucifron",
			}, -- [7]
		},
		["Loot"] = {
		},
		["End"] = "09/28/19 10:37:34",
		["BossKills"] = {
		},
		["key"] = "09/28/19 09:55:29",
		["PlayerInfos"] = {
			["Nakanjo-Lucifron"] = {
			},
			["Luckypriest-Lucifron"] = {
			},
		},
		["Realm"] = "Lucifron",
	}, -- [22]
	{
		["PlayerInfos"] = {
			["Luckypriest-Lucifron"] = {
			},
			["Vacanta-Lucifron"] = {
			},
		},
		["zone"] = "Molten Core",
		["Leave"] = {
			{
				["time"] = "09/25/19 06:51:24",
				["player"] = "Vacanta-Lucifron",
			}, -- [1]
			{
				["time"] = "09/25/19 06:51:24",
				["player"] = "Luckypriest-Lucifron",
			}, -- [2]
		},
		["BossKills"] = {
		},
		["Join"] = {
			{
				["time"] = "09/25/19 06:51:23",
				["player"] = "Luckypriest-Lucifron",
			}, -- [1]
			{
				["time"] = "09/25/19 06:51:23",
				["player"] = "Vacanta-Lucifron",
			}, -- [2]
		},
		["End"] = "09/25/19 06:51:24",
		["key"] = "09/25/19 06:51:23",
		["Loot"] = {
		},
		["Realm"] = "Lucifron",
	}, -- [23]
}
CT_RaidTracker_Options = {
	["NewRaidOnNewZone"] = false,
	["AutoSetEPGPCost"] = false,
	["DKPmonLoggingMode"] = false,
	["SaveTooltips"] = false,
	["AskCost"] = 7,
	["GuildSnapshot"] = false,
	["SaveExtendedPlayerInfo"] = true,
	["BonusLoot"] = false,
	["AutoGroup"] = false,
	["AutoBossChangeMinTime"] = 10,
	["MinQuality"] = 5,
	["GetDkpValue"] = 7,
	["LogGroup"] = false,
	["24hFormat"] = true,
	["AutoZone"] = true,
	["Timezone"] = 0,
	["AutoRaidCreation"] = true,
	["GroupItems"] = 5,
	["AutoBossBoss"] = "Trash mob",
	["TimeSync"] = false,
	["AutoBoss"] = 2,
	["LogBattlefield"] = false,
	["WipeCoolDown"] = 150,
	["LogAttendees"] = 1,
	["MaxLevel"] = 70,
	["WipePercent"] = 0.5,
	["NextBoss"] = false,
	["OldFormat"] = 0,
	["ListMeEnabled"] = true,
	["ExportFormat"] = 0,
	["MLdkp"] = 0,
	["Wipe"] = false,
	["WaitlistAttendanceType"] = 1,
}
CT_RaidTracker_SortOptions = {
	["method"] = "name",
	["itemmethod"] = "looted",
	["playeritemway"] = "asc",
	["way"] = "asc",
	["playeritemfilter"] = 1,
	["itemhistorymethod"] = "name",
	["playerraidway"] = "desc",
	["playeritemmethod"] = "name",
	["itemfilter"] = 1,
	["itemway"] = "asc",
	["itemhistoryway"] = "asc",
}
CT_RaidTracker_ItemOptions = {
}
CT_RaidTracker_ItemOptions_selected = nil
CT_RaidTracker_VersionFix = nil
CT_RaidTracker_GetCurrentRaid = 1
CT_RaidTracker_TimeOffsetStatus = nil
CT_RaidTracker_CustomZoneTriggers = {
}
CT_RaidTracker_WaitList = {
}
CT_RaidTracker_FuBarOptions = {
	["profiles"] = {
		["Default"] = {
			["minimapPosition"] = 226.909227968597,
			["detachedTooltip"] = {
				["fontSizePercent"] = 1,
			},
		},
	},
}
