
CT_BarModOptions = {
	["CHAR-Luckymagic-Lucifron"] = {
		["barHideInVehicle12"] = false,
		["barHideInOverride5"] = true,
		["orientation6"] = "ACROSS",
		["barHideInOverride6"] = true,
		["barHideInOverride3"] = true,
		["MOVABLE-GROUP9"] = {
			"BOTTOMLEFT", -- [1]
			"UIParent", -- [2]
			"BOTTOM", -- [3]
			-260, -- [4]
			495, -- [5]
			1, -- [6]
		},
		["barHideInOverride2"] = true,
		["MOVABLE-GROUP3"] = {
			"BOTTOMRIGHT", -- [1]
			"UIParent", -- [2]
			"BOTTOMRIGHT", -- [3]
			-31.0000019073486, -- [4]
			612, -- [5]
			1, -- [6]
		},
		["orientation12"] = "ACROSS",
		["barHideInOverride8"] = true,
		["skinNumber"] = 1,
		["orientation9"] = "ACROSS",
		["orientation10"] = "ACROSS",
		["showGroup7"] = false,
		["MOVABLE-GROUP7"] = {
			"BOTTOMLEFT", -- [1]
			"UIParent", -- [2]
			"BOTTOM", -- [3]
			-260, -- [4]
			365, -- [5]
			1, -- [6]
		},
		["MOVABLE-GROUP8"] = {
			"BOTTOMLEFT", -- [1]
			"UIParent", -- [2]
			"BOTTOM", -- [3]
			-260, -- [4]
			429.999969482422, -- [5]
			1, -- [6]
		},
		["barHideInOverride4"] = true,
		["MOVABLE-GROUP6"] = {
			"BOTTOMLEFT", -- [1]
			"UIParent", -- [2]
			"BOTTOM", -- [3]
			-260, -- [4]
			300, -- [5]
			1, -- [6]
		},
		["orientation4"] = "ACROSS",
		["orientation1"] = "DOWN",
		["MOVABLE-GROUP2"] = {
			"BOTTOMRIGHT", -- [1]
			"UIParent", -- [2]
			"BOTTOMRIGHT", -- [3]
			12, -- [4]
			612, -- [5]
			1, -- [6]
		},
		["orientation2"] = "DOWN",
		["barHideInOverride1"] = true,
		["orientation7"] = "ACROSS",
		["MOVABLE-GROUP12"] = {
			"BOTTOM", -- [1]
			"UIParent", -- [2]
			"BOTTOM", -- [3]
			-486, -- [4]
			45, -- [5]
			1, -- [6]
		},
		["showGroup11"] = false,
		["showGroup10"] = false,
		["barHideInOverride12"] = false,
		["stdPositions"] = true,
		["MOVABLE-GROUP10"] = {
			"BOTTOMLEFT", -- [1]
			"UIParent", -- [2]
			"BOTTOM", -- [3]
			-260, -- [4]
			560.000061035156, -- [5]
			1, -- [6]
		},
		["disableDefaultActionBar"] = true,
		["showGroup12"] = 1,
		["MOVABLE-GROUP5"] = {
			"BOTTOMLEFT", -- [1]
			"UIParent", -- [2]
			"BOTTOM", -- [3]
			-516, -- [4]
			111.000007629395, -- [5]
			1, -- [6]
		},
		["barHideInOverride7"] = true,
		["showGroup6"] = false,
		["MOVABLE-GROUP4"] = {
			"BOTTOMLEFT", -- [1]
			"UIParent", -- [2]
			"BOTTOM", -- [3]
			0, -- [4]
			111.000007629395, -- [5]
			1, -- [6]
		},
		["barHideInVehicle11"] = false,
		["MOVABLE-GROUP11"] = {
			"BOTTOMLEFT", -- [1]
			"UIParent", -- [2]
			"BOTTOM", -- [3]
			-260, -- [4]
			625.000061035156, -- [5]
			1, -- [6]
		},
		["orientation3"] = "DOWN",
		["showGroup9"] = false,
		["orientation5"] = "ACROSS",
		["barHideInOverride11"] = false,
		["barHideInOverride9"] = true,
		["orientation11"] = "ACROSS",
		["orientation8"] = "ACROSS",
		["MOVABLE-GROUP1"] = {
			"BOTTOMLEFT", -- [1]
			"UIParent", -- [2]
			"TOPLEFT", -- [3]
			-10, -- [4]
			-85, -- [5]
			1, -- [6]
		},
		["barHideInOverride10"] = true,
		["showGroup8"] = false,
	},
}
