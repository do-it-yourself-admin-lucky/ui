
QuesterDB = {
	["profileKeys"] = {
		["Luckypriest - Patchwerk"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
		},
	},
}
