
InformantConfig = {
	["welcomed"] = true,
	["profile.Default"] = {
	},
	["position"] = {
		["y"] = 600,
		["x"] = 1066.66674804688,
	},
}
InformantLocalUpdates = nil
