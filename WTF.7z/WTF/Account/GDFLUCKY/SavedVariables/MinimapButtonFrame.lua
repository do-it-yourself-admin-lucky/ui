
MBFDB = {
	["profileKeys"] = {
		["Luckypriest - Lucifron"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["MBF_FrameLocation"] = {
				nil, -- [1]
				"RIGHT", -- [2]
				-6.24889755249024, -- [3]
				127.499885559082, -- [4]
			},
			["customChildren"] = {
				"MinimapButtonFrameDragButton", -- [1]
				"MiniMapMailFrameDisabled", -- [2]
				"LibDBIcon10_AtlasLoot", -- [3]
				"CT_MinimapButton", -- [4]
				"LibDBIcon10_DBM", -- [5]
				"LibDBIcon10_NovaWorldBuffs", -- [6]
				"LibDBIcon10_Questie", -- [7]
				"LibDBIcon10_WeakAuras", -- [8]
				"WIM3MinimapButton", -- [9]
				"LibDBIcon10_Details", -- [10]
				"LibDBIcon10_DetailsStreamer", -- [11]
			},
		},
	},
}
