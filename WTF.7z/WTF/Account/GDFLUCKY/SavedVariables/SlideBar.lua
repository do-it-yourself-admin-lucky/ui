
SlideBarConfig = {
	["locked"] = false,
	["enabled"] = true,
	["visibility"] = false,
}
