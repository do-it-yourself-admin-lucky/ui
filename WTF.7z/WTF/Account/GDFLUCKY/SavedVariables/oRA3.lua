
oRA3DB = {
	["namespaces"] = {
		["Promote"] = {
		},
		["Tanks"] = {
		},
		["ReadyCheck"] = {
		},
		["Invite"] = {
		},
	},
	["profileKeys"] = {
		["Luckypriest - Lucifron"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["positions"] = {
				["oRA3ReadyCheck"] = {
				},
			},
		},
	},
}
