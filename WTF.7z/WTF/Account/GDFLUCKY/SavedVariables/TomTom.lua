
TomTomDB = {
	["profileKeys"] = {
		["Luckypriest - Lucifron"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["arrow"] = {
				["position"] = {
					"CENTER", -- [1]
					nil, -- [2]
					"CENTER", -- [3]
					0, -- [4]
					0, -- [5]
				},
			},
			["block"] = {
				["position"] = {
					"BOTTOMRIGHT", -- [1]
					nil, -- [2]
					"BOTTOMRIGHT", -- [3]
					-455.555877685547, -- [4]
					39.4445953369141, -- [5]
				},
			},
		},
	},
}
TomTomWaypoints = nil
TomTomWaypointsM = {
	["profileKeys"] = {
		["Luckypriest - Lucifron"] = "Luckypriest - Lucifron",
	},
	["profiles"] = {
		["Luckypriest - Lucifron"] = {
		},
	},
}
