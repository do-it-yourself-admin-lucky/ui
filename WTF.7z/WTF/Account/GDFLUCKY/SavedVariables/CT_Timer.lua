
CT_TimerOptions = {
	["CHAR-Luckymagic-Lucifron"] = {
		["timerData"] = {
			["time"] = 0,
			["color"] = {
				1, -- [1]
				0, -- [2]
				0, -- [3]
			},
			["step"] = 1,
		},
		["position"] = {
			"CENTER", -- [1]
			"UIParent", -- [2]
			"CENTER", -- [3]
			0, -- [4]
			0, -- [5]
		},
	},
}
