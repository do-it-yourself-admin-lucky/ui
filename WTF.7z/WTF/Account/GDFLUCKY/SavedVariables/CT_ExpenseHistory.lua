
CT_EH_History = {
	["Luckymagic@Lucifron"] = {
		["class"] = "Magier",
		["key"] = "Luckymagic@Lucifron",
		["filename"] = "MAGE",
	},
	["version"] = 1.3,
	["startUsage"] = 1573061383,
}
