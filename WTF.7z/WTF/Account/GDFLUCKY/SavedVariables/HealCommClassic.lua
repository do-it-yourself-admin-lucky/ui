
HealCommSettings = {
	["profileKeys"] = {
		["Luckypriest - Lucifron"] = "Luckypriest - Lucifron",
	},
}
