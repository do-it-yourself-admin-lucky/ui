
DBMOnyxia_SavedStats = {
	["Onyxia"] = {
		["normalPulls"] = 37,
		["challengeKills"] = 0,
		["challengeBestRank"] = 0,
		["mythicKills"] = 0,
		["lfr25Kills"] = 0,
		["heroic25Pulls"] = 0,
		["lfr25Pulls"] = 0,
		["normal25Pulls"] = 0,
		["normalLastTime"] = 198.164000000001,
		["normalKills"] = 27,
		["heroic25Kills"] = 0,
		["normalBestTime"] = 164.761999999988,
		["timewalkerPulls"] = 0,
		["heroicKills"] = 0,
		["heroicPulls"] = 0,
		["normal25Kills"] = 0,
		["timewalkerKills"] = 0,
		["mythicPulls"] = 0,
		["challengePulls"] = 0,
	},
}
