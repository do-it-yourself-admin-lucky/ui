
ElvCharacterDB = {
	["ChatEditHistory"] = {
		"/s dankle", -- [1]
	},
	["ChatHistoryLog"] = {
		{
			"Habe die Nummer abgespeichert", -- [1]
			"|Km25|k", -- [2]
			"", -- [3]
			"", -- [4]
			"", -- [5]
			"", -- [6]
			0, -- [7]
			0, -- [8]
			"", -- [9]
			0, -- [10]
			3988, -- [11]
			false, -- [12]
			40, -- [13]
			false, -- [14]
			false, -- [15]
			false, -- [16]
			false, -- [17]
			[52] = "Bigholmi",
			[51] = 1569159047,
			[50] = "CHAT_MSG_BN_WHISPER",
			[53] = "Bigholmi",
		}, -- [1]
		{
			"ok sascha wann gehts du den immer darten?", -- [1]
			"|Km25|k", -- [2]
			"", -- [3]
			"", -- [4]
			"", -- [5]
			"", -- [6]
			0, -- [7]
			0, -- [8]
			"", -- [9]
			0, -- [10]
			3989, -- [11]
			false, -- [12]
			40, -- [13]
			false, -- [14]
			false, -- [15]
			false, -- [16]
			false, -- [17]
			[52] = "Bigholmi",
			[51] = 1569159060,
			[50] = "CHAT_MSG_BN_WHISPER_INFORM",
			[53] = "Bigholmi",
		}, -- [2]
		{
			"Donnerstags und Freitags. Immer ab 18 Uhr ", -- [1]
			"|Km25|k", -- [2]
			"", -- [3]
			"", -- [4]
			"", -- [5]
			"", -- [6]
			0, -- [7]
			0, -- [8]
			"", -- [9]
			0, -- [10]
			3992, -- [11]
			false, -- [12]
			40, -- [13]
			false, -- [14]
			false, -- [15]
			false, -- [16]
			false, -- [17]
			[52] = "Bigholmi",
			[51] = 1569159135,
			[50] = "CHAT_MSG_BN_WHISPER",
			[53] = "Bigholmi",
		}, -- [3]
		{
			"dann würde ich mich da gern mal anschließen, kann man sich da darts leihen weil ich ja noch keine eigenen hab? spielst du da in der liga?", -- [1]
			"|Km25|k", -- [2]
			"", -- [3]
			"", -- [4]
			"", -- [5]
			"", -- [6]
			0, -- [7]
			0, -- [8]
			"", -- [9]
			0, -- [10]
			3999, -- [11]
			false, -- [12]
			40, -- [13]
			false, -- [14]
			false, -- [15]
			false, -- [16]
			false, -- [17]
			[52] = "Bigholmi",
			[51] = 1569159180,
			[50] = "CHAT_MSG_BN_WHISPER_INFORM",
			[53] = "Bigholmi",
		}, -- [4]
		{
			"dankle", -- [1]
			"Luckyshaman-Lucifron", -- [2]
			"Orcisch", -- [3]
			"", -- [4]
			"Luckyshaman", -- [5]
			"", -- [6]
			0, -- [7]
			0, -- [8]
			"", -- [9]
			0, -- [10]
			4003, -- [11]
			"Player-4463-011AF8D5", -- [12]
			0, -- [13]
			false, -- [14]
			false, -- [15]
			false, -- [16]
			false, -- [17]
			[52] = "|cff0270ddLuckyshaman|r",
			[51] = 1569159200,
			[50] = "CHAT_MSG_SAY",
		}, -- [5]
		{
			"np", -- [1]
			"Ramman-Lucifron", -- [2]
			"", -- [3]
			"", -- [4]
			"Ramman", -- [5]
			"", -- [6]
			0, -- [7]
			0, -- [8]
			"", -- [9]
			0, -- [10]
			4005, -- [11]
			"Player-4463-0125AEE3", -- [12]
			0, -- [13]
			false, -- [14]
			false, -- [15]
			false, -- [16]
			false, -- [17]
			[52] = "|cffffffffRamman|r",
			[51] = 1569159203,
			[50] = "CHAT_MSG_WHISPER",
		}, -- [6]
		{
			"Ich selber spiele Liga und habe ein eigenes Team. Man kann aber auch Freizeit mäßig spielen. ", -- [1]
			"|Km25|k", -- [2]
			"", -- [3]
			"", -- [4]
			"", -- [5]
			"", -- [6]
			0, -- [7]
			0, -- [8]
			"", -- [9]
			0, -- [10]
			4016, -- [11]
			false, -- [12]
			40, -- [13]
			false, -- [14]
			false, -- [15]
			false, -- [16]
			false, -- [17]
			[52] = "Bigholmi",
			[51] = 1569159246,
			[50] = "CHAT_MSG_BN_WHISPER",
			[53] = "Bigholmi",
		}, -- [7]
	},
}
